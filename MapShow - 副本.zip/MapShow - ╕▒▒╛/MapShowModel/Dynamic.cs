﻿/**  版本信息模板在安装目录下，可自行修改。
* Dynamic.cs
*
* 功 能： N/A
* 类 名： Dynamic
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  18/6/22 21:12:28   N/A    初版
*
* Copyright (c) 2012 Maticsoft Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：动软卓越（北京）科技有限公司　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
namespace MapShowModel
{
	/// <summary>
	/// Dynamic:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class Dynamic
	{
		public Dynamic()
		{}
		#region Model
		private int? _id;
		private int? _creatid;
		private DateTime? _creatdate;
		private string _dynamicdata;
		private string _videodata;
		private string _address;
		private string _latlng;
		private int? _commentnum;
		private int? _favornum;
		/// <summary>
		/// 
		/// </summary>
		public int? id
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? creatid
		{
			set{ _creatid=value;}
			get{return _creatid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? creatdate
		{
			set{ _creatdate=value;}
			get{return _creatdate;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string dynamicdata
		{
			set{ _dynamicdata=value;}
			get{return _dynamicdata;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string videodata
		{
			set{ _videodata=value;}
			get{return _videodata;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string address
		{
			set{ _address=value;}
			get{return _address;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string latlng
		{
			set{ _latlng=value;}
			get{return _latlng;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? commentnum
		{
			set{ _commentnum=value;}
			get{return _commentnum;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? favornum
		{
			set{ _favornum=value;}
			get{return _favornum;}
		}
		#endregion Model

	}
}

