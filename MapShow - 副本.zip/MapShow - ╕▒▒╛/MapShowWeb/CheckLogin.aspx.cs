﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MapShowWeb;
using System.Collections;
using System.Configuration;
using MapShowBLL;

namespace MapShowWeb
{
    public partial class CheckLogin : System.Web.UI.Page
    {
        static string ConnectString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        //HttpParrament newHttpParament = new HttpParrament();
        protected void Page_Load(object sender, EventArgs e)
        {
            string recieveParament = "";
            string outString = "";
            try
            {
                //recieveParament = newHttpParament.PostInput(System.Web.HttpContext.Current.Request.InputStream);
                recieveParament = Request.Form[0];
                //recieveParament = Request.Form["form1"].ToString();
                UsersBLL newUsersBLL = new UsersBLL(ConnectString);
                outString = newUsersBLL.CheckLogin(recieveParament);
            }
            catch (Exception ex)
            {
                outString = "{\"resultCode\":0,\"resultMessage\":\"" + ex.ToString() + "\"}";
            }

            Response.Write(outString);
            Response.End();
        }
    }
}