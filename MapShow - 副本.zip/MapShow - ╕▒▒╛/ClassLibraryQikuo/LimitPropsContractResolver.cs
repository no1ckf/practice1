﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Text;
using System.Linq;

namespace ClassLibraryQikuo
{
    public class LimitPropsContractResolver : DefaultContractResolver
    {
        string[] props = null;
        public LimitPropsContractResolver(string[] props)
        {
            //指定要序列化属性的清单
            this.props = props;
        }
        //REF: http://james.newtonking.com/archive/2009/10/23/efficient-json-with-json-net-reducing-serialized-json-size.aspx
        protected override IList<JsonProperty> CreateProperties(Type type,
            MemberSerialization memberSerialization)
        {
            IList<JsonProperty> list =
                base.CreateProperties(type, memberSerialization);
            //只保留清单有列出的属性
            return list.Where(p => props.Contains(p.PropertyName)).ToList();
        }

    }
}
