﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryQikuo
{
    public class ListPaging
    {
        public ListPaging()
        {

        }
        int? _pagePer;
        int? _pageNum;
        string _selectCon;
        string _orderBy;

        public int? pagePer
        {
            get
            {
                return _pagePer;
            }
            set
            {
                _pagePer = value;
            }
        }

        public int? pageNum
        {
            get
            {
                return _pageNum;
            }
            set
            {
                _pageNum = value;
            }
        }

        public string selectCon
        {
            get
            {
                return _selectCon;
            }
            set
            {
                _selectCon = value;
            }
        }

        public string orderBy
        {
            get
            {
                return _orderBy;
            }
            set
            {
                _orderBy = value;
            }
        }
    }
}
