﻿using System.Collections;
using System.Data.SqlClient;

namespace ClassLibraryQikuo
{
    public class FunctionOperation
    {
        private SqlConnection myConnection;
        DBOperation newDB;
        public FunctionOperation()
        {
            this.myConnection = new SqlConnection();
        }

        public FunctionOperation(string dataConstr)//dataConstr数据库的链接字符串
        {
            this.myConnection = new SqlConnection();
            this.myConnection = new SqlConnection(dataConstr);
            newDB = new DBOperation(dataConstr);
        }

        public bool CheckData(string tableName,string userCoLumn,string userName,string passColumn,string passWord)
        {
            try
            {
                int userCount = newDB.ReturnDataRowCount(tableName, "select * from " + tableName + " where " + userCoLumn + "='" + userName + "' and " + passColumn + "='" + passWord + "'");
                if (userCount > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateData(string tableName, ArrayList updateArr, string updateConStr)
        {
            string updateStr = "";
            for(int i=0;i<updateArr.Count;i++)
            {
                string dataType = ((DataObject)updateArr[i]).dataType;
                string dataColumn = ((DataObject)updateArr[i]).dataColumn;
                string dataValue = ((DataObject)updateArr[i]).dataValue;

                if(dataType=="int")
                {
                    updateStr = updateStr+ "," + dataColumn + "=" + dataValue;
                }
                else
                {
                    updateStr= updateStr+"," + dataColumn + "='" + dataValue+"'";
                }
            }

            updateStr = updateStr.Substring(1);

            updateStr = "update " + tableName + " set " + updateStr + " where " + updateConStr;
            return newDB.update(updateStr);
        }

        public bool InsertData(string tableName, ArrayList updateArr)
        {
            string columnListStr = "";
            string valueListStr = "";
            for (int i = 0; i < updateArr.Count; i++)
            {
                columnListStr = columnListStr + "," + ((DataObject)updateArr[i]).dataColumn;
                string dataType = ((DataObject)updateArr[i]).dataType;

                if (dataType == "int")
                {
                    valueListStr = valueListStr + "," + ((DataObject)updateArr[i]).dataValue;
                }
                else
                {
                    valueListStr = valueListStr + ",'" + ((DataObject)updateArr[i]).dataValue + "'";
                }

            }

            columnListStr = columnListStr.Substring(1);
            valueListStr = valueListStr.Substring(1);

            string updateString = "insert " + tableName + " (" + columnListStr + ") values (" + valueListStr + ")";
            return newDB.update(updateString);
        }

        public bool DeleteData(string tableName, ArrayList updateArr)
        {
            string deleteStr = "";
            string dataType = ((DataObject)updateArr[0]).dataType;

            if (dataType == "int")
            {
                deleteStr = "delete " + tableName + " where " + ((DataObject)updateArr[0]).dataColumn + "=" + ((DataObject)updateArr[0]).dataValue;
            }
            else
            {
                deleteStr = "delete " + tableName + " where " + ((DataObject)updateArr[0]).dataColumn + "='" + ((DataObject)updateArr[0]).dataValue+"'";
            }

            return newDB.update(deleteStr);
        }

        public object ReturnInsertSign(string tableName,string returnSign)
        {
            string selectString = "select top 1 * from " + tableName + " order by " + returnSign + " desc";
            return newDB.returndata(selectString, returnSign);
        }
    }
}
