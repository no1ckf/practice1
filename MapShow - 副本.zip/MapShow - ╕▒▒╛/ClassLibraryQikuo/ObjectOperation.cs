﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryQikuo
{
    class ObjectOperation
    {
        public int returnint(object newobj)
        {
            try
            {
                return Convert.ToInt32(newobj);
            }
            catch
            {
                return -1;
            }
        }

        public string returnstring(object newob)
        {
            if ((newob == null) || (newob == DBNull.Value))
            {
                return "";
            }
            return newob.ToString();
        }
    }
}
