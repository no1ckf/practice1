﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Xml;

namespace ClassLibraryQikuo
{
    public class XMLOperation
    {
        public XmlDocument newXML = new XmlDocument();
        public string savePath;
        public XMLOperation()
        {

        }

        public XMLOperation(string path)
        {
            savePath = path;
            newXML.Load(path);
        }

        public void SaveXML()
        {
            newXML.Save(savePath);
        }

        public DataSet returndataset(string xmlurl)
        {
            DataSet ds = new DataSet();
            ds.ReadXml(xmlurl);
            if (ds.Tables.Count > 0)
            {
                return ds;
            }
            else
            {
                return null;
            }
        }
 
        public bool AddNode(string parrentNodeString,string newNodeString,string nodeString)
        {
            XmlNode parrentNode = newXML.SelectSingleNode("/" + parrentNodeString);
            XmlElement newelement = newXML.CreateElement(newNodeString);//创建一个<Website>节点 

            //XmlElement newelement = new XmlElement();
            string[] nodearr = nodeString.Split('$');
            int q = nodearr.Length;

            for (int i = 0; i < q / 2; i++)
            {
                XmlElement addElement = newXML.CreateElement(nodearr[i * 2]);
                addElement.InnerText = nodearr[i * 2 + 1];
                newelement.AppendChild(addElement);
            }

            parrentNode.AppendChild(newelement);//添加到<Websites>节点中 
            SaveXML();

            return true;
            //parrentNode.AppendChild();
            return true;
        }

        public string ReturnInnerText(string selectString)
        {
            XmlNode newNode = newXML.SelectSingleNode(selectString);
            return newNode.InnerText;
        }

        public string ReturnAbbribute(string selectString)
        {
            XmlNode newNode = newXML.SelectSingleNode(selectString);
            return newNode.InnerText;
        }

        public bool SetNodeInner(string selectString,string setValue)
        {
            XmlNode newNode = newXML.SelectSingleNode(selectString);
            newNode.InnerText = setValue;
            SaveXML();
            return true;
        }

        public bool DeleteNode(string selectString)
        {
            XmlNode newNode = newXML.SelectSingleNode(selectString);
            newNode.ParentNode.RemoveChild(newNode);
            SaveXML();
            return true;
        }

        public void creatxmlfile(string filename, string onnode)
        {
            XmlDocument xmldoc;
            XmlNode xmlnode;
            XmlElement xmlelem;

            xmldoc = new XmlDocument();
            //加入XML的声明段落
            xmlnode = xmldoc.CreateNode(XmlNodeType.XmlDeclaration, "", "");
            xmldoc.AppendChild(xmlnode);
            //加入一个根元素
            xmlelem = xmldoc.CreateElement("", onnode, "");
            xmldoc.AppendChild(xmlelem);


            //保存创建好的XML文档
            try
            {
                xmldoc.Save(filename);
            }
            catch (Exception e)
            {
                //显示错误信息
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();



        }
    }
}
