﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ClassLibraryQikuo
{
    public delegate void GreetingDelegate<T>(string inString,string outString);
    public class IJSON
    {

        int _resultCode;
        string _resultMessage;
        object _resultData;

        public int resultCode
        {
            get
            {
                return _resultCode;
            }
            set
            {
                _resultCode = value;
            }
        }

        public string resultMessage
        {
            get
            {
                return _resultMessage;
            }
            set
            {
                _resultMessage = value;
            }
        }
        public Object resultData
        {
            get
            {
                return _resultData;
            }
            set
            {
                _resultData = value;
            }
        }

        public string SerializeObject(object o)
        {
            string json = JsonConvert.SerializeObject(o);
            return json;
        }

        public string SerializeObject<T>(T o)
        {
            string json = JsonConvert.SerializeObject(o);
            return json;
        }

        public string SerializeObject(object o, string[] newArr)
        {
            try
            {
                JsonSerializerSettings jsetting = new JsonSerializerSettings();
                jsetting.ContractResolver = new LimitPropsContractResolver(newArr);
                return JsonConvert.SerializeObject(o, Formatting.Indented, jsetting);
            }
            catch
            {
                return "error";
            }
        }

        public string ObjectToJSON<T>(T newObject)
        {
            IJSON newIJSON = new IJSON();
            return newIJSON.SerializeObject(newObject);
        }

        public string ObjectToJSON<T>(T newObject, string[] newArr)
        {
            IJSON newIJSON = new IJSON();
            return newIJSON.SerializeObject(newObject,newArr);
        }

        public T JSONToObject<T>(string JSONString) where T : class
        {
            JsonSerializer serializer = new JsonSerializer();
            StringReader sr = new StringReader(JSONString);
            object o;
            try
            {
                o = serializer.Deserialize(new JsonTextReader(sr), typeof(T));
            }
            catch
            {
                o = null;
            }
            T t = o as T;
            return t;
        }

        //public string ListToString<T>(List<T> newList)
        //{
        //    string outString = "";
           
        //    for(int i=0;i<newList.Count;i++)
        //    {
        //        outString=outString+SerializeObject()
        //    }

        //}

        public T DeserializeJsonToObject<T>(string json) where T : class
        {
            JsonSerializer serializer = new JsonSerializer();
            StringReader sr = new StringReader(json);
            object o;
            try
            {
                o = serializer.Deserialize(new JsonTextReader(sr), typeof(T));
            }
            catch
            {
                o = null;
            }
            T t = o as T;
            return t;
        }

        public IJSON SetIJSON(int resultCode,string resultMessage,object resultData)
        {
            IJSON newIJSON = new IJSON();
            newIJSON.resultCode = resultCode;
            newIJSON.resultMessage = resultMessage;
            newIJSON.resultData = resultData;
            return newIJSON;
        }

        public bool CheckJSON(string JSONString,string[] setArr)
        {
            bool outBool = true;
            for(int i=0;i<setArr.Length;i++)
            {
                if(JSONString.Contains("\""+setArr[i]+"\""))
                {
                    outBool = false;
                    break;
                }
            }
            return outBool;
        }

        public string IJSONToString(IJSON newIJSON)
        {
            string outString = "{\"resultCode\":" + newIJSON.resultCode + ",\"resultMessage\":\"" + newIJSON.resultMessage + "\",\"resultData\":" + newIJSON.resultData + "}";
            return outString;
        }

    }
}
