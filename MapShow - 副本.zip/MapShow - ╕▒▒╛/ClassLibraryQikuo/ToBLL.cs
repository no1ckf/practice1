﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;

namespace ClassLibraryQikuo
{
    //直接的数据操作，直接返回IJSON数据
    public class ToBLL<T> where T : class
    {
        #region 公共方法和参数
        DBOperation newDB;
        JSONOperation newJSON = new JSONOperation();//上面2行是每个DAL文件必须要的，方便在具体的文件操作的时候处理
        string connectString = "";
        IJSON newIJSON = new IJSON();
        ToDAL<T> newToDAL;

        public ToBLL(string conString)
        {
            newDB = new DBOperation(conString);//把数据库连接语句传递入qikuo类库中
            connectString = conString;
            newToDAL = new ToDAL<T>(conString);
        }
        #endregion

        #region 对象的操作方法
        /// <summary>
        /// 删除对象，传递入的是对象，id必须有id属性
        /// </summary>
        /// <param name="newObject">传递的对象</param>
        /// <returns>返回IJSON字符串</returns>
        public string DeleteObject(T newObject)
        {
            return DeleteObject(newIJSON.SerializeObject(newObject));
        }
        
        /// <summary>
        /// 编辑对象，传递入的是对象，对象必须有id属性
        /// </summary>
        /// <param name="newObject">传递过来的对象</param>
        /// <returns>IJSON数据</returns>
        public string EditObject(T newObject)
        {
            return EditObject(newIJSON.SerializeObject(newObject));
        }

        /// <summary>
        /// 添加对象，传递入的是对象
        /// </summary>
        /// <param name="newObject">传递的对象</param>
        /// <returns>IJSON数据</returns>
        public string AddObject(T newObject)
        {
            return AddObject(newIJSON.SerializeObject(newObject));
        }

        /// <summary>
        /// 通过json字符串进行数据删除操作
        /// </summary>
        /// <param name="recieveParament">json字符串</param>
        /// <returns>ijson字符串</returns>
        public string DeleteObject(string recieveParament)
        {
            string[] setJSON = { "id" };
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化
            _obj = newIJSON.DeserializeJsonToObject<T>(recieveParament);

            if (_obj == null || newIJSON.CheckJSON(recieveParament, setJSON))
            {
                newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
            }
            else
            {
                if (newDB.ReturnConnectStatus())
                {
                    string deleteStatus = "";
                    newToDAL.DeleteObject((T)_obj,  ref deleteStatus);

                    if (deleteStatus != "")
                    {
                        newIJSON = newIJSON.SetIJSON(10, deleteStatus, "");
                    }
                    else
                    {
                        newIJSON = newIJSON.SetIJSON(1, "删除成功", "");
                    }

                }
                else
                {
                    newIJSON = newIJSON.SetIJSON(3, "数据库连接失败", "");
                }
            }
            return newIJSON.SerializeObject(newIJSON);
        }

        /// <summary>
        /// 对于数据库删除、插入等数据进行执行操作，并返回json字符串
        /// </summary>
        /// <param name="recieveString">传递过来的字符串</param>
        /// <returns>返回ijson字符串</returns>
        public string UpdateString(string recieveString)
        {
            
            if (newDB.ReturnConnectStatus())
            {
                bool outBool = newDB.update(recieveString);
                if(outBool)
                    newIJSON = newIJSON.SetIJSON(1, "删除成功", "");
                else
                    newIJSON = newIJSON.SetIJSON(2, "删除失败", "");

            }
            else
            {
                newIJSON = newIJSON.SetIJSON(3, "数据库连接失败", "");
            }
           
            return newIJSON.SerializeObject(newIJSON);
        }

        /// <summary>
        /// 通过json字符串对于对象进行更新，返回ijson数据
        /// </summary>
        /// <param name="recieveParament">接收的json数据</param>
        /// <returns>返回ijson数据</returns>
        public string EditObject(string recieveParament)
        {
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化

            _obj = newIJSON.DeserializeJsonToObject<T>(recieveParament);

            string[] setJSON = { "id" };
            if (_obj == null || newIJSON.CheckJSON(recieveParament, setJSON))
            {
                newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
            }
            else
            {
                int setValuePro = (int)newToDAL.ReturnValue((T)_obj, "id");
                string checkString = " id=" + setValuePro + "";

                if (newDB.ReturnConnectStatus())//判定数据库是否连接成功
                {
                    int itemCount = newToDAL.ReturnObjectCount(checkString);

                    if (itemCount == 1)
                    {
                        string editStatus = "";
                        bool outBool = newToDAL.EditObject((T)_obj,ref editStatus);

                        if (outBool == true)
                        {
                            if (editStatus != "")
                            {
                                newIJSON = newIJSON.SetIJSON(802, editStatus, "");
                            }
                            else
                            {
                                newIJSON = newIJSON.SetIJSON(1, "更新成功", "");
                            }
                        }
                        else
                        {
                            newIJSON = newIJSON.SetIJSON(801, "更新失败", "");
                        }

                    }
                    else
                    {
                        newIJSON = newIJSON.SetIJSON(4, "对象不存在", "");
                    }
                }
                else
                {
                    newIJSON = newIJSON.SetIJSON(15, "数据库连接失败", "");
                }
            }
            return newIJSON.SerializeObject(newIJSON);
        }

        /// <summary>
        /// 通过json字符串对于对象进行添加，返回ijson数据
        /// </summary>
        /// <param name="recieveParament">接收的json数据</param>
        /// <returns>返回ijson数据</returns>
        public string AddObject(string recieveParament)
        {
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化

            _obj = newIJSON.DeserializeJsonToObject<T>(recieveParament);

            if (_obj == null)
            {
                newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
            }
            else
            {
                if (newDB.ReturnConnectStatus())
                {
                    string editStatus = "";
                    newToDAL.AddObject((T)_obj, ref editStatus);

                    if (editStatus != "")
                    {
                        newIJSON = newIJSON.SetIJSON(10, editStatus, "");
                    }
                    else
                    {
                        int itemId =Convert.ToInt32(newDB.returndata("SELECT   IDENT_CURRENT('" + t.Name + "') as itemid", "itemid"));
                        newIJSON = newIJSON.SetIJSON(1, "添加成功", "{\"id\":"+itemId+"}");
                    }

                }
                else
                {
                    newIJSON = newIJSON.SetIJSON(3, "数据库连接失败", "");
                }
            }

            return newIJSON.SerializeObject(newIJSON);
        }

        /// <summary>
        /// 通过json字符串对于对象进行添加，返回ijson数据，newArr是传递的参数类型
        /// </summary>
        /// <param name="recieveParament">json字符串</param>
        /// <param name="newArr">传递过来的参数，要去判定传递过来的json数据是否包含这些参数</param>
        /// <returns>ijson数据</returns>
        public string AddObject(string recieveParament,string[] newArr)//newArr的格式是\"id\"
        {
                System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化

            _obj = newIJSON.DeserializeJsonToObject<T>(recieveParament);

            if (_obj == null || newIJSON.CheckJSON(recieveParament, newArr))
            {
                newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
            }
            else
            {
                if (newDB.ReturnConnectStatus())
                {
                    string editStatus = "";
                    newToDAL.AddObject((T)_obj,ref editStatus);

                    if (editStatus != "")
                    {
                        newIJSON = newIJSON.SetIJSON(10, editStatus, "");
                    }
                    else
                    {
                        newIJSON = newIJSON.SetIJSON(1, "添加成功", "");
                    }

                }
                else
                {
                    newIJSON = newIJSON.SetIJSON(3, "数据库连接失败", "");
                }
            }

            return newIJSON.SerializeObject(newIJSON);
        }
        #endregion

        #region 对象及对象集合的返回

        /// <summary>
        /// 通过ListPage对象的json字符串返回数据，返回数据的格式是ijson字符串
        /// </summary>
        /// <param name="recieveParament">ListPage格式的字符串</param>
        /// <returns>ijson数据</returns>
        public string ReturnObjectList(string recieveParament)
        {
            ListPaging newListPaging = new ListPaging();
            try
            {
                newListPaging = newIJSON.DeserializeJsonToObject<ListPaging>(recieveParament);
                string outString = "";
                
                if (newDB.ReturnConnectStatus())
                {
                    List<T> newArr = new List<T>();
                    string selectStr = newListPaging.selectCon;

                    try
                    {
                        string pageString = newListPaging.orderBy;
                        int pagePer = (int)newListPaging.pagePer;
                        int pageNum = (int)newListPaging.pageNum;
                        
                        newArr = newToDAL.ReturnObjectList(selectStr, pageNum, pagePer);
                        outString =newIJSON.SerializeObject(newArr);
                        newIJSON = newIJSON.SetIJSON(102, "返回成功", outString);
                        
                    }
                    catch
                    {
                        newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
                    }
                }
                else
                {
                    newIJSON = newIJSON.SetIJSON(3, "数据库连接失败", "");
                }
               
            }
            catch
            {
                newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
            }

            return newIJSON.SerializeObject(newIJSON);
        }

        /// <summary>
        /// 通过ListPage对象的json字符串返回数据，返回数据的格式是ijson字符串，返回指定的列
        /// </summary>
        /// <param name="recieveParament">ListPage格式的字符串</param>
        /// <param name="setArr">查询的列的集合</param>
        /// <returns>ijson数据</returns>
        public string ReturnObjectList(string recieveParament, string[] setArr)
        {
            ListPaging newListPaging = new ListPaging();
            string outString = "";
            System.Type t = typeof(T);
            if (newDB.ReturnConnectStatus())
            {
                List<T> newArr = new List<T>();
                string selectStr = newListPaging.orderBy;

                try
                {
                    string pageString = newListPaging.selectCon;
                    int pagePer = (int)newListPaging.pagePer;
                    int pageNum = (int)newListPaging.pageNum;


                    if (pagePer == 0)
                    {
                        //newArr = newToDAL.ReturnObjectList(selectStr, objectName);
                    }
                    else
                    {
                        newArr = newToDAL.ReturnObjectList(selectStr, pageNum, pagePer);
                    }

                    if (newArr.Count > 0)
                    {
                        outString = newIJSON.SerializeObject(newArr);
                        newIJSON = newIJSON.SetIJSON(102, "返回成功", outString);
                    }
                    else
                    {
                        newIJSON = newIJSON.SetIJSON(101, "返回成功", "");
                    }
                }
                catch
                {
                    newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
                }
            }
            else
            {
                newIJSON = newIJSON.SetIJSON(3, "数据库连接失败", "");
            }
            return newIJSON.SerializeObject(newIJSON);
        }
        #endregion

        /// <summary>
        /// 返回指定的对象，返回数据是ijson字符串
        /// </summary>
        /// <param name="recieveParament">接收的ListPage对象的json字符串</param>
        /// <returns>返回的ijson字符串</returns>
        public string ReturnObject(string recieveParament)
        {
            ListPaging newListPaging = new ListPaging();
            newListPaging = newIJSON.DeserializeJsonToObject<ListPaging>(recieveParament);

            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化

            _obj = newIJSON.DeserializeJsonToObject<T>(recieveParament);

            _obj = newToDAL.ReturnObject(newListPaging.selectCon);

            if (newDB.ReturnConnectStatus())//判定数据库是否连接成功
            {
                int itemCount = newToDAL.ReturnObjectCount(newListPaging.selectCon);

                if (itemCount == 1)
                {

                    newIJSON = newIJSON.SetIJSON(1, "返回成功", _obj);

                }
                else
                {
                    newIJSON = newIJSON.SetIJSON(4, "对象不存在", "");
                }
            }
            else
            {
                newIJSON = newIJSON.SetIJSON(15, "数据库连接失败", "");
            }
                
            
            return newIJSON.SerializeObject(newIJSON);
        }

        /// <summary>
        /// 返回对象的数量
        /// </summary>
        /// <param name="recieveParament">ListPage的json字符串</param>
        /// <param name="objectName">对象名</param>
        /// <returns></returns>
        public string ReturnCount(string recieveParament)
        {
            string[] setJSON = { "selectcon" };
            ListPaging newListPaging = new ListPaging();
            newListPaging = newIJSON.DeserializeJsonToObject<ListPaging>(recieveParament);

            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化

            _obj = newIJSON.DeserializeJsonToObject<T>(recieveParament);

            if (newIJSON.CheckJSON(recieveParament, setJSON))
            {
                newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
            }
            else
            {
                _obj = newToDAL.ReturnObject(newListPaging.selectCon);

                if (newDB.ReturnConnectStatus())//判定数据库是否连接成功
                {
                    int itemCount = newToDAL.ReturnObjectCount(newListPaging.selectCon);
                    newIJSON = newIJSON.SetIJSON(1, "返回成功", itemCount);

                }
                else
                {
                    newIJSON = newIJSON.SetIJSON(15, "数据库连接失败", "");
                }
               
            }
            return newIJSON.SerializeObject(newIJSON);
        }

        /// <summary>
        /// 返回对象，只返回特定的属性
        /// </summary>
        /// <param name="recieveParament">接收的list的json字符串</param>
        /// <param name="setArr">对象的属性集合</param>
        /// <returns></returns>
        public string ReturnObject(string recieveParament, string[] setArr)
        {
            string[] setJSON = { "selectcon" };
            ListPaging newListPaging = new ListPaging();
            newListPaging = newIJSON.DeserializeJsonToObject<ListPaging>(recieveParament);

            System.Type t = typeof(T);
            
            Assembly ass = Assembly.GetAssembly(t);
            PropertyInfo[] pc = t.GetProperties();
            Object _obj = ass.CreateInstance(t.FullName);

            _obj = newIJSON.DeserializeJsonToObject<T>(recieveParament);

            if (newIJSON.CheckJSON(recieveParament, setJSON))
            {
                newIJSON = newIJSON.SetIJSON(201, "JSON格式错误", "");
            }
            else
            {
                if (newDB.ReturnConnectStatus())
                {
                    _obj = newToDAL.ReturnObject(newListPaging.selectCon);

                    if (newDB.ReturnConnectStatus())//判定数据库是否连接成功
                    {
                        int itemCount = newToDAL.ReturnObjectCount(newListPaging.selectCon);

                        if (itemCount == 1)
                        {

                            newIJSON = newIJSON.SetIJSON(1, "返回成功", newIJSON.SerializeObject((T)_obj,setArr));

                        }
                        else
                        {
                            newIJSON = newIJSON.SetIJSON(4, "对象不存在", "");
                        }
                    }
                    else
                    {
                        newIJSON = newIJSON.SetIJSON(15, "数据库连接失败", "");
                    }
                }
            }
            return newIJSON.SerializeObject(newIJSON);
        }

    }

    
}
