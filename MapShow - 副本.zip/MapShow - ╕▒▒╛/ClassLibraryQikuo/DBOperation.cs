﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;

namespace ClassLibraryQikuo
{
    public class DBOperation
    {
        private SqlConnection myConnection;

        public DBOperation()
        {
            
            this.myConnection = new SqlConnection();
        }

        public DBOperation(string dataConstr)//dataConstr数据库的链接字符串
        {
            this.myConnection = new SqlConnection();
            this.myConnection = new SqlConnection(dataConstr);
        }

        public DBOperation(SqlConnection newConnection)//dataConstr数据库的链接字符串
        {
            this.myConnection = newConnection;
        }

        public bool ReturnConnectStatus()//str查询字符串，item查询对应的条目
        {
            try
            {
                this.myConnection.Open();
                if(this.myConnection.State==ConnectionState.Open)
                {
                    this.myConnection.Close();
                    return true;
                }
                else
                {
                    this.myConnection.Close();
                    return false;
                }
            }
            catch(Exception ex)
            {
                this.myConnection.Close();
                return false;
            }
            
        }

        public int ReturnDataRowCount<T>(string conString)//tableName查询的表名，conString查询条件，返回行的数量
        {
            System.Type t = typeof(T);
            string selectStr = "select * from " + t.Name + " where 1=1 and " + conString;
            SqlDataAdapter myCommandselefreeitem = new SqlDataAdapter(selectStr, this.myConnection);
            DataSet selefreeitem = new DataSet();
            DataTable outdt = new DataTable();
            myCommandselefreeitem.Fill(selefreeitem, "selefreeitem");
            int rowsCount = selefreeitem.Tables["selefreeitem"].Rows.Count;
            return rowsCount;
        }

        public object returndata(string str, string item)//str查询字符串，item查询对应的条目
        {
            try
            {
                this.myConnection.Open();
            }
            catch
            {
            }
            SqlDataReader dr = new SqlCommand(str, this.myConnection).ExecuteReader();
            object ob = new object();
            if (dr.Read())
            {
                ob = dr[item];
                dr.Close();
                this.myConnection.Close();
                return ob;
            }
            dr.Close();
            this.myConnection.Close();
            return null;
        }

        public T returndata<T>(string str)
        {
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化
            SqlDataReader dr;

            PropertyInfo j;

            try
            {
                this.myConnection.Open();

                dr = new SqlCommand(str, this.myConnection).ExecuteReader();
                object ob = new object();
                if (dr.Read())
                {
                    foreach (PropertyInfo i in pc)
                    {
                        try
                        {
                            if (dr[i.Name] != null)
                                i.SetValue((T)_obj, dr[i.Name], null);
                        }
                        catch
                        {

                        }
                    }
                    dr.Close();
                    this.myConnection.Close();
                    return (T)_obj;
                }
                else
                {
                    dr.Close();
                    this.myConnection.Close();
                    return default(T);
                }
            }
            catch(Exception ex)
            {
                this.myConnection.Close();
                return default(T);
            }
        }

        public T returndata<T>(DataRow newDataRow)
        {
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化

            foreach (PropertyInfo pname in pc)
            {
                if (newDataRow[pname.Name] != null)
                    pname.SetValue((T)_obj, newDataRow[pname.Name], null);
            }
            return (T)_obj;
        }

        /// <summary>
        /// 返回对象的集合，采用分页的方式进行数据返回
        /// </summary>
        /// <typeparam name="T">返回对象</typeparam>
        /// <param name="selecon">查询条件</param>
        /// <param name="table">查询的表格，在一般的情况下和对象的名称一致</param>
        /// <param name="pageper">每一页显示多少数据</param>
        /// <param name="page">当前显示第几页，如果全部显示，则该值为0</param>
        /// <param name="sort">排序标识符，1代表降序，0代表升序</param>
        /// <param name="selecol">查询的列，如果全部查询为*</param>
        /// <param name="orderid">排序的关键字</param>
        /// <returns></returns>
        public List<T> returndatalist<T>(string selecon, string table, int pageper, int page, int sort, string selecol, string orderid, ref int TotalPage, ref int TotalItem)
        {
            string selestr = ReturnSelectStringByListPage(selecon, table, pageper, page, sort, selecol, orderid);

            SqlDataAdapter myCommandselefreeitem = new SqlDataAdapter(selestr, this.myConnection);
            DataSet selefreeitem = new DataSet();
            DataTable outdt = new DataTable();
            myCommandselefreeitem.Fill(selefreeitem, "selefreeitem");
            outdt = selefreeitem.Tables["selefreeitem"];
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            List<T> newList = new List<T>();

            for (int i = 0; i < outdt.Rows.Count; i++)
            {
                Object _obj = ass.CreateInstance(t.FullName);//泛型实例化
                foreach (PropertyInfo pname in pc)
                {
                    try
                    {
                        if (outdt.Rows[i][pname.Name] != null)
                            pname.SetValue((T)_obj, outdt.Rows[i][pname.Name], null);
                    }
                    catch
                    {

                    }
                }
                newList.Add((T)_obj);
            }
            TotalItem = ReturnDataRowCount<T>(selecon);
            if (TotalItem % pageper == 0)
                TotalPage = TotalItem / pageper;
            else
                TotalPage = TotalItem / pageper + 1;
            this.myConnection.Close();
            return newList;
        }

        public List<T> returndatalist<T>(string str)
        {
            SqlDataAdapter myCommandselefreeitem = new SqlDataAdapter(str, this.myConnection);
            DataSet selefreeitem = new DataSet();
            DataTable outdt = new DataTable();
            myCommandselefreeitem.Fill(selefreeitem, "selefreeitem");
            outdt = selefreeitem.Tables["selefreeitem"];
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            List<T> newList = new List<T>();
            for(int i=0;i<outdt.Rows.Count;i++)
            {
                Object _obj = ass.CreateInstance(t.FullName);//泛型实例化
                foreach (PropertyInfo pname in pc)
                {
                    if (outdt.Rows[i][pname.Name] != null)
                        pname.SetValue((T)_obj, outdt.Rows[i][pname.Name], null);
                }
                newList.Add((T)_obj);
            }
            this.myConnection.Close();
            return newList;
        }

        public List<T> returndatalistforjoin<T>(string str)
        {
            SqlDataAdapter myCommandselefreeitem = new SqlDataAdapter(str, this.myConnection);
            DataSet selefreeitem = new DataSet();
            DataTable outdt = new DataTable();
            myCommandselefreeitem.Fill(selefreeitem, "selefreeitem");
            outdt = selefreeitem.Tables["selefreeitem"];
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            List<T> newList = new List<T>();
            if (outdt.Rows.Count > 0)
            {
                for (int i = 0; i < outdt.Rows.Count; i++)
                {
                    Object _obj = ass.CreateInstance(t.FullName);//泛型实例化
                    foreach (PropertyInfo pname in pc)
                    {
                        try
                        {
                            if (outdt.Rows[i][pname.Name] != null)
                                pname.SetValue((T)_obj, outdt.Rows[i][pname.Name], null);
                        }
                        catch
                        {
                            pname.SetValue((T)_obj, null, null);
                        }
                    }
                    newList.Add((T)_obj);
                }
            }
            else
            {
                newList = default(List<T>);
            }
            this.myConnection.Close();
            return newList;
        }

        public List<T> returndatalist<T>(string selecon, string table, int pageper, int page, int sort,string selecol, string orderid)
        {
            string selestr = "";
            string setstr = "";
            string inorder = "";
            string middleorder = "";

            selestr = "select top " + pageper + " "+selecol+"  from " + table + " where 1=1 and " + selecon + " and " + orderid;
            if (sort == 0)
            {
                setstr = ">";
                inorder = " asc";
                middleorder = " desc";
            }
            else
            {
                setstr = "<";
                inorder = " desc";
                middleorder = " asc";
            }

            if (page == 1)
            {
                selestr = "select top " + pageper + " " + selecol + "  from " + table + " where 1=1 and " + selecon + " order by " + orderid + " " + inorder;
            }
            else
            {
                selestr = selestr + setstr + "(select top 1 " + orderid + " from " + table + " where 1=1 and " + selecon + " and " + orderid + " in (select top " + pageper * (page - 1) + " " + orderid + " from " + table + " where  1=1 and " + selecon + " order by " + orderid + " " + inorder + ") order by " + orderid + " " + middleorder + ") order by " + orderid + " " + inorder;
            }

            SqlDataAdapter myCommandselefreeitem = new SqlDataAdapter(selestr, this.myConnection);
            DataSet selefreeitem = new DataSet();
            DataTable outdt = new DataTable();
            myCommandselefreeitem.Fill(selefreeitem, "selefreeitem");
            outdt = selefreeitem.Tables["selefreeitem"];
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            List<T> newList = new List<T>();
            
            for (int i = 0; i < outdt.Rows.Count; i++)
            {
                Object _obj = ass.CreateInstance(t.FullName);//泛型实例化
                foreach (PropertyInfo pname in pc)
                {
                    if (outdt.Rows[i][pname.Name] != null)
                        pname.SetValue((T)_obj, outdt.Rows[i][pname.Name], null);
                }
                newList.Add((T)_obj);
            }
            this.myConnection.Close();
            return newList;
        }

        public List<T> returndatalistforjoin<T>(string selecon, string table, int pageper, int page, int sort, string selecol, string orderid)
        {
            string selestr = "";
            string setstr = "";
            string inorder = "";
            string middleorder = "";

            selestr = "select top " + pageper + " " + selecol + "  from " + table + " on 1=1 and " + selecon + " and " + orderid;
            if (sort == 0)
            {
                setstr = ">";
                inorder = " asc";
                middleorder = " desc";
            }
            else
            {
                setstr = "<";
                inorder = " desc";
                middleorder = " asc";
            }

            if (page == 1)
            {
                selestr = "select top " + pageper + " " + selecol + "  from " + table + " on 1=1 and " + selecon + " order by " + orderid + " " + inorder;
            }
            else
            {
                selestr = selestr + setstr + "(select top 1 " + orderid + " from " + table + " on 1=1 and " + selecon + " and " + orderid + " in (select top " + pageper * (page - 1) + " " + orderid + " from " + table + " on  1=1 and " + selecon + " order by " + orderid + " " + inorder + ") order by " + orderid + " " + middleorder + ") order by " + orderid + " " + inorder;
            }

            SqlDataAdapter myCommandselefreeitem = new SqlDataAdapter(selestr, this.myConnection);
            DataSet selefreeitem = new DataSet();
            DataTable outdt = new DataTable();
            myCommandselefreeitem.Fill(selefreeitem, "selefreeitem");
            outdt = selefreeitem.Tables["selefreeitem"];
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            List<T> newList = new List<T>();
            for (int i = 0; i < outdt.Rows.Count; i++)
            {

                Object _obj = ass.CreateInstance(t.FullName);//泛型实例化
                foreach (PropertyInfo pname in pc)
                {
                    if (outdt.Rows[i][pname.Name] != null)
                        pname.SetValue((T)_obj, outdt.Rows[i][pname.Name], null);
                }
                newList.Add((T)_obj);
            }
            this.myConnection.Close();
            return newList;
        }


        public DataTable returndatatable(string tableName, string conString)
        {
            string selectStr = "select * from " + tableName + " where 1=1 and " + conString;
            SqlDataAdapter myCommandselefreeitem = new SqlDataAdapter(selectStr, this.myConnection);
            DataSet selefreeitem = new DataSet();
            DataTable outdt = new DataTable();
            myCommandselefreeitem.Fill(selefreeitem, "selefreeitem");
            outdt = selefreeitem.Tables["selefreeitem"];
            this.myConnection.Close();
            return outdt;
        }

        public DataTable returndatatable(string selecon, string table, int pageper, int page, int sort, string orderid)
        {
            string selestr = "";
            string setstr = "";
            string inorder = "";
            string middleorder = "";

            selestr = "select top " + pageper + " *  from " + table + " where 1=1 and " + selecon + " and " + orderid;
            if (sort == 0)
            {
                setstr = ">";
                inorder = " asc";
                middleorder = " desc";
            }
            else
            {
                setstr = "<";
                inorder = " desc";
                middleorder = " asc";
            }

            if (page == 1)
            {
                selestr = "select top " + pageper + " *  from " + table + " where 1=1 and " + selecon + " order by " + orderid + " " + inorder;
            }
            else
            {
                selestr = selestr + setstr + "(select top 1 " + orderid + " from " + table + " where 1=1 and " + selecon + " and " + orderid + " in (select top " + pageper * (page - 1) + " " + orderid + " from " + table + " where  1=1 and " + selecon + " order by " + orderid + " " + inorder + ") order by " + orderid + " " + middleorder + ") order by " + orderid + " " + inorder;
            }

            SqlDataAdapter myCommandselefreeitem = new SqlDataAdapter(selestr, this.myConnection);
            DataSet selefreeitem = new DataSet();
            DataTable outdt = new DataTable();
            myCommandselefreeitem.Fill(selefreeitem, "selefreeitem");
            outdt = selefreeitem.Tables["selefreeitem"];
            this.myConnection.Close();
            return outdt;
        }

        public bool update(string str)
        {
            SqlCommand myCommand = new SqlCommand(str, this.myConnection);
            myCommand.Connection.Open();
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                myCommand.Connection.Close();
                return false;
            }
            myCommand.Connection.Close();
            return true;
        }

        #region 辅助方法
        public string ReturnSelectStringByListPage(string selecon, string table, int pageper, int page, int sort, string selecol, string orderid)
        {
            string selestr = "";
            string setstr = "";
            string inorder = "";
            string middleorder = "";

            selestr = "select top " + pageper + " " + selecol + "  from " + table + " where 1=1 and " + selecon + " and " + orderid;
            if (sort == 0)
            {
                setstr = ">";
                inorder = " asc";
                middleorder = " desc";
            }
            else
            {
                setstr = "<";
                inorder = " desc";
                middleorder = " asc";
            }

            if (page == 1)
            {
                selestr = "select top " + pageper + " " + selecol + "  from " + table + " where 1=1 and " + selecon + " order by " + orderid + " " + inorder;
            }
            else
            {
                selestr = selestr + setstr + "(select top 1 " + orderid + " from " + table + " where 1=1 and " + selecon + " and " + orderid + " in (select top " + pageper * (page - 1) + " " + orderid + " from " + table + " where  1=1 and " + selecon + " order by " + orderid + " " + inorder + ") order by " + orderid + " " + middleorder + ") order by " + orderid + " " + inorder;
            }
            return selestr;
        }

        public string ReturnInnerJoinSelectStringByListPage(string selecon, string table, int pageper, int page, int sort, string selecol, string orderid)
        {
            string selestr = "";
            string setstr = "";
            string inorder = "";
            string middleorder = "";

            selestr = "select top " + pageper + " " + selecol + "  from " + table + " on 1=1 and " + selecon + " and " + orderid;
            if (sort == 0)
            {
                setstr = ">";
                inorder = " asc";
                middleorder = " desc";
            }
            else
            {
                setstr = "<";
                inorder = " desc";
                middleorder = " asc";
            }

            if (page == 1)
            {
                selestr = "select top " + pageper + " " + selecol + "  from " + table + " on 1=1 and " + selecon + " order by " + orderid + " " + inorder;
            }
            else
            {
                selestr = selestr + setstr + "(select top 1 " + orderid + " from " + table + " on 1=1 and " + selecon + " and " + orderid + " in (select top " + pageper * (page - 1) + " " + orderid + " from " + table + " on  1=1 and " + selecon + " order by " + orderid + " " + inorder + ") order by " + orderid + " " + middleorder + ") order by " + orderid + " " + inorder;
            }
            return selestr;
        }
        #endregion
    }
}
