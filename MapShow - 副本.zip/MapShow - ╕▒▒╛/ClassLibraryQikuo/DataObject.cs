﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryQikuo
{
    public class DataObject
    {
        public DataObject()
        {
        }

        string _dataType, _dataColumn, _dataValue;

        public string dataType
        {
            get
            {
                return _dataType;
            }
            set
            {
                _dataType = value;
            }
        }

        public string dataColumn
        {
            get
            {
                return _dataColumn;
            }
            set
            {
                _dataColumn = value;
            }
        }

        public string dataValue
        {
            get
            {
                return _dataValue;
            }
            set
            {
                _dataValue = value;
            }
        }
    }
}
