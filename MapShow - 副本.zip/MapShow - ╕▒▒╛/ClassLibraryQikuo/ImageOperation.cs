﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Data;

namespace ClassLibraryQikuo
{
    class ImageProcessingLib
    {
        /// <summary>
        /// 保存图像
        /// </summary>
        /// <param name="curBitmap">待保存图像</param>
        /// <param name="filename">保存文件名</param>
        /// <returns></returns>
        public bool SavaBitmap(Bitmap curBitmap, string filename)
        {
            if (null == curBitmap)
                return false;

            if (filename.Length <= 3)
            {
                MessageBox.Show("保存文件的名字有误！");
                return false;
            }

            string strFilExtn = filename.Remove(0, filename.Length - 3);

            switch (strFilExtn)
            {
                case "bmp":
                    curBitmap.Save(filename, System.Drawing.Imaging.ImageFormat.Bmp);
                    break;
                case "jpg":
                    curBitmap.Save(filename, System.Drawing.Imaging.ImageFormat.Jpeg);
                    break;
                case "gif":
                    curBitmap.Save(filename, System.Drawing.Imaging.ImageFormat.Gif);
                    break;
                case "tif":
                    curBitmap.Save(filename, System.Drawing.Imaging.ImageFormat.Tiff);
                    break;
                case "png":
                    curBitmap.Save(filename, System.Drawing.Imaging.ImageFormat.Png);
                    break;
                default:
                    break;
            }

            return true;
        }

        /// <summary>
        /// 得到彩色图像的灰度数据
        /// </summary>
        /// <param name="curBitmap">原始图像</param>
        /// <param name="r_Rate"></param>
        /// <param name="g_Rate"></param>
        /// <param name="b_Rate"></param>
        /// <returns>图像的灰度数据</returns>
        public byte[] GetBitmapGrayData_Pixel(Bitmap curBitmap, float r_Rate = 0.299f, float g_Rate = 0.587f, float b_Rate = 0.114f)
        {
            if (null == curBitmap)
                return null;

            int width = curBitmap.Width;
            int height = curBitmap.Height;

            byte[] grayData = new byte[width * height];

            Color curColor;
            byte ret = 0;
            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    curColor = curBitmap.GetPixel(i, j);

                    ret = (byte)(curColor.R * r_Rate + curColor.G * g_Rate + curColor.B * b_Rate);

                    grayData[j * width + i] = ret;

                }
            }

            return grayData;
        }


        /// <summary>
        /// 得到彩色图像的灰度数据 -- 有点问题
        /// </summary>
        /// <param name="curBitmap">原始图像</param>
        /// <param name="r_Rate"></param>
        /// <param name="g_Rate"></param>
        /// <param name="b_Rate"></param>
        /// <returns>图像的灰度数据</returns>        
        public byte[] GetBitmapGrayData_Memory(ref Bitmap curBitmap, float r_Rate = 0.299f, float g_Rate = 0.587f, float b_Rate = 0.114f)
        {
            if (null == curBitmap)
                return null;

            int width = curBitmap.Width;
            int height = curBitmap.Height;

            byte[] grayData = new byte[width * height];


            Rectangle rect = new Rectangle(0, 0, width, height);

            System.Drawing.Imaging.BitmapData bmpData = curBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, curBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;

            int bytes = width * height * 3;

            byte[] rgbValues = new byte[bytes];

            System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);

            double colorTemp;
            for (int i = 0; i < rgbValues.Length; i += 3)
            {
                colorTemp = rgbValues[i + 2] * r_Rate + rgbValues[i + 1] * g_Rate + rgbValues[i] * b_Rate;

                rgbValues[i] = rgbValues[i + 1] = rgbValues[i + 2] = (byte)colorTemp;

                grayData[i] = (byte)colorTemp;
            }


            System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes);

            curBitmap.UnlockBits(bmpData);

            return grayData;
        }

        /// <summary>
        /// 得到彩色图像的灰度数据
        /// </summary>
        /// <param name="curBitmap">原始图像</param>
        /// <param name="r_Rate"></param>
        /// <param name="g_Rate"></param>
        /// <param name="b_Rate"></param>
        /// <returns>图像的灰度数据</returns>        
        public byte[] GetBitmapGrayData_Pointer(Bitmap curBitmap, float r_Rate = 0.299f, float g_Rate = 0.587f, float b_Rate = 0.114f)
        {
            if (null == curBitmap)
                return null;

            int width = curBitmap.Width;
            int height = curBitmap.Height;

            byte[] grayData = new byte[width * height];


            Rectangle rect = new Rectangle(0, 0, width, height);

            System.Drawing.Imaging.BitmapData bmpData = curBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, curBitmap.PixelFormat);
            byte temp = 0;
            unsafe
            {
                byte* ptr = (byte*)(bmpData.Scan0);
                for (int j = 0; j < height; j++)
                {
                    for (int i = 0; i < width; i++)
                    {
                        temp = (byte)(r_Rate * ptr[2] + g_Rate * ptr[1] + b_Rate * ptr[0]);
                        ptr[0] = ptr[1] = ptr[2] = temp;

                        ptr += 3;

                        grayData[j * width + i] = temp;
                    }
                    ptr += bmpData.Stride - bmpData.Width * 3;
                }
            }
            curBitmap.UnlockBits(bmpData);

            return grayData;
        }

        /// <summary>
        /// 由灰度得到图像
        /// </summary>
        /// <param name="grayData">图像灰度数据</param>
        /// <param name="width">图像宽度</param>
        /// <param name="height">图像高度</param>
        /// <returns>一幅Bitmap图像</returns>
        public Bitmap Gray2Bitmap(byte[] grayData, int width, int height)
        {
            if (null == grayData || grayData.Length <= 0)
                return null;

            Bitmap tempBitmap = new Bitmap(width, height);

            byte ret = 0;

            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    ret = grayData[j * width + i];
                    tempBitmap.SetPixel(i, j, Color.FromArgb(ret, ret, ret));
                }
            }

            return tempBitmap;
        }


        /// <summary>
        /// 得到统计直方图
        /// </summary>
        /// <param name="grayData"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns></returns>
        private double[] GetHist(byte[] grayData, int width, int height)
        {
            if (null == grayData || 0 >= width || 0 >= height)
                return null;

            const int num = 256;
            double[] hist = new double[num];
            Array.Clear(hist, 0, hist.Length);
            int i, j;
            for (j = 0; j < height; j++)
            {
                for (i = 0; i < width; i++)
                {
                    hist[grayData[j * width + i]]++;
                }
            }

            for (i = 0; i < num; i++)
            {
                hist[i] = hist[i] / (double)(width * height);
            }

            return hist;

        }

        /// <summary>
        /// 得到累积分布直方图
        /// </summary>
        /// <param name="hist"></param>
        /// <returns></returns>
        private double[] GetAccumulateDistribution(double[] hist)
        {
            if (null == hist || 0 >= hist.Length)
                return null;

            int len = hist.Length;
            double[] curHist = new double[len];
            Array.Clear(curHist, 0, curHist.Length);

            curHist[0] = hist[0];
            for (int i = 1; i < len; i++)
            {
                curHist[i] = curHist[i - 1] + hist[i];
            }

            return curHist;
        }

        /// <summary>
        /// 得到直方图均衡化变换
        /// </summary>
        /// <param name="hist"></param>
        /// <returns></returns>
        private byte[] GetHistTransform(double[] hist)
        {
            if (null == hist || 0 >= hist.Length)
                return null;

            int len = hist.Length;
            byte[] transHist = new byte[len];
            Array.Clear(transHist, 0, transHist.Length);

            for (int i = 0; i < len; i++)
            {
                transHist[i] = (byte)(255.0 * hist[i] + 0.5);
            }

            return transHist;
        }
        /// <summary>
        /// 得到直方图均衡化后的灰度数据
        /// </summary>
        /// <param name="oldGrayData"></param>
        /// <param name="transHist"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns></returns>
        private byte[] GetHistTransImageData(byte[] oldGrayData, byte[] transHist, int width, int height)
        {
            if (null == oldGrayData || 0 >= oldGrayData.Length || 0 >= width || 0 >= height)
                return null;

            if (null == transHist || 0 >= transHist.Length)
                return null;

            byte[] curGrayData = new byte[width * height];

            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    curGrayData[j * width + i] = transHist[oldGrayData[j * width + i]];
                }
            }

            return curGrayData;
        }

        /// <summary>
        /// 得到直方图均衡化后的数据
        /// </summary>
        /// <param name="oldBitmap"></param>
        /// <returns></returns>
        public byte[] GetHistTransImageData(Bitmap oldBitmap)
        {
            if (null == oldBitmap)
            {
                return null;
            }

            int width = oldBitmap.Width;
            int height = oldBitmap.Height;

            if (0 >= width || 0 >= height)
            {
                return null;
            }


            byte[] oldGrayData = GetBitmapGrayData_Pointer(oldBitmap);
            if (null == oldGrayData || 0 >= oldGrayData.Length)
            {
                return null;
            }


            double[] hist = GetHist(oldGrayData, width, height);
            if (null == hist || 0 >= hist.Length)
            {
                return null;
            }


            double[] curhist = GetAccumulateDistribution(hist);
            if (null == curhist || 0 >= curhist.Length)
            {
                return null;
            }

            byte[] transHist = GetHistTransform(curhist);
            if (null == transHist || 0 >= transHist.Length)
            {
                return null;
            }

            return GetHistTransImageData(oldGrayData, transHist, width, height);
        }

        /// <summary>
        /// 得到直方图均衡化后的图像
        /// </summary>
        /// <param name="oldBitmap"></param>
        /// <returns></returns>
        public Bitmap EqualizationImage(Bitmap oldBitmap)
        {
            if (null == oldBitmap)
            {
                return null;
            }

            int width = oldBitmap.Width;
            int height = oldBitmap.Height;

            if (0 >= width || 0 >= height)
            {
                return null;
            }

            byte[] curGrayData = GetHistTransImageData(oldBitmap);

            if (null == curGrayData || 0 >= curGrayData.Length)
            {
                return null;
            }

            return Gray2Bitmap(curGrayData, width, height);
        }

        /// <summary>
        /// 图像平移水平和垂直
        /// </summary>
        /// <param name="?"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public bool TranslationImage(Bitmap curBitmap, int x, int y)
        {
            if (null == curBitmap)
            {
                return false;
            }
            int width = curBitmap.Width;
            int height = curBitmap.Height;

            //byte[] grayData = new byte[width * height];

            //grayData = GetBitmapGrayData_Pointer(curBitmap);//得到图形灰度值             

            // Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
            // System.Drawing.Imaging.BitmapData bmpData = curBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, curBitmap.PixelFormat);

            // byte[] tempArray = new byte[width * height];

            // tempArray = (byte[])grayData.Clone();
            //// grayData.CopyTo(tempArray, width * height);

            // for (int i = 0; i < width * height; i++)
            // {
            //     tempArray[i] = 255;
            // }

            // for (int i = 0; i < height; i++)
            // {
            //     if ((i + y) < height &&  (i + y) > 0)
            //     {
            //         for (int j = 0; j < width; j++)
            //         {
            //             if ((j + x ) < width  && (j + x) > 0)
            //             {
            //                 tempArray[j + x + (i + y) * width] = grayData[j + i * width];
            //             }
            //         }
            //     }
            // }

            // grayData = (byte[])tempArray.Clone();
            // //tempArray.CopyTo(grayData , width * height );
            // return Gray2Bitmap(grayData , width , height);

            Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
            System.Drawing.Imaging.BitmapData bmpData = curBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, curBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;
            int bytes = bmpData.Stride * curBitmap.Height;//图像数据
            byte[] grayValues = new byte[bytes];
            System.Runtime.InteropServices.Marshal.Copy(ptr, grayValues, 0, bytes);

            byte[] tempArray = new byte[bytes];
            //Array.Clear(tempArray, 0, bytes);
            for (int i = 0; i < bytes; i++)
            {
                tempArray[i] = 255;
            }

            for (int i = 0; i < curBitmap.Height; i++)
            {
                if ((i + y) < curBitmap.Height && (i + y) > 0)
                {

                    for (int j = 0; j < curBitmap.Width * 3; j += 3)
                    {
                        if ((j + x * 3) < curBitmap.Width * 3 && (j + x * 3) > 0)
                        {
                            tempArray[(j + x * 3) + (i + y) * bmpData.Stride] = grayValues[j + i * bmpData.Stride];
                            tempArray[(j + x * 3 + 1) + (i + y) * bmpData.Stride] = grayValues[j + 1 + i * bmpData.Stride];
                            tempArray[(j + x * 3 + 2) + (i + y) * bmpData.Stride] = grayValues[j + 2 + i * bmpData.Stride];
                        }
                    }
                }
            }

            grayValues = (byte[])tempArray.Clone();

            System.Runtime.InteropServices.Marshal.Copy(grayValues, 0, ptr, bytes);
            curBitmap.UnlockBits(bmpData);
            return true;
        }

        /// <summary>
        /// 图像镜像
        /// </summary>
        /// <param name="curBitmap">要转换的图像</param>
        /// <param name="flage">选择项</param>
        /// <returns></returns>
        public bool MirrorImage(Bitmap curBitmap, bool flage)
        {
            if (null == curBitmap)
            {

                return false;
            }

            Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
            System.Drawing.Imaging.BitmapData bmpData = curBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, curBitmap.PixelFormat);
            IntPtr ptr = bmpData.Scan0;
            //int bytes = curBitmap.Width * curBitmap.Height;
            int bytes = bmpData.Stride * curBitmap.Height;//内存区域大小，包括未使用的

            byte[] grayValues = new byte[bytes];
            System.Runtime.InteropServices.Marshal.Copy(ptr, grayValues, 0, bytes);

            //int halfWidth = curBitmap.Width / 2;
            //int halfHeight = curBitmap.Height / 2;
            int halfWidth = curBitmap.Width / 2;
            int halfHeight = curBitmap.Height / 2;

            byte[] temp = new byte[3];

            if (flage)
            {
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    for (int j = 0; j < halfWidth; j++)
                    {
                        //temp = grayValues[i * curBitmap.Width + j];
                        //grayValues[i * curBitmap.Width + j] = grayValues[(i + 1) * curBitmap.Width - 1 - j];
                        //grayValues[(i + 1) * curBitmap.Width - 1 - j] = temp;

                        temp[0] = grayValues[i * bmpData.Stride + j * 3];
                        temp[1] = grayValues[i * bmpData.Stride + j * 3 + 1];
                        temp[2] = grayValues[i * bmpData.Stride + j * 3 + 2];

                        grayValues[i * bmpData.Stride + j * 3] = grayValues[i * bmpData.Stride + curBitmap.Width * 3 - (j + 1) * 3];
                        grayValues[i * bmpData.Stride + j * 3 + 1] = grayValues[i * bmpData.Stride + curBitmap.Width * 3 - (j + 1) * 3 + 1];
                        grayValues[i * bmpData.Stride + j * 3 + 2] = grayValues[i * bmpData.Stride + curBitmap.Width * 3 - (j + 1) * 3 + 2];

                        grayValues[i * bmpData.Stride + curBitmap.Width * 3 - (j + 1) * 3] = temp[0];
                        grayValues[i * bmpData.Stride + curBitmap.Width * 3 - (j + 1) * 3 + 1] = temp[1];
                        grayValues[i * bmpData.Stride + curBitmap.Width * 3 - (j + 1) * 3 + 2] = temp[2];
                    }
                }
            }
            else
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    for (int j = 0; j < halfHeight; j++)
                    {
                        //temp = grayValues[j * curBitmap.Width + i];
                        //grayValues[j * curBitmap.Height + i] = grayValues[(curBitmap.Height - j - 1) * curBitmap.Width + i];
                        //grayValues[(curBitmap.Height - j - 1) * curBitmap.Width + i] = temp;

                        temp[0] = grayValues[j * bmpData.Stride + i * 3];
                        temp[1] = grayValues[j * bmpData.Stride + i * 3 + 1];
                        temp[2] = grayValues[j * bmpData.Stride + i * 3 + 2];

                        grayValues[j * bmpData.Stride + i * 3] = grayValues[(curBitmap.Height - j - 1) * bmpData.Stride + i * 3];
                        grayValues[j * bmpData.Stride + i * 3 + 1] = grayValues[(curBitmap.Height - j - 1) * bmpData.Stride + i * 3 + 1];
                        grayValues[j * bmpData.Stride + i * 3 + 2] = grayValues[(curBitmap.Height - j - 1) * bmpData.Stride + i * 3 + 2];

                        grayValues[(curBitmap.Height - j - 1) * bmpData.Stride + i * 3] = temp[0];
                        grayValues[(curBitmap.Height - j - 1) * bmpData.Stride + i * 3 + 1] = temp[1];
                        grayValues[(curBitmap.Height - j - 1) * bmpData.Stride + i * 3 + 2] = temp[2];
                    }
                }
            }
            System.Runtime.InteropServices.Marshal.Copy(grayValues, 0, ptr, bytes);
            curBitmap.UnlockBits(bmpData);
            return true;
        }

        /// <summary>
        /// 图像缩放
        /// </summary>
        /// <param name="curBitmap">要缩放的图像</param>
        /// <param name="x">横向缩放量</param>
        /// <param name="y">纵向所放量</param>
        /// <param name="flag">灰度插值方式 ：邻近插值（1）和双线性插值（0）</param>
        /// <returns></returns>
        public bool ZoomImage(ref Bitmap curBitmap, int x, int y, bool flag)
        {
            if (null == curBitmap)
            {
                return false;
            }
            int width = curBitmap.Width;
            int height = curBitmap.Height;

            byte[] grayData = new byte[width * height];
            byte[] tempArray = new byte[width * height];
            grayData = GetBitmapGrayData_Pointer(curBitmap);//得到图像灰度值

            //  tempArray = (byte[])grayData.Clone();

            int halfWidth = curBitmap.Width / 2;
            int halfHeight = curBitmap.Height / 2;

            int xz = 0;
            int yz = 0;
            int tempWidth = 0;
            int tempHeight = 0;


            for (int i = 0; i < width * height; i++)
            {
                tempArray[i] = 255;
            }
            if (flag == true)
            {
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    for (int j = 0; j < curBitmap.Width; j++)
                    {
                        tempHeight = halfHeight - i;
                        tempWidth = halfWidth - j;
                        if (tempWidth > 0)
                        {
                            xz = (int)(tempWidth / x + 0.5);

                            /**************************
                             * 
                             * x = h - (h - i)/ x;
                             * 
                             * ***********************
                             */
                        }
                        else
                        {
                            xz = (int)(tempWidth / x - 0.5);
                        }
                        if (tempHeight > 0)
                        {
                            yz = (int)(tempHeight / y + 0.5);
                        }
                        else
                        {
                            yz = (int)(tempHeight / y - 0.5);
                        }

                        tempWidth = halfWidth - xz;
                        tempHeight = halfHeight - yz;
                        if (tempWidth < 0 || tempWidth >= curBitmap.Width || tempHeight < 0 || tempHeight >= curBitmap.Height)
                        {
                            tempArray[i * curBitmap.Width + j] = 255;
                        }
                        else
                        {
                            //tempArray[i * curBitmap.Width + j] = grayData[tempHeight * curBitmap.Width + tempWidth];
                            tempArray[tempHeight * curBitmap.Width + tempWidth] = grayData[i * curBitmap.Width + j];
                        }
                    }
                }
            }
            else
            {
                double tempX, tempY, p, q;
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    for (int j = 0; j < curBitmap.Width; j++)
                    {
                        tempHeight = i - halfHeight;
                        tempWidth = j - halfWidth;
                        tempX = tempWidth / x;
                        tempY = tempHeight / y;
                        if (tempWidth > 0)
                        {
                            xz = (int)tempX;
                        }
                        else
                        {
                            xz = (int)(tempX - 1);
                        }
                        if (tempHeight > 0)
                        {
                            yz = (int)tempY;
                        }
                        else
                        {
                            yz = (int)(tempY - 1);
                        }

                        p = tempX - xz;
                        q = tempY - yz;
                        tempWidth = xz + halfWidth;
                        tempHeight = yz + halfHeight;
                        if (tempWidth < 0 || (tempWidth + 1) >= curBitmap.Width || tempHeight < 0 || (tempHeight + 1) >= curBitmap.Height)
                        {
                            tempArray[i * curBitmap.Width + j] = 255;
                        }
                        else
                        {
                            tempArray[i * curBitmap.Width + j] = (byte)((1.0 - q) * ((1.0 - p) * grayData[tempHeight * curBitmap.Width + tempWidth] + p * grayData[tempHeight * curBitmap.Width + tempWidth + 1]) +
                                q * ((1.0 - p) * grayData[(tempHeight + 1) * curBitmap.Width + tempWidth] + p * grayData[(tempHeight + 1) * curBitmap.Width + 1 + tempWidth]));
                        }
                    }
                }

            }

            grayData = (byte[])tempArray.Clone();
            curBitmap = Gray2Bitmap(grayData, width, height);
            //return grayData;
            return true;

        }

        /// <summary>
        /// 图像旋转
        /// </summary>
        /// <param name="curBitmap">要旋转的图像</param>
        /// <param name="angle">旋转角度（°）</param>
        /// <returns></returns>
        public bool Rotation(ref Bitmap curBitmap, int angle)
        {
            if (null == curBitmap)
            {
                return false;
            }

            int width = curBitmap.Width;
            int height = curBitmap.Height;
            double degree = angle * Math.PI / 180.0;       //化为弧度制；
            double mySin = Math.Sin(degree);
            double myCos = Math.Cos(degree);


            byte[] grayData = new byte[width * height];   //接收原始图片的灰度值；
            byte[] tempArray = new byte[width * height];  //进行旋转式的操作数组；

            grayData = GetBitmapGrayData_Pointer(curBitmap);

            for (int i = 0; i < width * height; i++)
            {
                tempArray[i] = 255;
            }

            /****************
             * 
             * y1 = y0 * cos(angle) - x0 * sin(angle);
             * x1 = x0 * cos(angle) - y0 * sin(angle);
             * 
             * *************
             */
            int xr = 0;
            int yr = 0;
            int tempWidth = 0;
            int tempHeight = 0;
            int halfWidth = (int)(curBitmap.Width / 2);
            int halfHeight = (int)(curBitmap.Height / 2);

            double tempX, tempY, p, q;
            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    tempHeight = i - halfHeight;
                    tempWidth = j - halfWidth;//相对于（halfWidth , halfHeight）

                    tempX = tempWidth * myCos - tempHeight * mySin;
                    tempY = tempHeight * myCos + tempWidth * mySin; //相对坐标变换后的左边（tempX , temY）
                    if (tempWidth > 0)
                    {
                        xr = (int)tempX;
                    }
                    else
                    {
                        xr = (int)(tempX - 1);
                    }
                    if (tempHeight > 0)
                    {
                        yr = (int)tempY;
                    }
                    else
                    {
                        yr = (int)(tempY - 1);
                    }

                    p = tempX - xr;
                    q = tempY - yr;
                    tempWidth = xr + halfWidth;
                    tempHeight = yr + halfHeight;
                    if (tempWidth < 0 || (tempWidth + 1) >= curBitmap.Width || tempHeight < 0 || (tempHeight + 1) >= curBitmap.Height)
                    {
                        tempArray[i * curBitmap.Width + j] = 255;
                    }
                    else
                    {
                        tempArray[i * curBitmap.Width + j] = (byte)((1.0 - q) * ((1.0 - p) * grayData[tempHeight * curBitmap.Width + tempWidth]
                            + p * grayData[tempHeight * curBitmap.Width + tempWidth + 1])
                            + q * ((1.0 - p) * grayData[(tempHeight + 1) * curBitmap.Width + tempWidth]
                            + p * grayData[(tempHeight + 1) * curBitmap.Width + 1 + tempWidth]));
                    }

                }
            }
            grayData = (byte[])tempArray.Clone();
            curBitmap = Gray2Bitmap(grayData, width, height);

            return true;
        }

        /// <summary>
        /// 图像腐蚀
        /// </summary>
        /// <param name="grayData">灰度数据</param>
        /// <param name="width">图像宽度</param>
        /// <param name="height">图像高度</param>
        /// <param name="style">元素结构风格：1水平，2垂直，3十字，4方形</param>
        /// <param name="form">元素组成样式3和5</param>
        /// <returns></returns>
        public bool ImageCorrosion(ref byte[] grayData, int width, int height, int style, int form)
        {
            if (null == grayData)
            {
                return false;
            }
            byte[] ployData = new byte[width * height];
            byte max = 0;

            for (int i = 0; i < width * height; i++)
            {
                if (max < grayData[i])
                {
                    max = grayData[i];
                }
            }

            for (int i = 0; i < width * height; i++)
            {
                ployData[i] = max;
            }

            switch (style)
            {
                case 1:
                    {
                        int f = form / 2;
                        for (int h = 0; h < height; h++)
                        {
                            for (int w = 0; w < width; w++)
                            {
                                if (w - f < 0 || w + f > width - 1)
                                {
                                    continue;
                                }
                                else
                                {
                                    byte maxelement = 0;
                                    for (int j = 0; j < form; j++)
                                    {
                                        if (maxelement < grayData[h * width + w - f + j])
                                        {
                                            maxelement = grayData[h * width + w - f + j];
                                        }
                                    }
                                    ployData[h * width + w] = maxelement;
                                }
                            }
                        }
                        grayData = (byte[])ployData.Clone();
                        break;
                    }

                case 2:
                    {
                        int f = form / 2;
                        for (int h = 0; h < height; h++)
                        {
                            for (int w = 0; w < width; w++)
                            {
                                if (h - f < 0 || h + f > height - 1)
                                {
                                    continue;
                                }
                                else
                                {
                                    byte maxelement = 0;
                                    for (int j = 0; j < form; j++)
                                    {
                                        if (maxelement < grayData[(h - f + j) * width + w])
                                        {
                                            maxelement = grayData[(h - f + j) * width + w];
                                        }
                                    }
                                    ployData[h * width + w] = maxelement;
                                }
                            }
                        }
                        grayData = (byte[])ployData.Clone();
                        break;
                    }

                case 3:
                    {
                        int f = form / 2;
                        for (int h = 0; h < height; h++)
                        {
                            for (int w = 0; w < width; w++)
                            {
                                if (h - f < 0 || h + f > height - 1 || w - f < 0 || w + f > width - 1)
                                {
                                    continue;
                                }
                                else
                                {
                                    byte maxelement = 0;
                                    for (int j = 0; j < form; j++)
                                    {
                                        if (maxelement < grayData[(h - f + j) * width + w])
                                        {
                                            maxelement = grayData[(h - f + j) * width + w];
                                        }

                                        if (maxelement < grayData[h * width + w - f + j])
                                        {
                                            maxelement = grayData[h * width + w - f + j];
                                        }
                                    }
                                    ployData[h * width + w] = maxelement;
                                }
                            }
                        }
                        grayData = (byte[])ployData.Clone();
                        break;
                    }
                case 4:
                    {
                        int f = form / 2;
                        for (int h = 0; h < height; h++)
                        {
                            for (int w = 0; w < width; w++)
                            {
                                if (h - f < 0 || h + f > height - 1 || w - f < 0 || w + f > width - 1)
                                {
                                    continue;
                                }
                                else
                                {
                                    byte maxelement = 0;
                                    for (int j = 0; j < form; j++)
                                    {
                                        for (int k = 0; k < form; k++)
                                        {
                                            if (maxelement < grayData[(h - f + j) * width + w - f + k])
                                            {
                                                maxelement = grayData[(h - f + j) * width + w - f + k];
                                            }
                                        }
                                    }
                                    ployData[h * width + w] = maxelement;
                                }
                            }
                        }
                        grayData = (byte[])ployData.Clone();
                        break;
                    }
                default:
                    MessageBox.Show("错误的元素！");
                    break;
            }


            return true;
        }


        /// <summary>
        /// 元素膨胀
        /// </summary>
        /// <param name="grayData">灰度数据</param>
        /// <param name="width">图像宽度</param>
        /// <param name="height">图像高度</param>
        /// <param name="flag">所选这的元素结构</param>
        /// <returns></returns>
        public bool ImageExpansion(ref byte[] grayData, int width, int height, int stlye, int form)
        {
            if (null == grayData)
            {
                return false;
            }
            byte[] ployData = new byte[width * height];
            byte max = 0;

            for (int i = 0; i < width * height; i++)
            {
                if (max < grayData[i])
                {
                    max = grayData[i];
                }
                //if (min > grayData[i])
                //{
                //    min = grayData[i];
                //}
            }

            for (int i = 0; i < width * height; i++)
            {
                ployData[i] = max;
            }

            switch (stlye)
            {
                case 1:
                    {
                        int f = form / 2;
                        for (int h = 0; h < height; h++)
                        {
                            for (int w = 0; w < width; w++)
                            {
                                if (w - f < 0 || w + f > width - 1)
                                {
                                    continue;
                                }
                                else
                                {
                                    byte minelement = 255;
                                    for (int j = 0; j < form; j++)
                                    {
                                        if (minelement > grayData[h * width + w - f + j])
                                        {
                                            minelement = grayData[h * width + w - f + j];
                                        }
                                    }
                                    ployData[h * width + w] = minelement;
                                }
                            }
                        }
                        grayData = (byte[])ployData.Clone();
                        break;
                    }
                case 2:
                    {
                        int f = form / 2;
                        for (int h = 0; h < height; h++)
                        {
                            for (int w = 0; w < width; w++)
                            {
                                if (h - f < 0 || h + f > height - 1)
                                {
                                    continue;
                                }
                                else
                                {
                                    byte minelement = 255;
                                    for (int j = 0; j < form; j++)
                                    {
                                        if (minelement > grayData[(h - f + j) * width + w])
                                        {
                                            minelement = grayData[(h - f + j) * width + w];
                                        }
                                    }
                                    ployData[h * width + w] = minelement;
                                }
                            }
                        }
                        grayData = (byte[])ployData.Clone();
                        break;
                    }
                case 3:
                    {
                        int f = form / 2;
                        for (int h = 0; h < height; h++)
                        {
                            for (int w = 0; w < width; w++)
                            {
                                if (h - f < 0 || h + f > height - 1 || w - f < 0 || w + f > width - 1)
                                {
                                    continue;
                                }
                                else
                                {
                                    byte minelement = 255;
                                    for (int j = 0; j < form; j++)
                                    {
                                        if (minelement > grayData[(h - f + j) * width + w])
                                        {
                                            minelement = grayData[(h - f + j) * width + w];
                                        }

                                        if (minelement > grayData[h * width + w - f + j])
                                        {
                                            minelement = grayData[h * width + w - f + j];
                                        }
                                    }
                                    ployData[h * width + w] = minelement;
                                }
                            }
                        }
                        grayData = (byte[])ployData.Clone();
                        break;
                    }
                case 4:
                    {
                        int f = form / 2;
                        for (int h = 0; h < height; h++)
                        {
                            for (int w = 0; w < width; w++)
                            {
                                if (h - f < 0 || h + f > height - 1 || w - f < 0 || w + f > width - 1)
                                {
                                    continue;
                                }
                                else
                                {
                                    byte minelement = 255;
                                    for (int j = 0; j < form; j++)
                                    {
                                        for (int k = 0; k < form; k++)
                                        {
                                            if (minelement > grayData[(h - f + j) * width + w - f + k])
                                            {
                                                minelement = grayData[(h - f + j) * width + w - f + k];
                                            }
                                        }
                                    }
                                    ployData[h * width + w] = minelement;
                                }
                            }
                        }
                        grayData = (byte[])ployData.Clone();
                        break;
                    }
                default:
                    MessageBox.Show("错误的元素！");
                    break;
            }
            return true;
        }

        /// <summary>
        /// 均值滤波
        /// </summary>
        /// <param name="grayValues">图像灰度值</param>
        /// <param name="Width">图像宽度</param>
        /// <param name="Height">图像高度</param>
        /// <param name="sideLength">模板边长（3,5,7三种选择）</param>
        /// <returns></returns>
        public bool MeanFilter(ref byte[] grayValues, int Width, int Height, byte sideLength)
        {
            if (grayValues == null)
            {
                return false;
            }

            int bytes = Width * Height;

            byte[] tempArray = new byte[bytes];

            byte halfLength = (byte)(sideLength / 2);

            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    switch (sideLength)
                    {
                        case 3:
                            tempArray[i * Width + j] = (byte)((grayValues[i * Width + j] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + j] +
                                grayValues[((i + 1) % Height) * Width + j] +
                                grayValues[i * Width + ((j + 1) % Width)] +
                                grayValues[i * Width + ((Math.Abs(j - 1)) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + ((Math.Abs(j - 1)) % Width)] +
                                grayValues[((i + 1) % Height) * Width + ((Math.Abs(j - 1)) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((i + 1) % Height) * Width + ((j + 1) % Width)]) / 9);
                            break;
                        case 5:
                            tempArray[i * Width + j] = (byte)((grayValues[((Math.Abs(i - 2)) % Height) * Width + (Math.Abs(j - 2)) % Width] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + (Math.Abs(j - 1)) % Width] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + j] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + j] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[i * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[i * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[i * Width + j] +
                                grayValues[i * Width + ((j + 1) % Width)] +
                                grayValues[i * Width + ((j + 2) % Width)] +
                                grayValues[((i + 2) % Height) * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[((i + 2) % Height) * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[((i + 2) % Height) * Width + j] +
                                grayValues[((i + 2) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((i + 2) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[((i + 1) % Height) * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[((i + 1) % Height) * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[((i + 1) % Height) * Width + j] +
                                grayValues[((i + 1) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((i + 1) % Height) * Width + ((j + 2) % Width)]) / 25);

                            break;
                        case 7:
                            tempArray[i * Width + j] = (byte)((grayValues[((Math.Abs(i - 2)) % Height) * Width + (Math.Abs(j - 2)) % Width] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + (Math.Abs(j - 1)) % Width] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + j] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + j] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[i * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[i * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[i * Width + j] +
                                grayValues[i * Width + ((j + 1) % Width)] +
                                grayValues[i * Width + ((j + 2) % Width)] +
                                grayValues[((i + 2) % Height) * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[((i + 2) % Height) * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[((i + 2) % Height) * Width + j] +
                                grayValues[((i + 2) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((i + 2) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[((i + 1) % Height) * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[((i + 1) % Height) * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[((i + 1) % Height) * Width + j] +
                                grayValues[((i + 1) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((i + 1) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[((Math.Abs(i - 3)) % Height) * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[((Math.Abs(i - 3)) % Height) * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[((Math.Abs(i - 3)) % Height) * Width + j] +
                                grayValues[((Math.Abs(i - 3)) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((Math.Abs(i - 3)) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[((Math.Abs(i - 3)) % Height) * Width + (Math.Abs(j - 3) % Width)] +
                                grayValues[((Math.Abs(i - 3)) % Height) * Width + ((j + 3) % Width)] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + ((j + 3) % Width)] +
                                grayValues[((i + 2) % Height) * Width + ((j + 3) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + ((j + 3) % Width)] +
                                grayValues[((i + 1) % Height) * Width + ((j + 3) % Width)] +
                                grayValues[i * Width + ((j + 3) % Width)] +
                                grayValues[i * Width + (Math.Abs(j - 3) % Width)] +
                                grayValues[((i + 1) % Height) * Width + (Math.Abs(j - 3) % Width)] +
                                grayValues[((Math.Abs(i - 1)) % Height) * Width + (Math.Abs(j - 3) % Width)] +
                                grayValues[((i + 2) % Height) * Width + (Math.Abs(j - 3) % Width)] +
                                grayValues[((Math.Abs(i - 2)) % Height) * Width + (Math.Abs(j - 3) % Width)] +
                                grayValues[((i + 3) % Height) * Width + ((j + 1) % Width)] +
                                grayValues[((i + 3) % Height) * Width + ((j + 2) % Width)] +
                                grayValues[((i + 3) % Height) * Width + (Math.Abs(j - 2) % Width)] +
                                grayValues[((i + 3) % Height) * Width + (Math.Abs(j - 1) % Width)] +
                                grayValues[((i + 3) % Height) * Width + j] +
                                grayValues[((i + 3) % Height) * Width + ((j + 3) % Width)] +
                                grayValues[((i + 3) % Height) * Width + (Math.Abs(j - 3) % Width)]) / 49);

                            break;
                        default:
                            MessageBox.Show("无效！");
                            break;
                    }
                }
            }
            grayValues = (byte[])tempArray.Clone();

            return true;
        }

        public bool MedianFilter(ref byte[] grayValues, Bitmap curBitmap, int Width, int Height, byte sideLength)
        {
            if (grayValues == null)
            {
                return false;
            }

            int bytes = Width * Height;

            byte[] tempArray = new byte[bytes];

            byte halfLength = (byte)(sideLength / 2);

            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    switch (sideLength)
                    {
                        case 3:
                            {
                                byte[] sortArray = new byte[] {grayValues[i * curBitmap.Width + j],
                                    grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j],
                                    grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j],
                                    grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                    grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)],
                                    grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)],
                                    grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)],
                                    grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                    grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)]};
                                Sort(sortArray);
                                tempArray[i * curBitmap.Width + j] = sortArray[4];
                            }
                            break;

                        case 5:
                            byte[] sArray = new byte[] {grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2)) % curBitmap.Width],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1)) % curBitmap.Width],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + j],
                                            grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)]};
                            Sort(sArray);
                            tempArray[i * curBitmap.Width + j] = sArray[12];
                            break;
                        case 7:
                            byte[] srArray = new byte[] {grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2)) % curBitmap.Width],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1)) % curBitmap.Width],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + j],
                                            grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + ((j + 3) % curBitmap.Width)],
                                            grayValues[i * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)],
                                            grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)],
                                            grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)],
                                            grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)],
                                            grayValues[((i + 3) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)],
                                            grayValues[((i + 3) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)],
                                            grayValues[((i + 3) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)],
                                            grayValues[((i + 3) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)],
                                            grayValues[((i + 3) % curBitmap.Height) * curBitmap.Width + j],
                                            grayValues[((i + 3) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)],
                                            grayValues[((i + 3) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)]};
                            Sort(srArray);
                            tempArray[i * curBitmap.Width + j] = srArray[24];
                            break;
                        default:
                            MessageBox.Show("无效！");
                            break;
                    }
                }
            }
            grayValues = (byte[])tempArray.Clone();

            return true;
        }

        /// <summary>
        /// 高斯低通滤波
        /// </summary>
        /// <param name="inputImage">处理前的图像数据</param>
        /// <param name="outputImage">处理后的图像数据</param>
        /// <param name="sigma"></param>
        public void gaussSmooth(double[] inputImage, out double[] outputImage, double sigma)
        {
            double std2 = 2 * sigma * sigma;
            int radius = Convert.ToInt16(Math.Ceiling(3 * sigma));
            int filterWidth = 2 * radius + 1;
            double[] filter = new double[filterWidth];
            outputImage = new double[inputImage.Length];
            int length = Convert.ToInt16(Math.Sqrt(inputImage.Length));
            double[] tempImage = new double[inputImage.Length];

            double sum = 0;
            for (int i = 0; i < filterWidth; i++)
            {
                int xx = (i - radius) * (i - radius);
                filter[i] = Math.Exp(-xx / std2);
                sum += filter[i];
            }
            for (int i = 0; i < filterWidth; i++)
            {
                filter[i] = filter[i] / sum;
            }

            for (int i = 0; i < length; i++)
            {
                for (int j = 0; j < length; j++)
                {
                    double temp = 0;
                    for (int k = -radius; k <= radius; k++)
                    {
                        int rem = (Math.Abs(j + k)) % length;
                        temp += inputImage[i * length + rem] * filter[k + radius];
                    }
                    tempImage[i * length + j] = temp;
                }
            }
            for (int j = 0; j < length; j++)
            {
                for (int i = 0; i < length; i++)
                {
                    double temp = 0;
                    for (int k = -radius; k <= radius; k++)
                    {
                        int rem = (Math.Abs(i + k)) % length;
                        temp += tempImage[rem * length + j] * filter[k + radius];
                    }
                    outputImage[i * length + j] = temp;
                }
            }
        }


        private void Sort(byte[] list)
        {
            int min;
            for (int i = 0; i < list.Length - 1; i++)
            {
                min = i;
                for (int j = i + 1; j < list.Length; j++)
                {
                    if (list[j] < list[min])
                        min = j;
                }
                byte t = list[min];
                list[min] = list[i];
                list[i] = t;
            }
        }



        /************************************************************************/
        /*      
         * 小波分析    部分
         * 
         */
        /************************************************************************/

        /// <summary>
        /// 
        /// </summary>
        /// <param name="curBitmap"></param>
        /// <param name="grayValues"></param>
        /// <param name="dwtSeries"></param>
        /// <param name="flagFilter"></param>
        /// <param name="thresholding"></param>
        public void WaveletFilter(Bitmap curBitmap, ref byte[] grayValues, byte dwtSeries, byte flagFilter, byte thresholding)
        {
            if (null == curBitmap)
            {
                return;
            }

            if (null == grayValues)
            {
                return;
            }
            Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
            System.Drawing.Imaging.BitmapData bmpData = curBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, curBitmap.PixelFormat);
            IntPtr ptr = bmpData.Scan0;
            int bytes = curBitmap.Width * curBitmap.Height;

            double[] tempA = new double[bytes];
            double[] tempB = new double[bytes];
            for (int i = 0; i < bytes; i++)
            {
                tempA[i] = Convert.ToDouble(grayValues[i]);
            }

            double[] lowFilter = null;
            double[] highFilter = null;

            switch (flagFilter & 0x0f)
            {
                case 0://haar
                    lowFilter = new double[] { 0.70710678118655, 0.70710678118655 };
                    break;
                case 1://daubechies2
                    lowFilter = new double[] { 0.48296291314453, 0.83651630373780, 0.22414386804201, -0.12940952255126 };
                    break;
                case 2://daubechies3
                    lowFilter = new double[] { 0.33267055295008, 0.80689150931109, 0.45987750211849, -0.13501102001025, -0.08544127388203, 0.03522629188571 };
                    break;
                case 3://daubechies4
                    lowFilter = new double[] { 0.23037781330889, 0.71484657055291, 0.63088076792986, -0.02798376941686, -0.18703481171909, 0.03084138183556, 0.03288301166689, -0.01059740178507 };
                    break;
                case 4://daubechies5
                    lowFilter = new double[] { 0.16010239797419, 0.60382926979719, 0.72430852843778, 0.13842814590132, -0.24229488706638, -0.03224486958464, 0.07757149384005, -0.00624149021280, -0.01258075199908, 0.00333572528547 };
                    break;
                case 5://daubechies6
                    lowFilter = new double[] { 0.11154074335011, 0.49462389039845, 0.75113390802110, 0.31525035170920, -0.22626469396544, -0.12976686756726, 0.09750160558732, 0.02752286553031, -0.03158203931849, 0.00055384220116, 0.00477725751195, -0.00107730108531 };
                    break;
                default:
                    MessageBox.Show("无效！");
                    break;
            }

            highFilter = new double[lowFilter.Length];
            for (int i = 0; i < lowFilter.Length; i++)
            {
                highFilter[i] = Math.Pow(-1, i) * lowFilter[lowFilter.Length - 1 - i];
            }

            for (int k = 0; k < dwtSeries; k++)
            {
                int coef = (int)Math.Pow(2, k);
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    if (i < curBitmap.Height / coef)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            if (j < curBitmap.Width / coef)
                            {
                                tempB[i * curBitmap.Width / coef + j] = tempA[i * curBitmap.Width + j];
                            }
                        }
                    }
                }
                wavelet2D(ref tempB, curBitmap, lowFilter, highFilter, coef);
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    if (i < curBitmap.Height / coef)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            if (j < curBitmap.Width / coef)
                            {
                                tempA[i * curBitmap.Width + j] = tempB[i * curBitmap.Width / coef + j];
                            }
                        }
                    }
                }

                if ((flagFilter & 0xf0) == 0x10)
                {
                    for (int l = 0; l < bytes; l++)
                    {
                        if (tempA[l] < thresholding && tempA[l] > -thresholding)
                            tempA[l] = 0;
                    }
                }
                else
                {
                    for (int l = 0; l < bytes; l++)
                    {
                        if (tempA[l] >= thresholding)
                            tempA[l] = tempA[l] - thresholding;
                        else
                        {
                            if (tempA[l] <= -thresholding)
                                tempA[l] = tempA[l] + thresholding;
                            else
                                tempA[l] = 0;
                        }
                    }
                }
            }

            for (int k = dwtSeries - 1; k >= 0; k--)
            {
                int coef = (int)Math.Pow(2, k);
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    if (i < curBitmap.Height / coef)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            if (j < curBitmap.Width / coef)
                            {
                                tempB[i * curBitmap.Width / coef + j] = tempA[i * curBitmap.Width + j];
                            }
                        }
                    }
                }
                iwavelet2D(ref tempB, curBitmap, lowFilter, highFilter, coef);
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    if (i < curBitmap.Height / coef)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            if (j < curBitmap.Width / coef)
                            {
                                tempA[i * curBitmap.Width + j] = tempB[i * curBitmap.Width / coef + j];
                            }
                        }
                    }
                }
            }

            for (int i = 0; i < bytes; i++)
            {
                if (tempA[i] >= 255)
                    tempA[i] = 255;
                if (tempA[i] <= 0)
                    tempA[i] = 0;
                grayValues[i] = Convert.ToByte(tempA[i]);
            }

        }

        public void wavelet1D(double[] scl0, double[] p, double[] q, out double[] scl1, out double[] wvl1)
        {
            int temp;
            int sclLen = scl0.Length;
            int pLen = p.Length;
            scl1 = new double[sclLen / 2];
            wvl1 = new double[sclLen / 2];

            for (int i = 0; i < sclLen / 2; i++)
            {
                scl1[i] = 0.0;
                wvl1[i] = 0.0;
                for (int j = 0; j < pLen; j++)
                {
                    temp = (j + i * 2) % sclLen;
                    scl1[i] += p[j] * scl0[temp];
                    wvl1[i] += q[j] * scl0[temp];
                }
            }
        }

        public void iwavelet1D(out double[] scl0, double[] p, double[] q, double[] scl1, double[] wvl1)
        {
            int temp;
            int sclLen = scl1.Length;
            int pLen = p.Length;
            scl0 = new double[sclLen * 2];

            for (int i = 0; i < sclLen; i++)
            {
                scl0[2 * i + 1] = 0.0;
                scl0[2 * i] = 0.0;
                for (int j = 0; j < pLen / 2; j++)
                {
                    temp = (i - j + sclLen) % sclLen;
                    scl0[2 * i + 1] += p[2 * j + 1] * scl1[temp] + q[2 * j + 1] * wvl1[temp];
                    scl0[2 * i] += p[2 * j] * scl1[temp] + q[2 * j] * wvl1[temp];
                }
            }
        }

        public void wavelet2D(ref double[] dataImage, Bitmap curBitmap, double[] p, double[] q, int series/*out double[] scl1, out double[] wvl1*/)
        {
            double[] s = new double[curBitmap.Width / series];
            double[] s1 = new double[curBitmap.Width / (2 * series)];
            double[] w1 = new double[curBitmap.Width / (2 * series)];
            for (int i = 0; i < curBitmap.Height / series; i++)
            {
                for (int j = 0; j < curBitmap.Width / series; j++)
                {
                    s[j] = dataImage[i * curBitmap.Width / series + j];
                }
                wavelet1D(s, p, q, out s1, out w1);

                for (int j = 0; j < curBitmap.Width / series; j++)
                {
                    if (j < curBitmap.Width / (2 * series))
                        dataImage[i * curBitmap.Width / series + j] = s1[j];
                    else
                        dataImage[i * curBitmap.Width / series + j] = w1[j - curBitmap.Width / (2 * series)];
                }
            }

            for (int i = 0; i < curBitmap.Width / series; i++)
            {
                for (int j = 0; j < curBitmap.Height / series; j++)
                {
                    s[j] = dataImage[j * curBitmap.Width / series + i];
                }
                wavelet1D(s, p, q, out s1, out w1);
                for (int j = 0; j < curBitmap.Height / series; j++)
                {
                    if (j < curBitmap.Height / (2 * series))
                        dataImage[j * curBitmap.Width / series + i] = s1[j];
                    else
                        dataImage[j * curBitmap.Width / series + i] = w1[j - curBitmap.Height / (2 * series)];
                }
            }
        }

        public void iwavelet2D(ref double[] dataImage, Bitmap curBitmap, double[] p, double[] q, int series)
        {
            double[] s = new double[curBitmap.Width / series];
            double[] s1 = new double[curBitmap.Width / (2 * series)];
            double[] w1 = new double[curBitmap.Width / (2 * series)];
            for (int i = 0; i < curBitmap.Width / series; i++)
            {
                for (int j = 0; j < curBitmap.Height / series; j++)
                {
                    if (j < curBitmap.Height / (2 * series))
                        s1[j] = dataImage[j * curBitmap.Width / series + i];
                    else
                        w1[j - curBitmap.Height / (2 * series)] = dataImage[j * curBitmap.Width / series + i];
                }
                iwavelet1D(out s, p, q, s1, w1);
                for (int j = 0; j < curBitmap.Height / series; j++)
                {
                    dataImage[j * curBitmap.Width / series + i] = s[j];
                }
            }
            for (int i = 0; i < curBitmap.Height / series; i++)
            {
                for (int j = 0; j < curBitmap.Width / series; j++)
                {
                    if (j < curBitmap.Width / (2 * series))
                        s1[j] = dataImage[i * curBitmap.Width / series + j];
                    else
                        w1[j - curBitmap.Width / (2 * series)] = dataImage[i * curBitmap.Width / series + j];
                }
                iwavelet1D(out s, p, q, s1, w1);
                for (int j = 0; j < curBitmap.Width / series; j++)
                {
                    dataImage[i * curBitmap.Width / series + j] = s[j];
                }
            }
        }


        /************************************************************************/
        /*  
         * 灰度 形态学部分
         */
        /************************************************************************/

        /// <summary>
        /// 灰度形态学膨胀运算
        /// </summary>
        /// <param name="grayImage">图像灰度数据</param>
        /// <param name="se">结构元素限制为5*5的方阵</param>
        /// <param name="tHeight">图像高度</param>
        /// <param name="tWidth">图像宽度</param>
        /// <returns></returns>
        public byte[] ImageGrayDelation(byte[] grayImage, byte[] se, int tHeight, int tWidth)
        {
            byte[] tempImage = new byte[grayImage.Length];

            for (int i = 0; i < tHeight; i++)
            {
                for (int j = 0; j < tWidth; j++)
                {
                    int[] cou = new int[]{grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + (Math.Abs(j - 2)) % tWidth] * se[0],
                                        grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + (Math.Abs(j - 1)) % tWidth] * se[1],
                                        grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + j] * se[2],
                                        grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + ((j + 1) % tWidth)] * se[3],
                                        grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + ((j + 2) % tWidth)] * se[4],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + (Math.Abs(j - 2) % tWidth)] * se[5],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + (Math.Abs(j - 1) % tWidth)] * se[6],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + j] * se[7],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + ((j + 1) % tWidth)] * se[8],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + ((j + 2) % tWidth)] * se[9],
                                        grayImage[i * tWidth + (Math.Abs(j - 2) % tWidth)] * se[10],
                                        grayImage[i * tWidth + (Math.Abs(j - 1) % tWidth)] * se[11],
                                        grayImage[i * tWidth + j] * se[12],
                                        grayImage[i * tWidth + ((j + 1) % tWidth)] * se[13],
                                        grayImage[i * tWidth + ((j + 2) % tWidth)] * se[14],
                                        grayImage[((i + 1) % tHeight) * tWidth + (Math.Abs(j - 2) % tWidth)] * se[15],
                                        grayImage[((i + 1) % tHeight) * tWidth + (Math.Abs(j - 1) % tWidth)] * se[16],
                                        grayImage[((i + 1) % tHeight) * tWidth + j] * se[17],
                                        grayImage[((i + 1) % tHeight) * tWidth + ((j + 1) % tWidth)] * se[18],
                                        grayImage[((i + 1) % tHeight) * tWidth + ((j + 2) % tWidth)] * se[19],
                                        grayImage[((i + 2) % tHeight) * tWidth + (Math.Abs(j - 2) % tWidth)] * se[20],
                                        grayImage[((i + 2) % tHeight) * tWidth + (Math.Abs(j - 1) % tWidth)] * se[21],
                                        grayImage[((i + 2) % tHeight) * tWidth + j] * se[22],
                                        grayImage[((i + 2) % tHeight) * tWidth + ((j + 1) % tWidth)] * se[23],
                                        grayImage[((i + 2) % tHeight) * tWidth + ((j + 2) % tWidth)] * se[24]};
                    int maxim = cou[0];
                    for (int k = 1; k < 25; k++)
                    {
                        if (cou[k] > maxim)
                        {
                            maxim = cou[k];
                        }
                    }
                    tempImage[i * tWidth + j] = (byte)maxim;
                }
            }

            return tempImage;
        }

        /// <summary>
        /// 灰度形态学腐蚀运算
        /// </summary>
        /// <param name="grayImage">图像灰度数据</param>
        /// <param name="se">结构元素限制为5*5的方阵</param>
        /// <param name="tHeight">图像高度</param>
        /// <param name="tWidth">图像宽度</param>
        /// <returns></returns>
        public byte[] ImageGrayErode(byte[] grayImage, byte[] se, int tHeight, int tWidth)
        {
            byte[] tempImage = new byte[grayImage.Length];

            byte[] tempSe = new byte[25];
            tempSe = (byte[])se.Clone();
            for (int k = 0; k < 25; k++)
            {
                if (tempSe[k] == 0)
                    tempSe[k] = 255;
            }
            for (int i = 0; i < tHeight; i++)
            {
                for (int j = 0; j < tWidth; j++)
                {
                    int[] cou = new int[]{grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + (Math.Abs(j - 2)) % tWidth] * tempSe[0],
                                        grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + (Math.Abs(j - 1)) % tWidth] * tempSe[1],
                                        grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + j] * tempSe[2],
                                        grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + ((j + 1) % tWidth)] * tempSe[3],
                                        grayImage[((Math.Abs(i - 2)) % tHeight) * tWidth + ((j + 2) % tWidth)] * tempSe[4],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + (Math.Abs(j - 2) % tWidth)] * tempSe[5],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + (Math.Abs(j - 1) % tWidth)] * tempSe[6],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + j] * tempSe[7],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + ((j + 1) % tWidth)] * tempSe[8],
                                        grayImage[((Math.Abs(i - 1)) % tHeight) * tWidth + ((j + 2) % tWidth)] * tempSe[9],
                                        grayImage[i * tWidth + (Math.Abs(j - 2) % tWidth)] * tempSe[10],
                                        grayImage[i * tWidth + (Math.Abs(j - 1) % tWidth)] * tempSe[11],
                                        grayImage[i * tWidth + j] * tempSe[12],
                                        grayImage[i * tWidth + ((j + 1) % tWidth)] * tempSe[13],
                                        grayImage[i * tWidth + ((j + 2) % tWidth)] * tempSe[14],
                                        grayImage[((i + 1) % tHeight) * tWidth + (Math.Abs(j - 2) % tWidth)] * tempSe[15],
                                        grayImage[((i + 1) % tHeight) * tWidth + (Math.Abs(j - 1) % tWidth)] * tempSe[16],
                                        grayImage[((i + 1) % tHeight) * tWidth + j] * tempSe[17],
                                        grayImage[((i + 1) % tHeight) * tWidth + ((j + 1) % tWidth)] * tempSe[18],
                                        grayImage[((i + 1) % tHeight) * tWidth + ((j + 2) % tWidth)] * tempSe[19],
                                        grayImage[((i + 2) % tHeight) * tWidth + (Math.Abs(j - 2) % tWidth)] * tempSe[20],
                                        grayImage[((i + 2) % tHeight) * tWidth + (Math.Abs(j - 1) % tWidth)] * tempSe[21],
                                        grayImage[((i + 2) % tHeight) * tWidth + j] * tempSe[22],
                                        grayImage[((i + 2) % tHeight) * tWidth + ((j + 1) % tWidth)] * tempSe[23],
                                        grayImage[((i + 2) % tHeight) * tWidth + ((j + 2) % tWidth)] * tempSe[24]};
                    int minimum = cou[0];
                    for (int k = 1; k < 25; k++)
                    {
                        if (cou[k] < minimum)
                        {
                            minimum = cou[k];
                        }
                    }
                    tempImage[i * tWidth + j] = (byte)minimum;
                }
            }

            return tempImage;
        }

        public byte[] ImageGrayOpen(byte[] grayImage, byte[] se, int tHeight, int tWidth)
        {
            byte[] tempImage = new byte[grayImage.Length];
            tempImage = ImageGrayErode(grayImage, se, tHeight, tWidth);
            return (ImageGrayDelation(tempImage, se, tHeight, tWidth));
        }

        public byte[] ImageGrayClose(byte[] grayImage, byte[] se, int tHeight, int tWidth)
        {
            byte[] tempImage = new byte[grayImage.Length];
            tempImage = ImageGrayDelation(grayImage, se, tHeight, tWidth);
            return (ImageGrayErode(tempImage, se, tHeight, tWidth));
        }


        /// <summary>
        /// 统计学滤波
        /// </summary>
        /// <param name="curBitmap">要处理的图像</param>
        /// <param name="grayValues">要处理的图像的灰度值</param>
        /// <param name="flag">元素的邻域窗大小，0：3*3 ,1：5*5</param>
        /// <param name="thresholding">阈值</param>
        public void ImageStatic(Bitmap curBitmap, ref byte[] grayValues, bool flag, double thresholding)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            byte[] tempArray = new byte[bytes];

            if (flag == false)
            {
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    for (int j = 0; j < curBitmap.Width; j++)
                    {
                        double mu = 0, sigma = 0;
                        mu = (grayValues[i * curBitmap.Width + j] +
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] +
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] +
                                grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)]) / 9;

                        sigma = Math.Sqrt((Math.Pow((grayValues[i * curBitmap.Width + j] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - mu), 2) +
                                Math.Pow((grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - mu), 2) +
                                Math.Pow((grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - mu), 2)) / 9);

                        if (Math.Abs(grayValues[i * curBitmap.Width + j] - mu) < sigma * thresholding)
                            tempArray[i * curBitmap.Width + j] = grayValues[i * curBitmap.Width + j];
                        else
                            tempArray[i * curBitmap.Width + j] = Convert.ToByte(mu);

                    }
                }
            }
            else
            {
                for (int i = 0; i < curBitmap.Height; i++)
                {
                    for (int j = 0; j < curBitmap.Width; j++)
                    {
                        double mu = 0, sigma = 0;
                        mu = (grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2)) % curBitmap.Width] +
                                grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1)) % curBitmap.Width] +
                                grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + j] +
                                grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] +
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                grayValues[i * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                grayValues[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                grayValues[i * curBitmap.Width + j] +
                                grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                grayValues[i * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + j] +
                                grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] +
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)]) / 25;

                        sigma = Math.Sqrt((Math.Pow((grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2)) % curBitmap.Width] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1)) % curBitmap.Width] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + j] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[i * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[i * curBitmap.Width + j] - mu), 2) +
                                Math.Pow((grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[i * curBitmap.Width + ((j + 2) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + j] - mu), 2) +
                                Math.Pow((grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - mu), 2) +
                                Math.Pow((grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - mu), 2) +
                                Math.Pow((grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] - mu), 2)) / 25);

                        if (Math.Abs(grayValues[i * curBitmap.Width + j] - mu) < sigma * thresholding)
                            tempArray[i * curBitmap.Width + j] = grayValues[i * curBitmap.Width + j];
                        else
                            tempArray[i * curBitmap.Width + j] = Convert.ToByte(mu);

                    }
                }
            }
            grayValues = (byte[])tempArray.Clone();
        }

        public void ImageHitMiss(Bitmap curBitmap, ref byte[] grayValues, bool[] hitStru, bool[] missStru)
        {
            int bytes = curBitmap.Width * curBitmap.Height;
            //bool[] hitStru = hitAndMiss.GetHitStruction;
            //bool[] missStru = hitAndMiss.GetMissStruction;

            byte[] tempArray = new byte[bytes];
            byte[] temp1Array = new byte[bytes];
            byte[] temp2Array = new byte[bytes];
            for (int i = 0; i < bytes; i++)
            {
                tempArray[i] = (byte)(255 - grayValues[i]);
                temp1Array[i] = 255;
                temp2Array[i] = 255;
            }

            for (int i = 1; i < curBitmap.Height - 1; i++)
            {
                for (int j = 1; j < curBitmap.Width - 1; j++)
                {
                    if ((grayValues[(i - 1) * curBitmap.Width + j - 1] == 0 || hitStru[0] == false) &&
                        (grayValues[(i - 1) * curBitmap.Width + j] == 0 || hitStru[1] == false) &&
                        (grayValues[(i - 1) * curBitmap.Width + j + 1] == 0 || hitStru[2] == false) &&
                        (grayValues[i * curBitmap.Width + j - 1] == 0 || hitStru[3] == false) &&
                        (grayValues[i * curBitmap.Width + j] == 0 || hitStru[4] == false) &&
                        (grayValues[i * curBitmap.Width + j + 1] == 0 || hitStru[5] == false) &&
                        (grayValues[(i + 1) * curBitmap.Width + j - 1] == 0 || hitStru[6] == false) &&
                        (grayValues[(i + 1) * curBitmap.Width + j] == 0 || hitStru[7] == false) &&
                        (grayValues[(i + 1) * curBitmap.Width + j + 1] == 0 || hitStru[8] == false))
                    {
                        temp1Array[i * curBitmap.Width + j] = 0;
                    }

                }
            }

            for (int i = 1; i < curBitmap.Height - 1; i++)
            {
                for (int j = 1; j < curBitmap.Width - 1; j++)
                {
                    if ((tempArray[(i - 1) * curBitmap.Width + j - 1] == 0 || missStru[0] == false) &&
                        (tempArray[(i - 1) * curBitmap.Width + j] == 0 || missStru[1] == false) &&
                        (tempArray[(i - 1) * curBitmap.Width + j + 1] == 0 || missStru[2] == false) &&
                        (tempArray[i * curBitmap.Width + j - 1] == 0 || missStru[3] == false) &&
                        (tempArray[i * curBitmap.Width + j] == 0 || missStru[4] == false) &&
                        (tempArray[i * curBitmap.Width + j + 1] == 0 || missStru[5] == false) &&
                        (tempArray[(i + 1) * curBitmap.Width + j - 1] == 0 || missStru[6] == false) &&
                        (tempArray[(i + 1) * curBitmap.Width + j] == 0 || missStru[7] == false) &&
                        (tempArray[(i + 1) * curBitmap.Width + j + 1] == 0 || missStru[8] == false))
                    {
                        temp2Array[i * curBitmap.Width + j] = 0;
                    }

                }
            }

            for (int i = 0; i < bytes; i++)
            {
                if (temp1Array[i] == 0 && temp2Array[i] == 0)
                {
                    tempArray[i] = 0;
                }
                else
                {
                    tempArray[i] = 255;
                }
            }
            grayValues = (byte[])tempArray.Clone();
        }


        /************************************************************************/
        /*
         * 边缘检测
         */
        /************************************************************************/

        /// <summary>
        /// 模板算子
        /// </summary>
        /// <param name="curBitmap">要处理的图像</param>
        /// <param name="grayValues">图像灰度值</param>
        /// <param name="flagMask">选择模板（0：Roberts；1：2；3；4；5）</param>
        /// <param name="thresholding">阈值</param>
        public void ImageMask(Bitmap curBitmap, ref byte[] grayValues, byte flagMask, int thresholding)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            double[] tempArray = new double[bytes];
            double gradX, gradY, grad;

            switch (flagMask)
            {
                case 0://Roberts
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            gradX = grayValues[((Math.Abs(i - 1)) % curBitmap.Height)
                                * curBitmap.Width + ((j + 1) % curBitmap.Width)]
                                - grayValues[i * curBitmap.Width + j];
                            gradY = grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            grad = Math.Sqrt(gradX * gradX + gradY * gradY);
                            tempArray[i * curBitmap.Width + j] = grad;
                        }
                    }
                    break;
                case 1://Prewitt
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            gradX = grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] - grayValues[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] - grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)];
                            gradY = grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] + grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] - grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            grad = Math.Sqrt(gradX * gradX + gradY * gradY);
                            tempArray[i * curBitmap.Width + j] = grad;
                        }
                    }
                    break;
                case 2://Sobel
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            gradX = grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];
                            gradY = grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            grad = Math.Sqrt(gradX * gradX + gradY * gradY);
                            tempArray[i * curBitmap.Width + j] = grad;
                        }
                    }
                    break;
                case 3://Laplacian1公式(8.4)
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            grad = grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - 4 * grayValues[i * curBitmap.Width + j];
                            tempArray[i * curBitmap.Width + j] = grad;
                        }
                    }
                    break;
                case 4://Laplacian2公式(8.5)
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            grad = grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] + grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - 8 * grayValues[i * curBitmap.Width + j];
                            tempArray[i * curBitmap.Width + j] = grad;
                        }
                    }
                    break;
                case 5://Laplacian3公式(8.6)
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            grad = -1 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                2 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] - grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - 4 * grayValues[i * curBitmap.Width + j];
                            tempArray[i * curBitmap.Width + j] = grad;
                        }
                    }
                    break;
                case 6://Kirsch
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            grad = 0;

                            gradX = -5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - 5 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                3 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            if (gradX > grad)
                                grad = gradX;

                            gradX = 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - 5 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                3 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            if (gradX > grad)
                                grad = gradX;

                            gradX = 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                3 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            if (gradX > grad)
                                grad = gradX;

                            gradX = 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] -
                                5 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            if (gradX > grad)
                                grad = gradX;

                            gradX = 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - 5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] -
                                5 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - 5 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            if (gradX > grad)
                                grad = gradX;

                            gradX = 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - 5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] -
                                5 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            if (gradX > grad)
                                grad = gradX;

                            gradX = -5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - 5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                3 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            if (gradX > grad)
                                grad = gradX;

                            gradX = -5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 5 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] - 5 * grayValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                3 * grayValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] + 3 * grayValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            if (gradX > grad)
                                grad = gradX;

                            tempArray[i * curBitmap.Width + j] = grad;
                        }
                    }
                    break;
                default:
                    MessageBox.Show("无效！");
                    break;
            }

            if (thresholding == 0)//不进行阈值处理
            {
                for (int i = 0; i < bytes; i++)
                {
                    if (tempArray[i] < 0)
                        grayValues[i] = 0;
                    else
                    {
                        if (tempArray[i] > 255)
                            grayValues[i] = 255;
                        else
                            grayValues[i] = Convert.ToByte(tempArray[i]);
                    }
                }
            }
            else//阈值处理，生成二值边缘图像
            {
                if (flagMask == 3 || flagMask == 4 || flagMask == 5)
                {
                    zerocross(curBitmap, ref tempArray, out grayValues, thresholding);
                }
                else
                {
                    for (int i = 0; i < bytes; i++)
                    {
                        if (tempArray[i] > thresholding)
                            grayValues[i] = 255;
                        else
                            grayValues[i] = 0;
                    }
                }
            }
        }

        /*找到零交叉点*/
        private void zerocross(Bitmap curBitmap, ref double[] inputImage, out byte[] outImage, double thresh)
        {
            outImage = new byte[curBitmap.Width * curBitmap.Height];
            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    if (inputImage[i * curBitmap.Width + j] < 0 && inputImage[((i + 1) % curBitmap.Height) * curBitmap.Width + j] > 0 && Math.Abs(inputImage[i * curBitmap.Width + j] - inputImage[((i + 1) % curBitmap.Height) * curBitmap.Width + j]) > thresh)
                    {
                        outImage[i * curBitmap.Width + j] = 255;
                    }
                    else if (inputImage[i * curBitmap.Width + j] < 0 && inputImage[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] > 0 && Math.Abs(inputImage[i * curBitmap.Width + j] - inputImage[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j]) > thresh)
                    {
                        outImage[i * curBitmap.Width + j] = 255;
                    }
                    else if (inputImage[i * curBitmap.Width + j] < 0 && inputImage[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] > 0 && Math.Abs(inputImage[i * curBitmap.Width + j] - inputImage[i * curBitmap.Width + ((j + 1) % curBitmap.Width)]) > thresh)
                    {
                        outImage[i * curBitmap.Width + j] = 255;
                    }
                    else if (inputImage[i * curBitmap.Width + j] < 0 && inputImage[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] > 0 && Math.Abs(inputImage[i * curBitmap.Width + j] - inputImage[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)]) > thresh)
                    {
                        outImage[i * curBitmap.Width + j] = 255;
                    }
                    else if (inputImage[i * curBitmap.Width + j] == 0)
                    {
                        if (inputImage[((i + 1) % curBitmap.Height) * curBitmap.Width + j] > 0 && inputImage[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] < 0 && Math.Abs(inputImage[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - inputImage[((i + 1) % curBitmap.Height) * curBitmap.Width + j]) > 2 * thresh)
                        {
                            outImage[i * curBitmap.Width + j] = 255;
                        }
                        else if (inputImage[((i + 1) % curBitmap.Height) * curBitmap.Width + j] < 0 && inputImage[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] > 0 && Math.Abs(inputImage[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] - inputImage[((i + 1) % curBitmap.Height) * curBitmap.Width + j]) > 2 * thresh)
                        {
                            outImage[i * curBitmap.Width + j] = 255;
                        }
                        else if (inputImage[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] > 0 && inputImage[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] < 0 && Math.Abs(inputImage[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] - inputImage[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)]) > 2 * thresh)
                        {
                            outImage[i * curBitmap.Width + j] = 255;
                        }
                        else if (inputImage[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] < 0 && inputImage[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] > 0 && Math.Abs(inputImage[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] - inputImage[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)]) > 2 * thresh)
                        {
                            outImage[i * curBitmap.Width + j] = 255;
                        }
                        else
                        {
                            outImage[i * curBitmap.Width + j] = 0;
                        }
                    }
                    else
                    {
                        outImage[i * curBitmap.Width + j] = 0;
                    }
                }
            }
        }

        /// <summary>
        /// 高斯算子边缘检测
        /// </summary>
        /// <param name="curBitmap">检测图像</param>
        /// <param name="grayValues">图像灰度值</param>
        /// <param name="sigma">均方差</param>
        /// <param name="thresholding">阈值</param>
        /// <param name="flag">选择算子种类(1:拉普拉斯-高斯算子;0:差分高斯算子)</param>
        public void ImageGaussian(Bitmap curBitmap, ref byte[] grayValues, double sigma, double thresholding, bool flag)
        {
            int bytes = curBitmap.Width * curBitmap.Height;
            double[] filt, tempArray;
            createFilter(curBitmap, out filt, sigma, flag);
            conv2(curBitmap, ref grayValues, ref filt, out tempArray);
            zerocross(curBitmap, ref tempArray, out grayValues, thresholding);
        }

        private void createFilter(Bitmap curBitmap, out double[] filter, double sigma, bool lod)
        {
            double std2 = 2 * sigma * sigma;
            int radius = Convert.ToInt16(Math.Ceiling(3 * sigma));
            int filterWidth = 2 * radius + 1;
            filter = new double[filterWidth * filterWidth];
            double sum = 0, average = 0;
            if (lod == false)
            {
                for (int i = 0; i < radius; i++)
                {
                    for (int j = 0; j < radius; j++)
                    {
                        int xx = (j - radius) * (j - radius);
                        int yy = (i - radius) * (i - radius);
                        filter[i * filterWidth + j] = (xx + yy - std2) * Math.Exp(-(xx + yy) / std2);
                        sum += 4 * filter[i * filterWidth + j];
                    }
                }
                for (int i = 0; i < radius; i++)
                {
                    int xx = (i - radius) * (i - radius);
                    filter[i * filterWidth + radius] = (xx - std2) * Math.Exp(-xx / std2);
                    sum += 2 * filter[i * filterWidth + radius];
                }
                for (int j = 0; j < radius; j++)
                {
                    int yy = (j - radius) * (j - radius);
                    filter[radius * filterWidth + j] = (yy - std2) * Math.Exp(-yy / std2);
                    sum += 2 * filter[radius * filterWidth + j];
                }
                filter[radius * filterWidth + radius] = -std2;
                sum += filter[radius * filterWidth + radius];
                average = sum / filter.Length;
                for (int i = 0; i < radius; i++)
                {
                    for (int j = 0; j < radius; j++)
                    {
                        filter[i * filterWidth + j] = filter[i * filterWidth + j] - average;
                        filter[filterWidth - 1 - j + i * filterWidth] = filter[i * filterWidth + j];
                        filter[filterWidth - 1 - j + (filterWidth - 1 - i) * filterWidth] = filter[i * filterWidth + j];
                        filter[j + (filterWidth - 1 - i) * filterWidth] = filter[i * filterWidth + j];
                    }
                }
                for (int i = 0; i < radius; i++)
                {
                    filter[i * filterWidth + radius] = filter[i * filterWidth + radius] - average;
                    filter[(filterWidth - 1 - i) * filterWidth + radius] = filter[i * filterWidth + radius];
                }
                for (int j = 0; j < radius; j++)
                {
                    filter[radius * filterWidth + j] = filter[radius * filterWidth + j] - average;
                    filter[radius * filterWidth + filterWidth - 1 - j] = filter[radius * filterWidth + j];

                }
                filter[radius * filterWidth + radius] = filter[radius * filterWidth + radius] - average;

            }
            else
            {
                for (int i = 0; i < radius; i++)
                {
                    for (int j = 0; j < radius; j++)
                    {
                        int xx = (j - radius) * (j - radius);
                        int yy = (i - radius) * (i - radius);
                        filter[i * filterWidth + j] = 1.6 * Math.Exp(-(xx + yy) * 1.6 * 1.6 / std2) / sigma - Math.Exp(-(xx + yy) / std2) / sigma;
                        sum += 4 * filter[i * filterWidth + j];
                    }
                }
                for (int i = 0; i < radius; i++)
                {
                    int xx = (i - radius) * (i - radius);
                    filter[i * filterWidth + radius] = 1.6 * Math.Exp(-xx * 1.6 * 1.6 / std2) / sigma - Math.Exp(-xx / std2) / sigma;
                    sum += 2 * filter[i * filterWidth + radius];
                }
                for (int j = 0; j < radius; j++)
                {
                    int yy = (j - radius) * (j - radius);
                    filter[radius * filterWidth + j] = 1.6 * Math.Exp(-yy * 1.6 * 1.6 / std2) / sigma - Math.Exp(-yy / std2) / sigma;
                    sum += 2 * filter[radius * filterWidth + j];
                }
                filter[radius * filterWidth + radius] = 1.6 / sigma - 1 / sigma;
                sum += filter[radius * filterWidth + radius];
                average = sum / filter.Length;
                for (int i = 0; i < radius; i++)
                {
                    for (int j = 0; j < radius; j++)
                    {
                        filter[i * filterWidth + j] = filter[i * filterWidth + j] - average;
                        filter[filterWidth - 1 - j + i * filterWidth] = filter[i * filterWidth + j];
                        filter[filterWidth - 1 - j + (filterWidth - 1 - i) * filterWidth] = filter[i * filterWidth + j];
                        filter[j + (filterWidth - 1 - i) * filterWidth] = filter[i * filterWidth + j];
                    }
                }
                for (int i = 0; i < radius; i++)
                {
                    filter[i * filterWidth + radius] = filter[i * filterWidth + radius] - average;
                    filter[(filterWidth - 1 - i) * filterWidth + radius] = filter[i * filterWidth + radius];
                }
                for (int j = 0; j < radius; j++)
                {
                    filter[radius * filterWidth + j] = filter[radius * filterWidth + j] - average;
                    filter[radius * filterWidth + filterWidth - 1 - j] = filter[radius * filterWidth + j];

                }
                filter[radius * filterWidth + radius] = filter[radius * filterWidth + radius] - average;
            }
        }

        private void conv2(Bitmap curBitmap, ref byte[] inputImage, ref double[] mask, out double[] outImage)
        {
            int windWidth = Convert.ToInt16(Math.Sqrt(mask.Length));
            int radius = windWidth / 2;
            double temp;
            outImage = new double[curBitmap.Width * curBitmap.Height];

            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    temp = 0;
                    for (int x = -radius; x <= radius; x++)
                    {
                        for (int y = -radius; y <= radius; y++)
                        {
                            temp += inputImage[((Math.Abs(i + x)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j + y)) % curBitmap.Width] * mask[(x + radius) * windWidth + y + radius];
                        }
                    }
                    outImage[i * curBitmap.Width + j] = temp;
                }
            }
        }

        /// <summary>
        /// Canny算子边缘检测
        /// </summary>
        /// <param name="curBitmap">要处理的图像</param>
        /// <param name="grayValues">图像灰度数据</param>
        /// <param name="thresholding">高低阈值（二维数组中第一个为高阈值）</param>
        /// <param name="sigma">均方差</param>
        public void ImageCanny(Bitmap curBitmap, ref byte[] grayValues, byte[] thresholding, double sigma)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            double[] tempArray;// = new double[bytes];
            double[] tempImage = new double[bytes];
            double[] grad = new double[bytes];
            byte[] aLabel = new byte[bytes];
            double[] edgeMap = new double[bytes];
            Array.Clear(edgeMap, 0, bytes);
            double gradX, gradY, angle;
            int rad = Convert.ToInt16(Math.Ceiling(3 * sigma));
            for (int i = 0; i < bytes; i++)
                tempImage[i] = Convert.ToDouble(grayValues[i]);

            gaussSmooth(tempImage, out tempArray, sigma);
            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    gradX = tempArray[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * tempArray[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + tempArray[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                tempArray[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * tempArray[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - tempArray[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];

                    gradY = tempArray[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * tempArray[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + tempArray[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                tempArray[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * tempArray[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - tempArray[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];

                    grad[i * curBitmap.Width + j] = Math.Sqrt(gradX * gradX + gradY * gradY);

                    angle = Math.Atan2(gradY, gradX);
                    if ((angle >= -1.178097 && angle < 1.178097) || angle >= 2.748894 || angle < -2.748894)
                        aLabel[i * curBitmap.Width + j] = 0;
                    else if ((angle >= 0.392699 && angle < 1.178097) || (angle >= -2.748894 && angle < -1.963495))
                        aLabel[i * curBitmap.Width + j] = 1;
                    else if ((angle >= -1.178097 && angle < -0.392699) || (angle >= 1.963495 && angle < 2.748894))
                        aLabel[i * curBitmap.Width + j] = 2;
                    else
                        aLabel[i * curBitmap.Width + j] = 3;
                }
            }
            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    switch (aLabel[i * curBitmap.Width + j])
                    {
                        case 3://水平方向
                            if (grad[i * curBitmap.Width + j] > grad[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] && grad[i * curBitmap.Width + j] > grad[((i + 1) % curBitmap.Height) * curBitmap.Width + j])
                                edgeMap[i * curBitmap.Width + j] = grad[i * curBitmap.Width + j];
                            break;
                        case 2://正45度方向
                            if (grad[i * curBitmap.Width + j] > grad[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] && grad[i * curBitmap.Width + j] > grad[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)])
                                edgeMap[i * curBitmap.Width + j] = grad[i * curBitmap.Width + j];
                            break;
                        case 1://负45度方向
                            if (grad[i * curBitmap.Width + j] > grad[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] && grad[i * curBitmap.Width + j] > grad[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)])
                                edgeMap[i * curBitmap.Width + j] = grad[i * curBitmap.Width + j];
                            break;
                        case 0://垂直方向
                            if (grad[i * curBitmap.Width + j] > grad[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] && grad[i * curBitmap.Width + j] > grad[i * curBitmap.Width + ((j + 1) % curBitmap.Width)])
                                edgeMap[i * curBitmap.Width + j] = grad[i * curBitmap.Width + j];
                            break;
                        default:
                            return;
                    }
                }
            }

            Array.Clear(grayValues, 0, bytes);
            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    if (edgeMap[i * curBitmap.Width + j] > thresholding[0])
                    {
                        grayValues[i * curBitmap.Width + j] = 255;
                        traceEdge(curBitmap, i, j, edgeMap, ref grayValues, thresholding[1]);
                    }
                }
            }
        }

        private void traceEdge(Bitmap curBitmap, int k, int l, double[] inputImage, ref byte[] outputImage, byte thrLow)
        {
            int[] kOffset = new int[] { 1, 1, 0, -1, -1, -1, 0, 1 };
            int[] lOffset = new int[] { 0, 1, 1, 1, 0, -1, -1, -1 };
            int kk, ll;
            for (int p = 0; p < 8; p++)
            {
                kk = k + kOffset[p];
                kk = Math.Abs(kk) % curBitmap.Height;
                ll = l + lOffset[p];
                ll = Math.Abs(ll) % curBitmap.Width;
                if (outputImage[ll * curBitmap.Width + kk] != 255)
                {
                    if (inputImage[ll * curBitmap.Width + kk] > thrLow)
                    {
                        outputImage[ll * curBitmap.Width + kk] = 255;
                        traceEdge(curBitmap, ll, kk, inputImage, ref outputImage, thrLow);
                    }
                }
            }
        }

        public void ImageWvl(Bitmap curBitmap, ref byte[] grayValues, byte multiscale, byte[] thresholding)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            double[] tempArray1 = new double[bytes];
            double[] tempArray2 = new double[bytes];
            double[] tempArray3 = new double[bytes];
            double[] gradX = new double[bytes];
            double[] gradY = new double[bytes];

            //byte multiscale = wavelet.GetScale;
            //byte[] thresholding = new byte[2];
            //thresholding = wavelet.GetThresh;

            for (int i = 0; i < bytes; i++)
            {
                tempArray1[i] = Convert.ToDouble(grayValues[i]);
            }

            for (int z = 0; z <= multiscale; z++)
            {
                double[] p = null;
                double[] q = null;
                switch (z)
                {
                    case 0:
                        p = new double[] { 0.125, 0.375, 0.375, 0.125 };
                        q = new double[] { -2, 2 };
                        break;
                    case 1:
                        p = new double[] { 0.125, 0, 0.375, 0, 0.375, 0, 0.125 };
                        q = new double[] { -2, 0, 2 };
                        break;
                    case 2:
                        p = new double[] { 0.125, 0, 0, 0, 0.375, 0, 0, 0, 0.375, 0, 0, 0, 0.125 };
                        q = new double[] { -2, 0, 0, 0, 2 };
                        break;
                    case 3:
                        p = new double[] { 0.125, 0, 0, 0, 0, 0, 0, 0, 0.375, 0, 0, 0, 0, 0, 0, 0, 0.375, 0, 0, 0, 0, 0, 0, 0, 0.125 };
                        q = new double[] { -2, 0, 0, 0, 0, 0, 0, 0, 2 };
                        break;
                    default:
                        return;
                }

                int coff = Convert.ToInt16(Math.Pow(2, z) - 1);

                for (int i = 0; i < curBitmap.Height; i++)
                {
                    for (int j = 0; j < curBitmap.Width; j++)
                    {
                        double[] scl = new double[curBitmap.Width];
                        double[] wvl = new double[curBitmap.Width];
                        int temp;

                        scl[j] = 0.0;
                        wvl[j] = 0.0;
                        for (int x = -2 - 2 * coff; x < p.Length - 2 - 2 * coff; x++)
                        {
                            temp = (Math.Abs(j + x)) % curBitmap.Width;
                            scl[j] += p[1 + coff - x] * tempArray1[i * curBitmap.Width + temp];
                        }
                        for (int x = -1 - coff; x < q.Length - 1 - coff; x++)
                        {
                            temp = (Math.Abs(j + x)) % curBitmap.Width;
                            wvl[j] += q[-x] * tempArray1[i * curBitmap.Width + temp];
                        }

                        tempArray2[i * curBitmap.Width + j] = scl[j];
                        gradX[i * curBitmap.Width + j] = wvl[j];
                    }
                }

                for (int i = 0; i < curBitmap.Width; i++)
                {
                    for (int j = 0; j < curBitmap.Height; j++)
                    {
                        double[] scl = new double[curBitmap.Height];
                        double[] wvl = new double[curBitmap.Height];
                        int temp;

                        scl[j] = 0.0;
                        wvl[j] = 0.0;
                        for (int x = -2 - 2 * coff; x < p.Length - 2 - 2 * coff; x++)
                        {
                            temp = (Math.Abs(j + x)) % curBitmap.Height;
                            scl[j] += p[1 + coff - x] * tempArray2[temp * curBitmap.Width + i];
                        }
                        for (int x = -1 - coff; x < q.Length - 1 - coff; x++)
                        {
                            temp = (Math.Abs(j + x)) % curBitmap.Height;
                            wvl[j] += q[-x] * tempArray1[temp * curBitmap.Width + i];
                        }

                        tempArray3[j * curBitmap.Width + i] = scl[j];
                        gradY[j * curBitmap.Width + i] = wvl[j];
                    }
                }

                tempArray1 = (double[])tempArray3.Clone();
            }

            double angle;
            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    tempArray1[i * curBitmap.Width + j] = Math.Sqrt(gradX[i * curBitmap.Width + j] * gradX[i * curBitmap.Width + j] + gradY[i * curBitmap.Width + j] * gradY[i * curBitmap.Width + j]);
                    angle = Math.Atan2(gradY[i * curBitmap.Width + j], gradX[i * curBitmap.Width + j]);
                    if ((angle >= -1.178097 && angle < 1.178097) || angle >= 2.748894 || angle < -2.748894)
                        tempArray2[i * curBitmap.Width + j] = 0;
                    else if ((angle >= 0.392699 && angle < 1.178097) || (angle >= -2.748894 && angle < -1.963495))
                        tempArray2[i * curBitmap.Width + j] = 1;
                    else if ((angle >= -1.178097 && angle < -0.392699) || (angle >= 1.963495 && angle < 2.748894))
                        tempArray2[i * curBitmap.Width + j] = 2;
                    else
                        tempArray2[i * curBitmap.Width + j] = 3;
                }
            }


            Array.Clear(tempArray3, 0, bytes);
            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    switch (Convert.ToInt16(tempArray2[i * curBitmap.Width + j]))
                    {
                        case 3://水平方向
                            if (tempArray1[i * curBitmap.Width + j] > tempArray1[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] && tempArray1[i * curBitmap.Width + j] > tempArray1[((i + 1) % curBitmap.Height) * curBitmap.Width + j])
                                tempArray3[i * curBitmap.Width + j] = tempArray1[i * curBitmap.Width + j];
                            break;
                        case 1://正45度方向
                            if (tempArray1[i * curBitmap.Width + j] > tempArray1[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] && tempArray1[i * curBitmap.Width + j] > tempArray1[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)])
                                tempArray3[i * curBitmap.Width + j] = tempArray1[i * curBitmap.Width + j];
                            break;
                        case 2://负45度方向
                            if (tempArray1[i * curBitmap.Width + j] > tempArray1[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] && tempArray1[i * curBitmap.Width + j] > tempArray1[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)])
                                tempArray3[i * curBitmap.Width + j] = tempArray1[i * curBitmap.Width + j];
                            break;
                        case 0://垂直方向
                            if (tempArray1[i * curBitmap.Width + j] > tempArray1[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] && tempArray1[i * curBitmap.Width + j] > tempArray1[i * curBitmap.Width + ((j + 1) % curBitmap.Width)])
                                tempArray3[i * curBitmap.Width + j] = tempArray1[i * curBitmap.Width + j];
                            break;
                        default:
                            return;
                    }
                }
            }

            Array.Clear(grayValues, 0, bytes);
            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    if (tempArray3[i * curBitmap.Width + j] > thresholding[0])
                    {
                        grayValues[i * curBitmap.Width + j] = 255;
                        traceEdge(curBitmap, i, j, tempArray3, ref grayValues, thresholding[1]);
                    }
                }
            }

        }

        /// <summary>
        /// 金字塔边缘检测
        /// </summary>
        /// <param name="curBitmap">待处理的图像</param>
        /// <param name="grayValues">图像灰度值</param>
        /// <param name="thresh">阈值</param>
        /// <param name="level">层级</param>
        /// <param name="sigma">均方差</param>
        public void ImageGlp(Bitmap curBitmap, ref byte[] grayValues, double thresh, byte level, double sigma)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            //double thresh = pyramid.GetThresh;
            //byte level = pyramid.GetLevel;
            //double sigma = pyramid.GetSigma;

            double[][] pyramidImage = new double[level + 1][];
            double[][] passImage = new double[level + 1][];
            int levelBytes = bytes;
            for (int k = 0; k < level + 1; k++)
            {
                passImage[k] = new double[levelBytes];
                pyramidImage[k] = new double[levelBytes];
                levelBytes = levelBytes / 4;
            }
            for (int i = 0; i < bytes; i++)
            {
                pyramidImage[0][i] = Convert.ToDouble(grayValues[i]);
            }

            for (int k = 0; k < level; k++)
            {
                double[] tempImage = null;
                gaussSmooth(pyramidImage[k], out tempImage, sigma);
                int coff = pyramidImage[k].Length;
                for (int i = 0; i < coff; i++)
                {
                    passImage[k][i] = pyramidImage[k][i] - tempImage[i];
                    int div = i / Convert.ToInt16(Math.Sqrt(coff));
                    int rem = i % Convert.ToInt16(Math.Sqrt(coff));
                    if (div % 2 == 0 && rem % 2 == 0)
                    {
                        int j = (int)((div / 2) * Math.Sqrt(pyramidImage[k + 1].Length) + rem / 2);
                        pyramidImage[k + 1][j] = tempImage[i];
                    }
                }
            }

            for (int k = level - 1; k >= 0; k--)
            {
                int coff = pyramidImage[k].Length;
                for (int i = 0; i < coff; i++)
                {
                    int div = i / Convert.ToInt16(Math.Sqrt(coff));
                    int rem = i % Convert.ToInt16(Math.Sqrt(coff));
                    int j = (int)((div / 2) * Math.Sqrt(pyramidImage[k + 1].Length) + rem / 2);
                    if (div % 2 == 0 && rem % 2 == 0)
                        pyramidImage[k][i] = pyramidImage[k + 1][j];
                    else
                        pyramidImage[k][i] = 0;
                }
                double[] tempImage = null;
                gaussSmooth(pyramidImage[k], out tempImage, 1);
                for (int i = 0; i < coff; i++)
                    pyramidImage[k][i] = tempImage[i] + passImage[k][i];
            }

            zerocross(curBitmap, ref pyramidImage[0], out grayValues, thresh);
        }

        public void MorphologicEdge(Bitmap curBitmap, ref byte[] grayValues, byte[] struEle, double thresh, bool flag)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            byte[] tempArray1 = new byte[bytes];
            byte[] tempArray2 = new byte[bytes];
            //bool flag = grayMor.GetMethod;
            //double thresh = grayMor.GetThresh;
            //byte[] struEle = new byte[25];
            //struEle = grayMor.GetStruction;
            int temp;

            tempArray1 = ImageGrayDelation(grayValues, struEle, curBitmap.Height, curBitmap.Width);
            tempArray2 = ImageGrayErode(grayValues, struEle, curBitmap.Height, curBitmap.Width);

            for (int i = 0; i < bytes; i++)
            {
                if (flag == false)
                    temp = (tempArray1[i] - tempArray2[i]) / 2;
                else
                    temp = (tempArray1[i] + tempArray2[i] - 2 * grayValues[i]) / 2;

                if (temp > thresh)
                    grayValues[i] = 255;
                else
                    grayValues[i] = 0;
            }
        }


        /************************************************************************/
        /*  
         *
         * 图像分割
         *
         */
        /************************************************************************/

        /// <summary>
        /// 阈值法图像分割
        /// </summary>
        /// <param name="curBitmap">待处理的图像</param>
        /// <param name="grayValues">图像灰度</param>
        /// <param name="method">选择方法（0：迭代法；1：Otsu法；2：一维最大熵法；3二维最大熵法；4简单统计法）</param>
        public void ImageThresholding(Bitmap curBitmap, ref byte[] grayValues, byte method)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            byte T = 0, S = 0;
            byte[] neighb = new byte[bytes];
            byte temp = 0;
            byte maxGray = 0;
            byte minGray = 255;
            int[] countPixel = new int[256];
            for (int i = 0; i < grayValues.Length; i++)
            {
                temp = grayValues[i];
                countPixel[temp]++;
                if (temp > maxGray)
                {
                    maxGray = temp;
                }
                if (temp < minGray)
                {
                    minGray = temp;
                }
            }
            double mu1, mu2;
            int numerator, denominator;
            double sigma;
            double tempMax = 0;

            switch (method)
            {
                case 0://迭代法
                    byte oldT;
                    T = oldT = Convert.ToByte((maxGray + minGray) / 2);

                    do
                    {
                        oldT = T;
                        numerator = denominator = 0;
                        for (int i = minGray; i < T; i++)
                        {
                            numerator += i * countPixel[i];
                            denominator += countPixel[i];
                        }
                        mu1 = numerator / denominator;

                        numerator = denominator = 0;
                        for (int i = T; i <= maxGray; i++)
                        {
                            numerator += i * countPixel[i];
                            denominator += countPixel[i];
                        }
                        mu2 = numerator / denominator;

                        T = Convert.ToByte((mu1 + mu2) / 2);
                    }
                    while (T != oldT);
                    break;
                case 1://Otsu法
                    double w1 = 0, w2 = 0;
                    double sum = 0;
                    numerator = 0;
                    for (int i = minGray; i <= maxGray; i++)
                    {
                        sum += i * countPixel[i];
                    }
                    for (int i = minGray; i < maxGray; i++)
                    {
                        w1 += countPixel[i];
                        numerator += i * countPixel[i];
                        mu1 = numerator / w1;
                        w2 = grayValues.Length - w1;
                        mu2 = (sum - numerator) / w2;
                        sigma = w1 * w2 * (mu1 - mu2) * (mu1 - mu2);

                        if (sigma > tempMax)
                        {
                            tempMax = sigma;
                            T = Convert.ToByte(i);
                        }
                    }
                    break;
                case 2://一维最大熵法
                    double Ht = 0.0, Hl = 0.0, p = 0.0, pt = 0.0;
                    for (int i = minGray; i <= maxGray; i++)
                    {
                        p = (double)countPixel[i] / grayValues.Length;
                        if (p < 0.00000000000000001)
                            continue;
                        Hl += -p * Math.Log10(p);
                    }
                    for (int i = minGray; i <= maxGray; i++)
                    {
                        p = (double)countPixel[i] / grayValues.Length;
                        pt += p;
                        if (p < 0.00000000000000001)
                            continue;
                        Ht += -p * Math.Log10(p);
                        sigma = Math.Log10(pt * (1 - pt)) + Ht / pt + (Hl - Ht) / (1 - pt);
                        if (sigma > tempMax)
                        {
                            tempMax = sigma;
                            T = Convert.ToByte(i);
                        }
                    }
                    break;
                case 3://二维最大熵

                    double[,] pap = new double[256, 256];
                    double Hl2D = 0.0, Pa = 0.0, Ha = 0.0;
                    for (int i = 0; i < bytes; i++)
                    {
                        neighb[i] = Convert.ToByte((grayValues[(i + 1) % bytes] + grayValues[Math.Abs(i - 1) % bytes] + grayValues[(i + curBitmap.Width) % bytes] + grayValues[Math.Abs(i - curBitmap.Width) % bytes]) / 4);
                    }
                    for (int i = 0; i < bytes; i++)
                    {
                        for (int j = 0; j < bytes; j++)
                        {
                            int ii = grayValues[i];
                            int jj = neighb[j];
                            pap[ii, jj]++;
                        }
                    }

                    for (int i = 0; i < 256; i++)
                    {
                        for (int j = 0; j < 256; j++)
                        {
                            pap[i, j] = ((double)pap[i, j] / bytes) / bytes;
                            if (pap[i, j] < 0.00000000000000001)
                                continue;
                            Hl2D += -pap[i, j] * Math.Log10(pap[i, j]);
                        }
                    }
                    for (int i = 0; i <= 255; i++)
                    {
                        for (int j = 0; j <= 255; j++)
                        {
                            Pa += pap[i, j];
                            if (pap[i, j] < 0.00000000000000001)
                                continue;
                            Ha += -pap[i, j] * Math.Log10(pap[i, j]);
                            sigma = Math.Log10(Pa * (1 - Pa)) + Ha / Pa + (Hl2D - Ha) / (1 - Pa);
                            if (sigma > tempMax)
                            {
                                tempMax = sigma;
                                S = Convert.ToByte(i);
                                T = Convert.ToByte(j);
                            }
                        }
                    }
                    break;
                case 4://简单统计法
                    int[] ee = new int[bytes];
                    int ex, ey, ef = 0, esum = 0;
                    for (int i = 0; i < bytes; i++)
                    {
                        ex = Math.Abs(grayValues[(i + 1) % bytes] - grayValues[Math.Abs(i - 1) % bytes]);
                        ey = Math.Abs(grayValues[(i + curBitmap.Width) % bytes] - grayValues[Math.Abs(i - curBitmap.Width) % bytes]);
                        ee[i] = Math.Max(ex, ey);
                        ef += ee[i] * grayValues[i];
                        esum += ee[i];
                    }
                    T = Convert.ToByte(ef / esum);
                    break;
                default:
                    break;
            }

            for (int i = 0; i < bytes; i++)
            {
                if (method == 3)
                {
                    if (grayValues[i] < S && neighb[i] < T)
                        grayValues[i] = 0;
                    else
                        grayValues[i] = 255;
                }
                else
                {
                    if (grayValues[i] < T)
                        grayValues[i] = 0;
                    else
                        grayValues[i] = 255;
                }
            }

        }

        /// <summary>
        /// 聚类分割法
        /// </summary>
        /// <param name="curBitmap">待处理的图像</param>
        /// <param name="grayValues">灰度数据</param>
        /// <param name="method">选择方法（0:K-均值聚类法;1:ISODATA聚类法）</param>
        /// <param name="numbers">分类个数（大于2开始）</param>
        public void ImageCluster(Bitmap curBitmap, ref byte[] grayValues, bool method, int numbers)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            //bool method = cluMethod.GetMethod;
            //int numbers = cluMethod.GetNumber;

            if (method == false)//k-mean
            {
                int[] kNum = new int[numbers];
                int[] kAver = new int[numbers];
                int[] kOldAver = new int[numbers];
                int[] kSum = new int[numbers];
                int[] kTemp = new int[numbers];
                byte[] segmentMap = new byte[bytes];
                //初始化聚类均值
                for (int i = 0; i < numbers; i++)
                {
                    //kNum[i] = 0;
                    //kSum[i] = 0;
                    kAver[i] = kOldAver[i] = Convert.ToInt16(i * 255 / (numbers - 1));
                }

                while (true)
                {
                    int order = 0;
                    for (int i = 0; i < numbers; i++)
                    {
                        kAver[i] = kOldAver[i];
                        kNum[i] = 0;
                        kSum[i] = 0;
                    }
                    //归属聚类
                    for (int i = 0; i < bytes; i++)
                    {
                        for (int j = 0; j < numbers; j++)
                        {
                            kTemp[j] = Math.Abs(grayValues[i] - kAver[j]);
                        }
                        int temp = 255;

                        for (int j = 0; j < numbers; j++)
                        {
                            if (kTemp[j] < temp)
                            {
                                temp = kTemp[j];
                                order = j;
                            }
                        }
                        kNum[order]++;
                        kSum[order] += grayValues[i];
                        segmentMap[i] = Convert.ToByte(order);
                    }
                    for (int i = 0; i < numbers; i++)
                    {
                        if (kNum[i] != 0)
                            kOldAver[i] = Convert.ToInt16(kSum[i] / kNum[i]);
                    }

                    int kkk = 0;
                    for (int i = 0; i < numbers; i++)
                    {
                        if (kAver[i] == kOldAver[i])
                            kkk++;
                    }
                    if (kkk == numbers)
                        break;
                }

                for (int i = 0; i < bytes; i++)
                {
                    for (int j = 0; j < numbers; j++)
                    {
                        if (segmentMap[i] == j)
                        {
                            grayValues[i] = Convert.ToByte(kAver[j]);
                        }
                    }
                }
            }
            else//ISODATA
            {
                int k = 2 * numbers;
                byte[] segmentMap = new byte[bytes];
                List<int> kTemp = new List<int>();
                List<int> kNum = new List<int>();
                List<int> kAver = new List<int>();
                List<int> kSum = new List<int>();
                kAver.Clear();
                kNum.Clear();
                kTemp.Clear();
                kSum.Clear();
                for (int i = 0; i < k; i++)
                {
                    kAver.Add(Convert.ToInt16(i * 255 / (k - 1)));
                    kNum.Add(0);
                    kTemp.Add(0);
                    kSum.Add(0);
                }

                while (true)
                {
                    int temp;
                    for (int i = 0; i < bytes; i++)
                    {
                        kTemp.Clear();
                        int order = 0;
                        for (int j = 0; j < k; j++)
                        {
                            kTemp.Add(Math.Abs(grayValues[i] - kAver[j]));
                        }
                        temp = 255;

                        for (int j = 0; j < k; j++)
                        {
                            if (kTemp[j] < temp)
                            {
                                temp = kTemp[j];
                                order = j;
                            }
                        }
                        int num = kNum[order] + 1;
                        kNum.RemoveAt(order);
                        kNum.Insert(order, num);
                        int sum = kSum[order] + grayValues[i];
                        kSum.RemoveAt(order);
                        kSum.Insert(order, sum);
                        segmentMap[i] = Convert.ToByte(order);
                    }

                    for (int i = 0; i < k; i++)
                    {
                        if (kNum[i] == 0)
                        {
                            kNum.RemoveAt(i);
                            kAver.RemoveAt(i);
                            kSum.RemoveAt(i);
                            i--;
                            k--;
                        }
                    }

                    kAver.Clear();
                    for (int i = 0; i < k; i++)
                    {
                        kAver.Add(Convert.ToInt16(kSum[i] / kNum[i]));
                    }
                    if (k <= numbers)
                        break;
                    temp = 255;
                    int removeI = 0, removeJ = 0;
                    for (int i = 0; i < k; i++)
                    {
                        for (int j = i + 1; j < k; j++)
                        {
                            int distanceIJ = Math.Abs(kAver[i] - kAver[j]);
                            if (distanceIJ < temp)
                            {
                                temp = distanceIJ;
                                removeI = i;
                                removeJ = j;
                            }
                        }
                    }
                    k--;
                    kNum.Add(kNum[removeI] + kNum[removeJ]);
                    kAver.Add(Convert.ToInt16((kNum[removeI] * kAver[removeI] + kNum[removeJ] * kAver[removeJ]) / (kNum[removeI] + kNum[removeJ])));
                    kSum.Add(kNum[removeI] * kAver[removeI] + kNum[removeJ] * kAver[removeJ]);
                    kNum.RemoveAt(removeI);
                    kNum.RemoveAt(removeJ);
                    kAver.RemoveAt(removeI);
                    kAver.RemoveAt(removeJ);
                    kSum.RemoveAt(removeI);
                    kSum.RemoveAt(removeJ);
                }

                for (int i = 0; i < bytes; i++)
                {
                    for (int j = 0; j < numbers; j++)
                    {
                        if (segmentMap[i] == j)
                        {
                            grayValues[i] = Convert.ToByte(kAver[j]);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 松弛迭代分割
        /// </summary>
        /// <param name="curBitmap">待处理的图像</param>
        /// <param name="grayValues">图像灰度数据</param>
        /// <param name="segNumber">分类个数(至少为2)</param>
        /// <param name="iterNumber">迭代次数（至少为10）</param>
        public void ImageOverRelax(Bitmap curBitmap, ref byte[] grayValues, int segNumber, int iterNumber)
        {
            int bytes = curBitmap.Width * curBitmap.Height;

            //int segNumber = overRelaxIter.GetSegNum;
            //int iterNumber = overRelaxIter.GetIterNum;

            int[] kSum = new int[segNumber];
            double[] kAver = new double[segNumber];
            double[] kVar = new double[segNumber];
            Array.Clear(kAver, 0, segNumber);
            Array.Clear(kSum, 0, segNumber);
            Array.Clear(kVar, 0, segNumber);

            int[] imageMap = new int[bytes];

            for (int i = 0; i < bytes; i++)
            {
                for (int j = 1; j <= segNumber; j++)
                {
                    if (grayValues[i] < Convert.ToByte(255 * j / segNumber))
                    {
                        imageMap[i] = j - 1;
                        kAver[j - 1] += grayValues[i];
                        kSum[j - 1] += 1;
                        break;
                    }
                }
            }

            for (int i = 0; i < segNumber; i++)
            {
                if (kSum[i] != 0)
                    kAver[i] /= kSum[i];
            }
            for (int i = 0; i < bytes; i++)
            {
                if (imageMap[i] < segNumber)
                    kVar[imageMap[i]] += Convert.ToInt32(Math.Pow(grayValues[i] - kAver[imageMap[i]], 2));
            }
            for (int i = 0; i < segNumber; i++)
            {
                if (kSum[i] != 0)
                    kVar[i] /= kSum[i];
            }

            double[] d = new double[bytes * segNumber];
            double[] kProb = new double[bytes * segNumber];
            Array.Clear(d, 0, bytes * segNumber);
            Array.Clear(kProb, 0, bytes * segNumber);

            for (int i = 0; i < bytes; i++)
            {
                for (int j = 0; j < segNumber; j++)
                {
                    if (kVar[j] == 0)
                        kVar[j] = 0.00000005;
                    d[i * segNumber + j] = Math.Pow(kAver[j] - grayValues[i], 2) / kVar[j];
                    if (d[i * segNumber + j] == 0)
                        d[i * segNumber + j] = 0.00000005;
                }
            }

            double tempSum = 0;
            for (int i = 0; i < bytes; i++)
            {
                tempSum = 0;
                for (int j = 0; j < segNumber; j++)
                    tempSum += 1 / d[i * segNumber + j];
                for (int j = 0; j < segNumber; j++)
                    kProb[i * segNumber + j] = 1 / (tempSum * d[i * segNumber + j]);
            }

            while (iterNumber != 0)
            {
                iterNumber--;

                for (int i = 0; i < bytes; i++)
                {
                    for (int j = 0; j < segNumber; j++)
                    {
                        tempSum = kProb[(Math.Abs(i + 1 - curBitmap.Width) % bytes) * segNumber + j] + kProb[(Math.Abs(i - curBitmap.Width) % bytes) * segNumber + j] + kProb[(Math.Abs(i - 1 - curBitmap.Width) % bytes) * segNumber + j] + kProb[(Math.Abs(i - 1) % bytes) * segNumber + j] + kProb[((i - 1 + curBitmap.Width) % bytes) * segNumber + j] + kProb[((i + curBitmap.Width) % bytes) * segNumber + j] + kProb[((i + 1 + curBitmap.Width) % bytes) * segNumber + j] + kProb[((i + 1) % bytes) * segNumber + j];
                        d[i * segNumber + j] = tempSum / 8;
                        tempSum = 0;
                        for (int k = 0; k < segNumber; k++)
                            tempSum += kProb[i * segNumber + k] * (1 + d[i * segNumber + k]);
                        kProb[i * segNumber + j] *= (1 + d[i * segNumber + j]) / tempSum;
                    }
                }
            }

            for (int i = 0; i < bytes; i++)
            {
                double tempMax = 0;
                int m = 0;
                for (int j = 0; j < segNumber; j++)
                {
                    if (kProb[i * segNumber + j] > tempMax)
                    {
                        tempMax = kProb[i * segNumber + j];
                        m = j;
                    }
                }
                grayValues[i] = Convert.ToByte(m * 255 / segNumber);
            }
        }


        /************************************************************************/
        /*
         * 
         * 彩色图像处理
         * 
         */
        /************************************************************************/

        public byte[] GetColorSpace(Bitmap curBitmap, byte colorCom)
        {
            int width = curBitmap.Width;
            int height = curBitmap.Height;
            int bytes = curBitmap.Width * curBitmap.Height;
            byte[] rgbValues = new byte[bytes * 3];

            byte[] grayData = new byte[width * height];

            Color curColor;
            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    curColor = curBitmap.GetPixel(i, j);

                    rgbValues[j * width * 3 + 3 * i] = curColor.B;
                    rgbValues[j * width * 3 + 3 * i + 1] = curColor.G;
                    rgbValues[j * width * 3 + 3 * i + 2] = curColor.R;

                }
            }

            //byte colorCom = clS.GetCom;
            byte[] grayValues = new byte[bytes];
            byte tempB;
            double tempD;
            switch (colorCom)
            {
                case 0://red
                    for (int i = 0; i < bytes; i++)
                        grayValues[i] = rgbValues[i * 3 + 2];
                    break;
                case 1://green
                    for (int i = 0; i < bytes; i++)
                        grayValues[i] = rgbValues[i * 3 + 1];
                    break;
                case 2://blue;
                    for (int i = 0; i < bytes; i++)
                        grayValues[i] = rgbValues[i * 3];
                    break;
                case 3://hue
                    double theta;
                    for (int i = 0; i < bytes; i++)
                    {
                        theta = Math.Acos(0.5 * ((rgbValues[i * 3 + 2] - rgbValues[i * 3 + 1]) + (rgbValues[i * 3 + 2] - rgbValues[i * 3])) / Math.Sqrt((rgbValues[i * 3 + 2] - rgbValues[i * 3 + 1]) * (rgbValues[i * 3 + 2] - rgbValues[i * 3 + 1]) + (rgbValues[i * 3 + 2] - rgbValues[i * 3]) * (rgbValues[i * 3 + 1] - rgbValues[i * 3]) + 0.0000000001)) / (2 * Math.PI);
                        tempD = (rgbValues[i * 3] <= rgbValues[i * 3 + 1]) ? theta : (1 - theta);
                        grayValues[i] = (byte)(tempD * 255);
                    }
                    break;
                case 4://saturation
                    for (int i = 0; i < bytes; i++)
                    {
                        tempB = Math.Min(rgbValues[i * 3 + 2], rgbValues[i * 3 + 1]);
                        tempB = Math.Min(tempB, rgbValues[i * 3]);
                        tempD = 1.0 - 3.0 * tempB / (rgbValues[i * 3 + 2] + rgbValues[i * 3 + 1] + rgbValues[i * 3] + 0.0000000001);
                        grayValues[i] = (byte)(tempD * 255);
                    }
                    break;
                case 5://intensity
                    for (int i = 0; i < bytes; i++)
                        grayValues[i] = (byte)((rgbValues[i * 3] + rgbValues[i * 3 + 1] + rgbValues[i * 3 + 2]) / 3);
                    break;
                default:
                    break;
            }
            return grayValues;
        }

        public byte[] AdjustColorSpaceCom(ref Bitmap curBitmap, byte changTab, int numCom1, int numCom2, int numCom3)
        {
            int width = curBitmap.Width;
            int height = curBitmap.Height;
            int bytes = curBitmap.Width * curBitmap.Height;
            byte[] rgbValues = new byte[bytes * 3];

            byte[] tempArray = new byte[bytes * 3];

            Color curColor;
            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    curColor = curBitmap.GetPixel(i, j);

                    tempArray[j * width * 3 + 3 * i] = curColor.B;
                    tempArray[j * width * 3 + 3 * i + 1] = curColor.G;
                    tempArray[j * width * 3 + 3 * i + 2] = curColor.R;

                }
            }

            double valueCom1 = numCom1 / 100.0;
            double valueCom2 = numCom2 / 100.0;
            double valueCom3 = numCom3 / 100.0;
            double hue, sat, inten;
            double r, g, b;
            if (changTab == 0)
            {
                for (int i = 0; i < bytes; i++)
                {
                    if (valueCom1 <= 0)
                        rgbValues[i * 3 + 2] = (byte)(tempArray[i * 3 + 2] * (1.0 + valueCom1));
                    else
                        rgbValues[i * 3 + 2] = (byte)(tempArray[i * 3 + 2] + (255.0 - tempArray[i * 3 + 2]) * valueCom1);

                    if (valueCom2 <= 0)
                        rgbValues[i * 3 + 1] = (byte)(tempArray[i * 3 + 1] * (1.0 + valueCom2));
                    else
                        rgbValues[i * 3 + 1] = (byte)(tempArray[i * 3 + 1] + (255.0 - tempArray[i * 3 + 1]) * valueCom2);

                    if (valueCom3 <= 0)
                        rgbValues[i * 3] = (byte)(tempArray[i * 3] * (1.0 + valueCom3));
                    else
                        rgbValues[i * 3] = (byte)(tempArray[i * 3] + (255.0 - tempArray[i * 3]) * valueCom3);
                }
            }
            else
            {
                valueCom1 = valueCom1 * Math.PI / 1.8;
                for (int i = 0; i < bytes; i++)
                {
                    r = tempArray[i * 3 + 2] / 255.0;
                    g = tempArray[i * 3 + 1] / 255.0;
                    b = tempArray[i * 3] / 255.0;

                    double theta = Math.Acos(0.5 * ((r - g) + (r - b)) / Math.Sqrt((r - g) * (r - g) + (r - b) * (g - b) + 0.0000001)) / (2 * Math.PI);

                    hue = (b <= g) ? theta : (1 - theta);

                    sat = 1.0 - 3.0 * Math.Min(Math.Min(r, g), b) / (r + g + b + 0.0000001);

                    inten = (r + g + b) / 3.0;

                    hue = hue * 2 * Math.PI;
                    hue = (hue + valueCom1 + 2 * Math.PI) % (2 * Math.PI);

                    if (valueCom2 <= 0)
                        sat = sat * (1.0 + valueCom2);
                    else
                        sat = sat + (1.0 - sat) * valueCom2;

                    if (valueCom3 <= 0)
                        inten = inten * (1.0 + valueCom3);
                    else
                    {
                        inten = inten + (1.0 - inten) * valueCom3;
                        if (sat == 1.0)
                            sat = sat * (1 - valueCom3);
                    }

                    if (sat == 0.0)
                        hue = 0;

                    if (hue >= 0 && hue < 2 * Math.PI / 3)
                    {
                        b = inten * (1 - sat);
                        r = inten * (1 + sat * Math.Cos(hue) / Math.Cos(Math.PI / 3 - hue));
                        g = 3 * inten - (r + b);
                    }
                    else if (hue >= 2 * Math.PI / 3 && hue < 4 * Math.PI / 3)
                    {
                        r = inten * (1 - sat);
                        g = inten * (1 + sat * Math.Cos(hue - 2 * Math.PI / 3) / Math.Cos(Math.PI - hue));
                        b = 3 * inten - (r + g);
                    }
                    else //if (h >= 4 * Math.PI / 3 && h <= 2 * Math.PI)
                    {
                        g = inten * (1 - sat);
                        b = inten * (1 + sat * Math.Cos(hue - 4 * Math.PI / 3) / Math.Cos(5 * Math.PI / 3 - hue));
                        r = 3 * inten - (g + b);
                    }
                    if (r > 1)
                        r = 1;
                    if (g > 1)
                        g = 1;
                    if (b > 1)
                        b = 1;

                    rgbValues[i * 3 + 2] = (byte)(r * 255);
                    rgbValues[i * 3 + 1] = (byte)(g * 255);
                    rgbValues[i * 3] = (byte)(b * 255);
                }
            }

            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    curColor = Color.FromArgb(rgbValues[j * width * 3 + 3 * i + 2],
                        rgbValues[j * width * 3 + 3 * i + 1],
                        rgbValues[j * width * 3 + 3 * i]);

                    curBitmap.SetPixel(i, j, curColor);
                }
            }

            return rgbValues;
        }

        public void PseudoColor(ref Bitmap curBitmap, byte[] grayValues, bool method, byte seg = 4)
        {
            int bytes = curBitmap.Width * curBitmap.Height;
            // byte[] grayValues = new byte[bytes];

            //bool method = pc.GetMethod;
            //byte seg = pc.GetSeg;
            byte[] rgbValues = new byte[bytes * 3];
            Array.Clear(rgbValues, 0, bytes * 3);
            byte tempB;

            Color curColor;
            //for (int j = 0; j < curBitmap.Height; j++)
            //{
            //    for (int i = 0; i < curBitmap.Width; i++)
            //    {
            //        curColor = curBitmap.GetPixel(i, j);

            //        grayValues[j * curBitmap.Width * 3 + 3 * i] = curColor.B;
            //        grayValues[j * curBitmap.Width * 3 + 3 * i + 1] = curColor.G;
            //        grayValues[j * curBitmap.Width * 3 + 3 * i + 2] = curColor.R;

            //    }
            //}

            if (method == false)
            {
                for (int i = 0; i < bytes; i++)
                {
                    byte ser = (byte)(256 / seg);
                    tempB = (byte)(grayValues[i] / ser);
                    rgbValues[i * 3 + 1] = (byte)(tempB * ser);
                    rgbValues[i * 3] = (byte)((seg - 1 - tempB) * ser);
                    rgbValues[i * 3 + 2] = 0;
                }
            }
            else
            {
                for (int i = 0; i < bytes; i++)
                {
                    if (grayValues[i] < 64)
                    {
                        rgbValues[i * 3 + 2] = 0;
                        rgbValues[i * 3 + 1] = (byte)(4 * grayValues[i]);
                        rgbValues[i * 3] = 255;
                    }
                    else if (grayValues[i] < 128)
                    {
                        rgbValues[i * 3 + 2] = 0;
                        rgbValues[i * 3 + 1] = 255;
                        rgbValues[i * 3] = (byte)(-4 * grayValues[i] + 2 * 255);
                    }
                    else if (grayValues[i] < 192)
                    {
                        rgbValues[i * 3 + 2] = (byte)(4 * grayValues[i] - 2 * 255);
                        rgbValues[i * 3 + 1] = 255;
                        rgbValues[i * 3] = 0;
                    }
                    else
                    {
                        rgbValues[i * 3 + 2] = 255;
                        rgbValues[i * 3 + 1] = (byte)(-4 * grayValues[i] + 4 * 255);
                        rgbValues[i * 3] = 0;
                    }
                }
            }

            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = Color.FromArgb(rgbValues[j * curBitmap.Width * 3 + 3 * i + 2],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i]);

                    curBitmap.SetPixel(i, j, curColor);
                }
            }
        }

        public void EqualizationColorImage(ref Bitmap curBitmap, bool method)
        {
            int bytes = curBitmap.Width * curBitmap.Height;
            byte[] rgbValues = new byte[bytes * 3];

            Color curColor;
            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = curBitmap.GetPixel(i, j);

                    rgbValues[j * curBitmap.Width * 3 + 3 * i] = curColor.B;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1] = curColor.G;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 2] = curColor.R;

                }
            }
            //bool method = equC.GetMethod;
            if (method == false)
            {
                byte[] rValues = new byte[bytes];
                byte[] gValues = new byte[bytes];
                byte[] bValues = new byte[bytes];

                for (int i = 0; i < bytes; i++)
                {
                    rValues[i] = rgbValues[i * 3 + 2];
                    gValues[i] = rgbValues[i * 3 + 1];
                    bValues[i] = rgbValues[i * 3];
                }

                rValues = equalization(rValues);
                gValues = equalization(gValues);
                bValues = equalization(bValues);

                for (int i = 0; i < bytes; i++)
                {
                    rgbValues[i * 3 + 2] = rValues[i];
                    rgbValues[i * 3 + 1] = gValues[i];
                    rgbValues[i * 3] = bValues[i];
                }
            }
            else
            {
                double[] hue = new double[bytes];
                double[] sat = new double[bytes];
                byte[] inten = new byte[bytes];
                double r, g, b;

                for (int i = 0; i < bytes; i++)
                {
                    r = rgbValues[i * 3 + 2];
                    g = rgbValues[i * 3 + 1];
                    b = rgbValues[i * 3];

                    double theta = Math.Acos(0.5 * ((r - g) + (r - b)) / Math.Sqrt((r - g) * (r - g) + (r - b) * (g - b) + 1)) / (2 * Math.PI);

                    hue[i] = ((b <= g) ? theta : (1 - theta));

                    sat[i] = 1.0 - 3.0 * Math.Min(Math.Min(r, g), b) / (r + g + b + 1);

                    inten[i] = (byte)((r + g + b) / 3);
                }

                inten = equalization(inten);

                for (int i = 0; i < bytes; i++)
                {
                    r = rgbValues[i * 3 + 2];
                    g = rgbValues[i * 3 + 1];
                    b = rgbValues[i * 3];

                    hue[i] = hue[i] * 2 * Math.PI;
                    if (hue[i] >= 0 && hue[i] < 2 * Math.PI / 3)
                    {
                        b = inten[i] * (1 - sat[i]);
                        r = inten[i] * (1 + sat[i] * Math.Cos(hue[i]) / Math.Cos(Math.PI / 3 - hue[i]));
                        g = 3 * inten[i] - (r + b);
                    }
                    else if (hue[i] >= 2 * Math.PI / 3 && hue[i] < 4 * Math.PI / 3)
                    {
                        r = inten[i] * (1 - sat[i]);
                        g = inten[i] * (1 + sat[i] * Math.Cos(hue[i] - 2 * Math.PI / 3) / Math.Cos(Math.PI - hue[i]));
                        b = 3 * inten[i] - (r + g);
                    }
                    else //if (h >= 4 * Math.PI / 3 && h <= 2 * Math.PI)
                    {
                        g = inten[i] * (1 - sat[i]);
                        b = inten[i] * (1 + sat[i] * Math.Cos(hue[i] - 4 * Math.PI / 3) / Math.Cos(5 * Math.PI / 3 - hue[i]));
                        r = 3 * inten[i] - (g + b);
                    }
                    if (r > 255)
                        r = 255;
                    if (g > 255)
                        g = 255;
                    if (b > 255)
                        b = 255;

                    rgbValues[i * 3 + 2] = (byte)r;
                    rgbValues[i * 3 + 1] = (byte)g;
                    rgbValues[i * 3] = (byte)b;
                }
            }

            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = Color.FromArgb(rgbValues[j * curBitmap.Width * 3 + 3 * i + 2],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i]);

                    curBitmap.SetPixel(i, j, curColor);
                }
            }
        }

        private byte[] equalization(byte[] colorArray)
        {
            byte[] comValues = new byte[colorArray.Length];
            comValues = (byte[])colorArray.Clone();
            int[] countPixel = new int[256];
            byte temp;
            int[] tempArray = new int[256];
            Array.Clear(tempArray, 0, 256);
            byte[] pixelMap = new byte[256];
            for (int i = 0; i < comValues.Length; i++)
            {
                temp = comValues[i];
                countPixel[temp]++;
            }

            // 计算各灰度级的累计分布函数
            for (int i = 0; i < 256; i++)
            {
                if (i != 0)
                {
                    tempArray[i] = tempArray[i - 1] + countPixel[i];
                }
                else
                {
                    tempArray[0] = countPixel[0];
                }

                pixelMap[i] = (byte)(255.0 * tempArray[i] / comValues.Length + 0.5);
            }

            // 灰度等级映射处理
            for (int i = 0; i < comValues.Length; i++)
            {
                temp = comValues[i];
                comValues[i] = pixelMap[temp];
            }
            return comValues;
        }

        /// <summary>
        /// 彩色图像平滑处理
        /// </summary>
        /// <param name="curBitmap">待处理的图像</param>
        /// <param name="method">true or false（ture:HSI空间处理；false:RGB空间处理）</param>
        /// <param name="sideL">模板边长(3,5,7)</param>
        public void SmoothColorImage(ref Bitmap curBitmap, bool method, byte sideL = 3)
        {
            int bytes = curBitmap.Width * curBitmap.Height;
            byte[] rgbValues = new byte[bytes * 3];

            //bool method = smoothC.GetMethod;
            //byte sideL = smoothC.GetLength;
            Color curColor;
            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = curBitmap.GetPixel(i, j);

                    rgbValues[j * curBitmap.Width * 3 + 3 * i] = curColor.B;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1] = curColor.G;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 2] = curColor.R;

                }
            }

            if (method == false)
            {
                byte[] rValues = new byte[bytes];
                byte[] gValues = new byte[bytes];
                byte[] bValues = new byte[bytes];

                for (int i = 0; i < bytes; i++)
                {
                    rValues[i] = rgbValues[i * 3 + 2];
                    gValues[i] = rgbValues[i * 3 + 1];
                    bValues[i] = rgbValues[i * 3];
                }

                rValues = smooth(ref curBitmap, rValues, sideL);
                gValues = smooth(ref curBitmap, gValues, sideL);
                bValues = smooth(ref curBitmap, bValues, sideL);

                for (int i = 0; i < bytes; i++)
                {
                    rgbValues[i * 3 + 2] = rValues[i];
                    rgbValues[i * 3 + 1] = gValues[i];
                    rgbValues[i * 3] = bValues[i];
                }
            }
            else
            {
                double[] hue = new double[bytes];
                double[] sat = new double[bytes];
                byte[] inten = new byte[bytes];
                double r, g, b;

                for (int i = 0; i < bytes; i++)
                {
                    r = rgbValues[i * 3 + 2];
                    g = rgbValues[i * 3 + 1];
                    b = rgbValues[i * 3];

                    double theta = Math.Acos(0.5 * ((r - g) + (r - b)) / Math.Sqrt((r - g) * (r - g) + (r - b) * (g - b) + 1)) / (2 * Math.PI);

                    hue[i] = ((b <= g) ? theta : (1 - theta));

                    sat[i] = 1.0 - 3.0 * Math.Min(Math.Min(r, g), b) / (r + g + b + 1);

                    inten[i] = (byte)((r + g + b) / 3);
                }

                inten = smooth(ref curBitmap, inten, sideL);

                for (int i = 0; i < bytes; i++)
                {
                    r = rgbValues[i * 3 + 2];
                    g = rgbValues[i * 3 + 1];
                    b = rgbValues[i * 3];

                    hue[i] = hue[i] * 2 * Math.PI;
                    if (hue[i] >= 0 && hue[i] < 2 * Math.PI / 3)
                    {
                        b = inten[i] * (1 - sat[i]);
                        r = inten[i] * (1 + sat[i] * Math.Cos(hue[i]) / Math.Cos(Math.PI / 3 - hue[i]));
                        g = 3 * inten[i] - (r + b);
                    }
                    else if (hue[i] >= 2 * Math.PI / 3 && hue[i] < 4 * Math.PI / 3)
                    {
                        r = inten[i] * (1 - sat[i]);
                        g = inten[i] * (1 + sat[i] * Math.Cos(hue[i] - 2 * Math.PI / 3) / Math.Cos(Math.PI - hue[i]));
                        b = 3 * inten[i] - (r + g);
                    }
                    else //if (h >= 4 * Math.PI / 3 && h <= 2 * Math.PI)
                    {
                        g = inten[i] * (1 - sat[i]);
                        b = inten[i] * (1 + sat[i] * Math.Cos(hue[i] - 4 * Math.PI / 3) / Math.Cos(5 * Math.PI / 3 - hue[i]));
                        r = 3 * inten[i] - (g + b);
                    }
                    if (r > 255)
                        r = 255;
                    if (g > 255)
                        g = 255;
                    if (b > 255)
                        b = 255;

                    rgbValues[i * 3 + 2] = (byte)r;
                    rgbValues[i * 3 + 1] = (byte)g;
                    rgbValues[i * 3] = (byte)b;
                }
            }

            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = Color.FromArgb(rgbValues[j * curBitmap.Width * 3 + 3 * i + 2],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i]);

                    curBitmap.SetPixel(i, j, curColor);
                }
            }
        }

        private byte[] smooth(ref Bitmap curBitmap, byte[] comValues, byte sideLength)
        {
            byte halfLength = (byte)(sideLength / 2);
            byte[] comS = new byte[comValues.Length];
            comS = (byte[])comValues.Clone();
            byte[] comD = new byte[comS.Length];
            Array.Clear(comD, 0, comD.Length);
            switch (sideLength)
            {
                case 3:
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            comD[i * curBitmap.Width + j] = (byte)((comS[i * curBitmap.Width + j] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)]) / 9);
                        }
                    }
                    break;
                case 5:
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            comD[i * curBitmap.Width + j] = (byte)((comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2)) % curBitmap.Width] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1)) % curBitmap.Width] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + j] +
                                            comS[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)]) / 25);
                        }
                    }
                    break;
                case 7:
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            comD[i * curBitmap.Width + j] = (byte)((comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2)) % curBitmap.Width] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1)) % curBitmap.Width] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + j] +
                                            comS[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 3)) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + ((j + 3) % curBitmap.Width)] +
                                            comS[i * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)] +
                                            comS[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)] +
                                            comS[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)] +
                                            comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)] +
                                            comS[((i + 3) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                            comS[((i + 3) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                            comS[((i + 3) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                            comS[((i + 3) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                            comS[((i + 3) % curBitmap.Height) * curBitmap.Width + j] +
                                            comS[((i + 3) % curBitmap.Height) * curBitmap.Width + ((j + 3) % curBitmap.Width)] +
                                            comS[((i + 3) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 3) % curBitmap.Width)]) / 49);
                        }
                    }
                    break;
                default:
                    break;
            }
            return comD;
        }

        /// <summary>
        /// 彩色图像钝化处理
        /// </summary>
        /// <param name="curBitmap">待处理的图像</param>
        /// <param name="method">true or false（ture:HSI空间处理；false:RGB空间处理）</param>
        public void SharpColorImage(ref Bitmap curBitmap, bool method)
        {
            int bytes = curBitmap.Width * curBitmap.Height;
            byte[] rgbValues = new byte[bytes * 3];

            //bool method = sharpC.GetMethod;
            Color curColor;
            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = curBitmap.GetPixel(i, j);

                    rgbValues[j * curBitmap.Width * 3 + 3 * i] = curColor.B;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1] = curColor.G;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 2] = curColor.R;

                }
            }
            if (method == false)
            {
                byte[] rValues = new byte[bytes];
                byte[] gValues = new byte[bytes];
                byte[] bValues = new byte[bytes];

                for (int i = 0; i < bytes; i++)
                {
                    rValues[i] = rgbValues[i * 3 + 2];
                    gValues[i] = rgbValues[i * 3 + 1];
                    bValues[i] = rgbValues[i * 3];
                }

                rValues = sharp(ref curBitmap, rValues);
                gValues = sharp(ref curBitmap, gValues);
                bValues = sharp(ref curBitmap, bValues);

                for (int i = 0; i < bytes; i++)
                {
                    rgbValues[i * 3 + 2] = rValues[i];
                    rgbValues[i * 3 + 1] = gValues[i];
                    rgbValues[i * 3] = bValues[i];
                }
            }
            else
            {
                double[] hue = new double[bytes];
                double[] sat = new double[bytes];
                byte[] inten = new byte[bytes];
                double r, g, b;

                for (int i = 0; i < bytes; i++)
                {
                    r = rgbValues[i * 3 + 2];
                    g = rgbValues[i * 3 + 1];
                    b = rgbValues[i * 3];

                    double theta = Math.Acos(0.5 * ((r - g) + (r - b)) / Math.Sqrt((r - g) * (r - g) + (r - b) * (g - b) + 1)) / (2 * Math.PI);

                    hue[i] = ((b <= g) ? theta : (1 - theta));

                    sat[i] = 1.0 - 3.0 * Math.Min(Math.Min(r, g), b) / (r + g + b + 1);

                    inten[i] = (byte)((r + g + b) / 3);
                }

                inten = sharp(ref curBitmap, inten);

                for (int i = 0; i < bytes; i++)
                {
                    r = rgbValues[i * 3 + 2];
                    g = rgbValues[i * 3 + 1];
                    b = rgbValues[i * 3];

                    hue[i] = hue[i] * 2 * Math.PI;
                    if (hue[i] >= 0 && hue[i] < 2 * Math.PI / 3)
                    {
                        b = inten[i] * (1 - sat[i]);
                        r = inten[i] * (1 + sat[i] * Math.Cos(hue[i]) / Math.Cos(Math.PI / 3 - hue[i]));
                        g = 3 * inten[i] - (r + b);
                    }
                    else if (hue[i] >= 2 * Math.PI / 3 && hue[i] < 4 * Math.PI / 3)
                    {
                        r = inten[i] * (1 - sat[i]);
                        g = inten[i] * (1 + sat[i] * Math.Cos(hue[i] - 2 * Math.PI / 3) / Math.Cos(Math.PI - hue[i]));
                        b = 3 * inten[i] - (r + g);
                    }
                    else //if (h >= 4 * Math.PI / 3 && h <= 2 * Math.PI)
                    {
                        g = inten[i] * (1 - sat[i]);
                        b = inten[i] * (1 + sat[i] * Math.Cos(hue[i] - 4 * Math.PI / 3) / Math.Cos(5 * Math.PI / 3 - hue[i]));
                        r = 3 * inten[i] - (g + b);
                    }
                    if (r > 255)
                        r = 255;
                    if (g > 255)
                        g = 255;
                    if (b > 255)
                        b = 255;

                    rgbValues[i * 3 + 2] = (byte)r;
                    rgbValues[i * 3 + 1] = (byte)g;
                    rgbValues[i * 3] = (byte)b;
                }
            }

            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = Color.FromArgb(rgbValues[j * curBitmap.Width * 3 + 3 * i + 2],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i]);

                    curBitmap.SetPixel(i, j, curColor);
                }
            }
        }

        private byte[] sharp(ref Bitmap curBitmap, byte[] comArray)
        {
            byte[] comValues = new byte[comArray.Length];

            for (int i = 0; i < curBitmap.Height; i++)
            {
                for (int j = 0; j < curBitmap.Width; j++)
                {
                    comValues[i * curBitmap.Width + j] = (byte)(5 * comArray[i * curBitmap.Width + j] -
                        (comArray[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] +
                        comArray[((i + 1) % curBitmap.Height) * curBitmap.Width + j] +
                        comArray[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                        comArray[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)]));
                }
            }
            return comValues;
        }

        /// <summary>
        /// 彩色图像边缘检测
        /// </summary>
        /// <param name="curBitmap">待处理的图像</param>
        /// <param name="grayValues">接受处理后的数据</param>
        /// <param name="method">检测方法（0：向量法一； 1：向量法二； 2：直接梯度法）</param>
        /// <param name="thresh">阈值（0到255）</param>
        public void ColorImageEdge(ref Bitmap curBitmap, out byte[] grayValues, byte method, int thresh = 0)
        {
            int bytes = curBitmap.Width * curBitmap.Height;
            byte[] rgbValues = new byte[bytes * 3];

            //byte method = edgedetC.GetMethod;
            //int thresh = edgedetC.GetThresholding;

            Color curColor;
            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = curBitmap.GetPixel(i, j);

                    rgbValues[j * curBitmap.Width * 3 + 3 * i] = curColor.B;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1] = curColor.G;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 2] = curColor.R;

                }
            }

            grayValues = new byte[bytes];
            double[] tempArray = new double[bytes];
            byte[] rValues = new byte[bytes];
            byte[] gValues = new byte[bytes];
            byte[] bValues = new byte[bytes];
            for (int i = 0; i < bytes; i++)
            {
                rValues[i] = rgbValues[i * 3 + 2];
                gValues[i] = rgbValues[i * 3 + 1];
                bValues[i] = rgbValues[i * 3];
            }
            double maxV = 0.0;
            double minV = 1000.0;

            switch (method)
            {
                case 0:
                    double grh, ggh, gbh;
                    double grv, ggv, gbv;
                    double gxx, gyy, gxy;
                    double ge1, ge2;
                    double theta;

                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            grh = rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * rValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * rValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];
                            ggh = gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * gValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * gValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];
                            gbh = bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * bValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * bValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];

                            grv = rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            ggv = gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            gbv = bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];

                            gxx = grh * grh + ggh * ggh + gbh * gbh;
                            gyy = grv * grv + ggv * ggv + gbv * gbv;
                            gxy = grh * grv + ggh * ggv + gbh * gbv;

                            theta = Math.Atan(2 * gxy / (gxx - gyy + 0.000000001)) / 2;
                            ge1 = ((gxx + gyy) + (gxx - gyy) * Math.Cos(2 * theta) + 2 * gxy * Math.Sin(2 * theta)) / 2;
                            theta = theta + Math.PI / 2;
                            ge2 = ((gxx + gyy) + (gxx - gyy) * Math.Cos(2 * theta) + 2 * gxy * Math.Sin(2 * theta)) / 2;
                            tempArray[i * curBitmap.Width + j] = Math.Max(Math.Sqrt(ge1), Math.Sqrt(ge2));

                            if (tempArray[i * curBitmap.Width + j] > maxV)
                                maxV = tempArray[i * curBitmap.Width + j];
                            else if (tempArray[i * curBitmap.Width + j] < minV)
                                minV = tempArray[i * curBitmap.Width + j];

                        }
                    }

                    for (int i = 0; i < bytes; i++)
                    {
                        grayValues[i] = (byte)((tempArray[i] - minV) * 255 / (maxV - minV));
                    }
                    break;
                case 1:
                    double gr, gg, gb;
                    double de1, de2;

                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            gr = rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * rValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * rValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];
                            gg = gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * gValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * gValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];
                            gb = bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * bValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * bValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];

                            de1 = Math.Sqrt(gr * gr + gg * gg + gb * gb);

                            gr = rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            gg = gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            gb = bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];

                            de2 = Math.Sqrt(gr * gr + gg * gg + gb * gb);
                            tempArray[i * curBitmap.Width + j] = Math.Max(de1, de2);

                            if (tempArray[i * curBitmap.Width + j] > maxV)
                                maxV = tempArray[i * curBitmap.Width + j];
                            else if (tempArray[i * curBitmap.Width + j] < minV)
                                minV = tempArray[i * curBitmap.Width + j];
                        }
                    }

                    for (int i = 0; i < bytes; i++)
                    {
                        grayValues[i] = (byte)((tempArray[i] - minV) * 255 / (maxV - minV));
                    }
                    break;
                case 2:
                    double[] rvg = new double[bytes];
                    double[] gvg = new double[bytes];
                    double[] bvg = new double[bytes];
                    double gh, gv;
                    double[] maxValue = new double[3] { 0.0, 0.0, 0.0 };
                    double[] minValue = new double[3] { 1000.0, 1000.0, 1000.0 };

                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            gh = rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * rValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * rValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];
                            gv = rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + rValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - rValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            rvg[i * curBitmap.Width + j] = Math.Sqrt(gh * gh + gv * gv);
                            if (rvg[i * curBitmap.Width + j] > maxValue[0])
                                maxValue[0] = rvg[i * curBitmap.Width + j];
                            else if (rvg[i * curBitmap.Width + j] < minValue[0])
                                minValue[0] = rvg[i * curBitmap.Width + j];

                            gh = gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * gValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * gValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];
                            gv = gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + gValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - gValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            gvg[i * curBitmap.Width + j] = Math.Sqrt(gh * gh + gv * gv);
                            if (gvg[i * curBitmap.Width + j] > maxValue[1])
                                maxValue[1] = gvg[i * curBitmap.Width + j];
                            else if (gvg[i * curBitmap.Width + j] < minValue[1])
                                minValue[1] = gvg[i * curBitmap.Width + j];

                            gh = bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] + 2 * bValues[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] + bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * bValues[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)];
                            gv = bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] + 2 * bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] + bValues[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] -
                                bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] - 2 * bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + j] - bValues[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)];
                            bvg[i * curBitmap.Width + j] = Math.Sqrt(gh * gh + gv * gv);
                            if (bvg[i * curBitmap.Width + j] > maxValue[2])
                                maxValue[2] = bvg[i * curBitmap.Width + j];
                            else if (bvg[i * curBitmap.Width + j] < minValue[2])
                                minValue[2] = rvg[i * curBitmap.Width + j];
                        }
                    }

                    for (int i = 0; i < bytes; i++)
                    {
                        rgbValues[i * 3 + 2] = (byte)((rvg[i] - minValue[0]) * 255 / (maxValue[0] - minValue[0]));
                        rgbValues[i * 3 + 1] = (byte)((gvg[i] - minValue[1]) * 255 / (maxValue[1] - minValue[1]));
                        rgbValues[i * 3] = (byte)((bvg[i] - minValue[2]) * 255 / (maxValue[2] - minValue[2]));
                        gh = Math.Max((rvg[i] - minValue[0]) * 255 / (maxValue[0] - minValue[0]), (gvg[i] - minValue[1]) * 255 / (maxValue[1] - minValue[1]));
                        gv = Math.Max(gh, (bvg[i] - minValue[2]) * 255 / (maxValue[2] - minValue[2]));
                        grayValues[i] = (byte)(gv);
                    }
                    break;
                default:
                    break;
            }
            if (thresh != 0)
            {
                for (int i = 0; i < bytes; i++)
                {
                    if (grayValues[i] > thresh)
                        grayValues[i] = 255;
                    else
                        grayValues[i] = 0;
                }
            }

        }

        /// <summary>
        /// 彩色图像K—均值聚类分割
        /// </summary>
        /// <param name="curBitmap">待处理的图像</param>
        /// <param name="numbers">阈值（从2到20）</param>
        public void ColorSeg(ref Bitmap curBitmap, byte numbers = 2)
        {
            int bytes = curBitmap.Width * curBitmap.Height;
            byte[] rgbValues = new byte[bytes * 3];

            //byte numbers = segmentationC.GetNum;

            Color curColor;
            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = curBitmap.GetPixel(i, j);

                    rgbValues[j * curBitmap.Width * 3 + 3 * i] = curColor.B;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1] = curColor.G;
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 2] = curColor.R;

                }
            }

            int[] kNum = new int[numbers];
            int[] kAver = new int[numbers * 3];
            int[] kOldAver = new int[numbers * 3];
            int[] kSum = new int[numbers * 3];
            double[] kTemp = new double[numbers];
            byte[] segmentMap = new byte[bytes * 3];
            //初始化聚类均值
            for (int i = 0; i < numbers; i++)
            {

                kAver[i * 3 + 2] = kOldAver[i * 3 + 2] = Convert.ToInt16(i * 255 / (numbers - 1));
                kAver[i * 3 + 1] = kOldAver[i * 3 + 1] = Convert.ToInt16(i * 255 / (numbers - 1));
                kAver[i * 3] = kOldAver[i * 3] = Convert.ToInt16(i * 255 / (numbers - 1));
            }
            int count = 0;
            while (true)
            {
                int order = 0;
                for (int i = 0; i < numbers; i++)
                {
                    kNum[i] = 0;
                    kSum[i * 3 + 2] = kSum[i * 3 + 1] = kSum[i * 3] = 0;
                    kAver[i * 3 + 2] = kOldAver[i * 3 + 2];
                    kAver[i * 3 + 1] = kOldAver[i * 3 + 1];
                    kAver[i * 3] = kOldAver[i * 3];
                }
                //归属聚类
                for (int i = 0; i < bytes; i++)
                {
                    for (int j = 0; j < numbers; j++)
                    {
                        kTemp[j] = Math.Pow(rgbValues[i * 3 + 2] - kAver[j * 3 + 2], 2) + Math.Pow(rgbValues[i * 3 + 1] - kAver[j * 3 + 1], 2) + Math.Pow(rgbValues[i * 3] - kAver[j * 3], 2);
                    }
                    double temp = 100000;

                    for (int j = 0; j < numbers; j++)
                    {
                        if (kTemp[j] < temp)
                        {
                            temp = kTemp[j];
                            order = j;
                        }
                    }
                    kNum[order]++;
                    kSum[order * 3 + 2] += rgbValues[i * 3 + 2];
                    kSum[order * 3 + 1] += rgbValues[i * 3 + 1];
                    kSum[order * 3] += rgbValues[i * 3];
                    segmentMap[i] = Convert.ToByte(order);
                }
                for (int i = 0; i < numbers; i++)
                {
                    if (kNum[i] != 0)
                    {
                        kOldAver[i * 3 + 2] = Convert.ToInt16(kSum[i * 3 + 2] / kNum[i]);
                        kOldAver[i * 3 + 1] = Convert.ToInt16(kSum[i * 3 + 1] / kNum[i]);
                        kOldAver[i * 3] = Convert.ToInt16(kSum[i * 3] / kNum[i]);
                    }
                }

                int kkk = 0;
                count++;
                for (int i = 0; i < numbers; i++)
                {
                    if (kAver[i * 3 + 2] == kOldAver[i * 3 + 2] && kAver[i * 3 + 1] == kOldAver[i * 3 + 1] && kAver[i * 3] == kOldAver[i * 3])
                        kkk++;
                }
                if (kkk == numbers || count == 100)
                    break;
            }

            for (int i = 0; i < bytes; i++)
            {
                for (int j = 0; j < numbers; j++)
                {
                    if (segmentMap[i] == j)
                    {
                        rgbValues[i * 3 + 2] = Convert.ToByte(kAver[j * 3 + 2]);
                        rgbValues[i * 3 + 1] = Convert.ToByte(kAver[j * 3 + 1]);
                        rgbValues[i * 3] = Convert.ToByte(kAver[j * 3]);
                    }
                }
            }

            for (int j = 0; j < curBitmap.Height; j++)
            {
                for (int i = 0; i < curBitmap.Width; i++)
                {
                    curColor = Color.FromArgb(rgbValues[j * curBitmap.Width * 3 + 3 * i + 2],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i + 1],
                    rgbValues[j * curBitmap.Width * 3 + 3 * i]);

                    curBitmap.SetPixel(i, j, curColor);
                }
            }
        }

        //
    }
}
