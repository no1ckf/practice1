﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Text;

namespace ClassLibraryQikuo
{
    public class Connect
    {
        public SqlConnection ReturnSqlConnection()
        {
            string ConnectString = Read();
            SqlConnection myConnection = new SqlConnection();
            myConnection = new SqlConnection(ConnectString);
            return myConnection;
        }

        public SqlConnection ReturnSqlConnection(string connectString)
        {
            SqlConnection myConnection = new SqlConnection(connectString);
            
            return myConnection;
        }

        public string Read()
        {
            string path = Directory.GetCurrentDirectory() + "\\connect.txt";
            try
            {
                StreamReader sr = new StreamReader(path, Encoding.Default);
                String line;
                line = sr.ReadLine();
                
                return line.ToString();
                
            }
            catch
            {
                return "";
            }
        }
    }
}
