﻿using System.Collections;
using Newtonsoft.Json;
using System.Data;
using System.IO;

namespace ClassLibraryQikuo
{
    public class JSONOperation
    {
        public string ArrayListToJSON(string arrName, ArrayList convertArr)
        {
            return JsonConvert.SerializeObject(convertArr);
        }

        public string DataTableToJson(string tableName,DataTable newData)
        {
            return JsonConvert.SerializeObject(newData);
        }

       public ArrayList JSONToArrayList(string JSONString)
        {
            JsonReader reader = new JsonTextReader(new StringReader(JSONString));
            
            ArrayList newArr = new ArrayList();
            string outstr = "";
            int i = 0;
            
            while (reader.Read())
            {
                //try
                //{
                //    DataObject newData = new DataObject();
                //    newData.dataColumn = reader.TokenType.ToString();
                //    newData.dataValue = reader.Value.ToString();
                //    newData.dataType = reader.ValueType.ToString();
                //    newArr.Add(newData);
                //}
                //catch
                //{

                //}

                string test = reader.TokenType.ToString();
                if (reader.TokenType.ToString().Trim() == "PropertyName")
                {
                    DataObject newData = new DataObject();
                    newData.dataColumn = reader.Value.ToString();
                    newData.dataValue = "0";
                    newData.dataType = "String";
                    newArr.Add(newData);

                }
                else
                {
                    if (reader.TokenType.ToString().Trim() != "StartObject"&& reader.TokenType.ToString().Trim() !="EndObject")
                    {
                        ((DataObject)newArr[i]).dataValue = reader.Value.ToString();
                        i++;

                    }
                }
                // outstr= outstr+reader.TokenType + "\t\t" + reader.ValueType.Name + "\t\t" + reader.Value;
            }
            return newArr;
        }

        public string ReturnValueByDataColumn(ArrayList newArr,string DataColumnValue)
        {
            string outString = "";
            for(int i=0;i<newArr.Count;i++)
            {
                if(((DataObject)newArr[i]).dataColumn==DataColumnValue)
                {
                    outString = ((DataObject)newArr[i]).dataValue;
                    break;
                }
            }
            return outString;
        }

        public string ArrayListToJSON(string arrName, ArrayList convertArr,string topNameColumn)
        {
            string outString = "";
            for (int i = 0; i < convertArr.Count; i++)
            {
                string cString = string.Empty;
                foreach (System.Reflection.PropertyInfo p in convertArr[i].GetType().GetProperties())
                {
                    //p.GetValue()
                    cString = cString + ",\"" + p.Name + "\"" + ":" + "\"" + p.GetValue(convertArr[i], null).ToString() + "\"";
                }
                cString = cString.Substring(1);
                cString = ",{" + cString + "}";
                outString = outString + cString;
            }
            outString = "{" + arrName + ":[" + outString.Substring(1) + "]" + "}";
            return outString;
        }

        //public object JSONToObject(string JSONString)
        //{
        //    object newObject = new object();
        //    JsonReader reader = new JsonTextReader(new StringReader(jsonText));
        //}

        public string getProperties<T>(T t)
        {
            string tStr = string.Empty;
            if (t == null)
            {
                return tStr;
            }
            System.Reflection.PropertyInfo[] properties = t.GetType().GetProperties(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);

            if (properties.Length <= 0)
            {
                return tStr;
            }
            foreach (System.Reflection.PropertyInfo item in properties)
            {
                string name = item.Name;
                object value = item.GetValue(t, null);
                if (item.PropertyType.IsValueType || item.PropertyType.Name.StartsWith("String"))
                {
                    tStr += string.Format("{0}:{1},", name, value);
                }
                else
                {
                    getProperties(value);
                }
            }
            return tStr;
        }

        
    }


}
