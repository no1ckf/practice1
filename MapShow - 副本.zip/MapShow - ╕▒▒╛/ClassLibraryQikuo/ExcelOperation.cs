﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text;

namespace ClassLibraryQikuo
{
    public class ExcelOperation
    {
        public System.Data.DataTable ExcelToDataTable(string setText, string[] columnArr, int beginLine)
        {

            string s = string.Empty;
            System.Data.DataTable xlsTable = new System.Data.DataTable();
            DataRow dr;

            int z = 0;
            z = columnArr.Length;

            for(int i=0;i<columnArr.Length;i++)
            {
                xlsTable.Columns.Add(columnArr[i], typeof(string));
            }

            object missing = System.Reflection.Missing.Value;
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            excel.Visible = false;
            excel.UserControl = true;
            // 以只读的形式打开EXCEL文件
            Workbook wb = excel.Application.Workbooks.Open(setText, missing, true, missing, missing, missing,
             missing, missing, missing, true, missing, missing, missing, missing, missing);
            //取得第一个工作薄
            Worksheet ws = (Worksheet)wb.Worksheets.get_Item(1);
            Microsoft.Office.Interop.Excel._Worksheet sh;
            sh = (Microsoft.Office.Interop.Excel._Worksheet)excel.Worksheets.get_Item(1);


            //取得总记录行数   (包括标题列)
            int rowsint = ws.UsedRange.Cells.Rows.Count; //得到行数
                                                         //int columnsint = mySheet.UsedRange.Cells.Columns.Count;//得到列数
                                                         //取得数据范围区域 (不包括标题列) 


            for (int i = beginLine; i < rowsint + 1; i++)
            {

                dr = xlsTable.NewRow();
                for (int j = 0; j < z; j++)
                {
                    dr[j] = ((Microsoft.Office.Interop.Excel.Range)sh.Cells[i, j + 1]).Text.ToString();
                    //s = s + ((Microsoft.Office.Interop.Excel.Range)sh.Cells[i, j + 1]).Text.ToString() + "$";
                }

                xlsTable.Rows.Add(dr);

            }
            excel.Quit(); excel = null;
            Process[] procs = Process.GetProcessesByName("excel");

            foreach (Process pro in procs)
            {
                pro.Kill();//没有更好的方法,只有杀掉进程
            }
            GC.Collect();

            return xlsTable;
        }
    }
}
