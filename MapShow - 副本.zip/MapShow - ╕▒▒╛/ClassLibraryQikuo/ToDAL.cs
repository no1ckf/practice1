﻿using ClassLibraryQikuo;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace ClassLibraryQikuo
{
    public class ToDAL<T>
    {
        #region 公共的参数及方法
        DBOperation newDB;
        string connectString = "";

        public ToDAL(string conString)//把数据库连接字符串传入到数据操作类中，进行数据操作
        {
            newDB = new DBOperation(conString);//把数据库连接语句传递入qikuo类库中
            connectString = conString;
        }
        #endregion

        #region 对象的操作方法
        /// <summary>
        /// 添加一个数据对象到数据库中
        /// </summary>
        /// <param name="newObject">所要添加的数据对象</param>
        /// <param name="editStatus">返回的添加状态字符串</param>
        /// <returns></returns>
        public bool AddObject(T newObject, ref string editStatus)
        {
            String columnString = "";
            string valueString = "";

            Type type = newObject.GetType();
            System.Reflection.PropertyInfo[] ps = type.GetProperties();

            foreach (PropertyInfo i in ps)
            {
                object obj = i.GetValue(newObject, null);
                if (obj != null)
                {
                    string proType = i.PropertyType.ToString();
                    string name = i.Name;

                    if (proType == "System.Nullable`1[System.Int32]" || proType == "System.Int32")
                    {
                        if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                        {
                            if (int.Parse(obj.ToString()) > -1)
                            {
                                columnString = columnString + i.Name + ",";
                                valueString = valueString + "" + obj.ToString() + ",";
                            }
                        }
                    }
                    else
                    {
                        if (proType == "System.Nullable`1[System.Decmial]" || proType == "System.Decmial")
                        {
                            if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                            {
                                if (float.Parse(obj.ToString()) > -1)
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "" + obj.ToString() + ",";
                                }
                            }
                        }
                        else
                        {
                            if (proType == "System.DateTime" || proType == "System.Nullable`1[System.DateTime]")
                            {
                                if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "'" + obj.ToString() + "',";
                                }
                            }
                            else
                            {
                                if (obj != null)//下面3个if语句是判定对象
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "'" + obj.ToString() + "',";
                                }
                            }
                        }
                    }
                }

            }


            if (columnString.IndexOf(",") > 0)//判定是否需要进行更新
            {
                columnString = columnString.Substring(0, columnString.Length - 1);//对于更新字符串进行处理，因为字符串构建方法在最后会多出来一个逗号，所以需要把字后的逗号去掉
                valueString = valueString.Substring(0, valueString.Length - 1);
                string updateString = " insert "+ type.Name+" (" + columnString + ") values (" + valueString + ")";
                //拼接更新字符串，设定更新条件

                return newDB.update(updateString);//执行数据库更新语句，更新数据库，返回执行状态
            }
            else
            {
                editStatus = " no update parameter";//错误代表没有传入更新参数
                return false;
            }
        }

        /// <summary>
        /// 添加一个数据对象到数据库中，并将刚刚添加的数据对象编号返回
        /// </summary>
        /// <param name="newObject">需要添加的数据对象</param>
        /// <param name="editStatus">返回的添加转台字符串</param>
        /// <param name="addObjectId">返回的刚刚添加对象的编号</param>
        /// <returns></returns>
        public bool AddObject(T newObject, ref string editStatus,ref int addObjectId)
        {
            String columnString = "";
            string valueString = "";

            Type type = newObject.GetType();
            System.Reflection.PropertyInfo[] ps = type.GetProperties();

            foreach (PropertyInfo i in ps)
            {
                object obj = i.GetValue(newObject, null);
                if (obj != null)
                {
                    string proType = i.PropertyType.ToString();
                    string name = i.Name;

                    if (proType == "System.Nullable`1[System.Int32]" || proType == "System.Int32")
                    {
                        if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                        {
                            if (int.Parse(obj.ToString()) > -1)
                            {
                                columnString = columnString + i.Name + ",";
                                valueString = valueString + "" + obj.ToString() + ",";
                            }
                        }
                    }
                    else
                    {
                        if (proType == "System.Nullable`1[System.Decmial]" || proType == "System.Decmial")
                        {
                            if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                            {
                                if (float.Parse(obj.ToString()) > -1)
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "" + obj.ToString() + ",";
                                }
                            }
                        }
                        else
                        {
                            if (proType == "System.DateTime" || proType == "System.Nullable`1[System.DateTime]")
                            {
                                if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "'" + obj.ToString() + "',";
                                }
                            }
                            else
                            {
                                if (obj != null)//下面3个if语句是判定对象
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "'" + obj.ToString() + "',";
                                }
                            }
                        }
                    }
                }

            }


            if (columnString.IndexOf(",") > 0)//判定是否需要进行更新
            {
                columnString = columnString.Substring(0, columnString.Length - 1);//对于更新字符串进行处理，因为字符串构建方法在最后会多出来一个逗号，所以需要把字后的逗号去掉
                valueString = valueString.Substring(0, valueString.Length - 1);
                string updateString = " insert " + type.Name + " (" + columnString + ") values (" + valueString + ")";
                //拼接更新字符串，设定更新条件
                string idString = "SELECT   IDENT_CURRENT('"+ type.Name + "')  as topid";
                addObjectId =Convert.ToInt32(newDB.returndata(idString, "topid"));
                return newDB.update(updateString);//执行数据库更新语句，更新数据库，返回执行状态
            }
            else
            {
                editStatus = " no update parameter";//错误代表没有传入更新参数
                return false;
            }
        }

        /// <summary>
        /// 修改数据库中的对象
        /// </summary>
        /// <param name="newObject">新的修改对象</param>
        /// <param name="editStatus">返回的修改状态信息</param>
        /// <returns></returns>
        public bool EditObject(T newObject,ref string editStatus)//更新一个taskeventanswer对象，方法命名规则Edit+对象名，这里必须设定id的值
        {//这里采用的是反射参数方法，editStatus是返回更新的具体问题所在，调用方法的时候可以直接用
            

            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            string setValueName = "";
            int setValuePro = 0;
            string updateString = "update " + t.Name + " set ";//首先设定更新字符串的初始值
            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化
            _obj = newObject;
            foreach (PropertyInfo pi in pc)
            {
                if (pi.Name.Equals("id"))//判断属性的类型是不是String
                {
                    setValueName = pi.Name;
                    setValuePro = (int)pi.GetValue((T)_obj, null);
                    break;
                }
            }

            
            Type type = newObject.GetType();
            System.Reflection.PropertyInfo[] ps = type.GetProperties();

            foreach (PropertyInfo i in ps)
            {
                object obj = i.GetValue(newObject, null);
                if (obj != null)
                {
                    string proType = obj.GetType().ToString();
                    string name = i.Name;

                    if (proType == "System.Nullable`1[System.Int32]" || proType == "System.Int32")
                    {
                        if (i.Name != "id" && i.Name != "username")
                        {
                            if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                            {
                                updateString = updateString + " " + i.Name + "=" + obj.ToString() + ",";
                            }
                        }
                    }
                    else
                    {
                        if (proType == "System.Nullable`1[System.Decmial]" || proType == "System.Decmial")
                        {
                            if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                            {
                                updateString = updateString + " " + i.Name + "=" + obj.ToString() + ",";
                            }
                        }
                        else
                        {
                            if (proType == "System.DateTime" || proType == "System.Nullable`1[System.DateTime]")
                            {
                                if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                                {
                                    updateString = updateString + " " + i.Name + "='" + obj.ToString() + "',";
                                }
                            }
                            else
                            {
                                if (obj != null)//下面3个if语句是判定对象
                                {
                                    updateString = updateString + " " + i.Name + "='" + obj.ToString() + "',";
                                }
                            }
                        }
                    }
                }

            }
            if (updateString.IndexOf("=") > 0)//判定是否需要进行更新
            {
                updateString = updateString.Substring(0, updateString.Length - 1);//对于更新字符串进行处理，因为字符串构建方法在最后会多出来一个逗号，所以需要把字后的逗号去掉
                updateString = updateString + " where id=" + setValuePro + "";//拼接更新字符串，设定更新条件

                return newDB.update(updateString);//执行数据库更新语句，更新数据库，返回执行状态
            }
            else
            {
                editStatus = " no update parameter";//错误代表没有传入更新参数
                return false;
            }
            
        }

        /// <summary>
        /// 删除一个对象
        /// </summary>
        /// <param name="newObject">所要删除的对象</param>
        /// <param name="deleteStatus">返回删除的状态</param>
        /// <returns></returns>
        public bool DeleteObject(T newObject, ref string deleteStatus)//删除一个taskeventanswer对象，方法命名规则Delete+对象名，这里必须设定id的值
        {//这里采用的是反射参数方法，deleteStatus是返回更新的具体问题所在，调用方法的时候可以直接用
            int setValuePro = (int)ReturnValue(newObject, "id");
            Type type = newObject.GetType();
            newObject = ReturnObject(setValuePro);
            setValuePro= (int)ReturnValue(newObject, "id");

            if (setValuePro > 0) //判定是否有和oldtaskeventanswer的id对应的数据
            {
                string deleteString = "delete "+type.Name+" where id=" + setValuePro + "";
                return newDB.update(deleteString);
            }
            else
            {
                deleteStatus = " no such data";//错误代表没有与id对应的数据
                return false;
            }
        }
        #endregion

        #region 对象的返回
        /// <summary>
        /// 通过id返回一个对象
        /// </summary>
        /// <param name="id">对象的编号</param>
        /// <returns></returns>
        public T ReturnObject(int id)//返回数据
        {
            System.Type t = typeof(T);
            string selectString = "select * from " + t.Name + " where id=" + id + "";
            T newObject = newDB.returndata<T>(selectString);
            return newObject;//返回taskeventanswer对象
        }

        /// <summary>
        /// 通过一定的查询条件返回一个对象
        /// </summary>
        /// <param name="strWhere">查询条件</param>
        /// <returns></returns>
        public T ReturnObject(string strWhere)//这里用的是多态，可以在strwhere可以添加order by语句
        {
            System.Type t = typeof(T);
            string selectString = "select * from " + t.Name + " where 1=1 and "+strWhere;
            T newObject = newDB.returndata<T>(selectString);
            return newObject;//返回taskeventanswer对象
        }

        /// <summary>
        /// 多表联合查询一个对象返回，需要完整的查询语句
        /// </summary>
        /// <param name="strWhere"></param>
        /// <returns></returns>
        public T ReturnJoinObject(string strWhere)//这里用的是多态，可以在strwhere可以添加order by语句
        {
            System.Type t = typeof(T);
            T newObject = newDB.returndata<T>(strWhere);
            return newObject;//返回taskeventanswer对象
        }
        #endregion

        #region 集合的返回
        /// <summary>
        /// 返回数据集合，以分页的形式显示
        /// </summary>
        /// <param name="strWhere">查询条件</param>
        /// <param name="pageNO">当前显示的页码</param>
        /// <param name="pagePer">每页显示数据的条数</param>
        /// <returns></returns>
        public List<T> ReturnObjectList(string strWhere, int pageNO, int pagePer)
        {
            System.Type t = typeof(T);
            return newDB.returndatalist<T>(strWhere,t.Name,pagePer,pageNO,1,"*","id");
        }

        /// <summary>
        /// 返回数据集合，以分页的形式显示
        /// </summary>
        /// <param name="strWhere">查询条件</param>
        /// <param name="pageNO">当前显示的页面</param>
        /// <param name="pagePer">每页显示的数据条数</param>
        /// <param name="TotalPage">返回的总的页数</param>
        /// <param name="TotalItem">总共的数据条目数</param>
        /// <returns></returns>
        public List<T> ReturnObjectList(string strWhere, int pageNO, int pagePer,ref int TotalPage,ref int TotalItem)
        {
            System.Type t = typeof(T);
            return newDB.returndatalist<T>(strWhere, t.Name, pagePer, pageNO, 1, "*", "id",ref TotalPage,ref TotalItem);
        }

        /// <summary>
        /// 返回数据结合，全部显示
        /// </summary>
        /// <param name="strWhere">显示查询条件</param>
        /// <returns></returns>
        public List<T> ReturnObjectList(string strWhere)
        {
            System.Type t = typeof(T);
            return newDB.returndatalist<T>(strWhere);
        }

        /// <summary>
        /// 返回数据集合，多表联合查询，全部显示
        /// </summary>
        /// <param name="strWhere"></param>
        /// <returns></returns>
        public List<T> ReturnObjectListForJoin(string strWhere)
        {
            System.Type t = typeof(T);
            return newDB.returndatalistforjoin<T>(strWhere);
        }

        /// <summary>
        /// 返回数据集合，以分页形式显示，多查询条件，多表联合查询
        /// </summary>
        /// <param name="tableName">表格名称，多表名称，table1 join table2</param>
        /// <param name="seleColString">查询的列</param>
        /// <param name="strWhere">查询条件</param>
        /// <param name="pageNO">当前页面</param>
        /// <param name="pagePer">每页显示数据数量</param>
        /// <param name="orderId">排序条件</param>
        /// <returns></returns>
        public List<T> ReturnObjectListForJoin(string tableName,string seleColString,string strWhere, int pageNO, int pagePer,string orderId)
        {
            System.Type t = typeof(T);
            return newDB.returndatalistforjoin<T>(strWhere,tableName,pagePer,pageNO,1,seleColString,orderId);
        }
        #endregion

        #region 业务数据的返回
        /// <summary>
        /// 返回数据数量，通过一定的查询条件
        /// </summary>
        /// <param name="StrWhere">查询条件</param>
        /// <returns></returns>
        public int ReturnObjectCount(string StrWhere)//返回数据
        {
            return newDB.ReturnDataRowCount<T>(StrWhere);
        }

        /// <summary>
        /// 返回某一个对象特定的属性值，通过参数传入数据
        /// </summary>
        /// <param name="newObject">对象名称</param>
        /// <param name="dataColumn">返回的属性名称</param>
        /// <returns></returns>
        public object ReturnValue(T newObject,string dataColumn)
        {
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            object setValuePro = null;

            Object _obj = ass.CreateInstance(t.FullName);//泛型实例化

            foreach (PropertyInfo pi in pc)
            {
                if (pi.Name.Equals(dataColumn))//判断属性的类型是不是String
                {
                    setValuePro = pi.GetValue(newObject, null);
                    break;
                }
            }
            return setValuePro;
        }

        public List<T> ReturnSonList(T newObject)
        {
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            int setValue = -1;
            foreach (PropertyInfo pi in pc)
            {
                if (pi.Name.Equals("id"))//判断属性的类型是不是String
                {
                    setValue = Convert.ToInt32(pi.GetValue(newObject, null));
                    break;
                }
            }
            return ReturnObjectList(" parrentid=" + setValue);
        }
        #endregion

        #region 结构体的返回
        /// <summary>
        /// 将对象返回为结构体
        /// </summary>
        /// <param name="newObject">需要返回的对象</param>
        /// <returns></returns>
        public string ReturnObjectSture(T newObject)
        {
            string outString = "";
            IJSON newIJSON = new IJSON();
            T topObject = ReturnTopObject(newObject);

            outString = newIJSON.SerializeObject(topObject);

            List<T> newList = new List<T>();
            newList = ReturnSonList(newObject);
            string subString = "";
            for(int i=0;i<newList.Count;i++)
            {
                subString = subString + ReturnObjectSture(newList[i]) + ",";
            }
            outString = outString.Substring(0, outString.Length - 1) + ",\"sonlist\":[" + subString.Substring(0, subString.Length - 1) + "]}";
            return outString;
        }

        /// <summary>
        /// 将对象的集合返回为结构体
        /// </summary>
        /// <param name="newList">对象的集合</param>
        /// <returns></returns>
        public string ReturnObjectStureList(List<T> newList)
        {
            string outString = "[";
            List<T> outList = new List<T>();

            T topObject;

            for(int i=0;i<newList.Count;i++)
            {
                topObject = ReturnTopObject(newList[i]);
                if(!outList.Contains(topObject))
                {
                    outList.Add(topObject);
                }
            }

            for(int j=0;j<outList.Count;j++)
            {
                outString = outString + ReturnObjectSture(outList[j]) + ",";
            }
            outString = outString.Substring(0, outString.Length - 1) + "]";
            return outString;
        }
        #endregion

        public T ReturnTopObject(T newObject)
        {
            System.Type t = typeof(T);
            Assembly ass = Assembly.GetAssembly(t);//获取泛型的程序集
            PropertyInfo[] pc = t.GetProperties();//获取到泛型所有属性的集合
            int setValue = -1;
            foreach (PropertyInfo pi in pc)
            {
                if (pi.Name.Equals("parrentid"))//判断属性的类型是不是String
                {
                    setValue = Convert.ToInt32(pi.GetValue(newObject, null));
                    break;
                }
            }
            if (setValue == 0)
                return newObject;
            else
                return ReturnTopObject(ReturnObject(setValue));
        }

        
    }
}
