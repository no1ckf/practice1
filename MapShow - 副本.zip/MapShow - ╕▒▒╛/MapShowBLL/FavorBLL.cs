﻿using ClassLibraryQikuo;
using MapShowDAL;
using MapShowModel;
using System;
using System.Collections;
using System.Reflection;
using System.Data;

namespace MapShowBLL
{
    public class FavorBLL
    {
        #region public method
        DBOperation newDB;
        JSONOperation newJSON = new JSONOperation();//上面2行是每个DAL文件必须要的，方便在具体的文件操作的时候处理
        string connectString = "";
        FavorDAL newFavorDAL;
        DynamicDAL dynamicdal;
        IJSON newIJSON = new IJSON();
        Favor newFavor = new Favor();
        Dynamic dynamic = new Dynamic();

        public FavorBLL(string conString)
        {
            newDB = new DBOperation(conString);//把数据库连接语句传递入qikuo类库中
            connectString = conString;
            newFavorDAL = new FavorDAL(conString);
            dynamicdal = new DynamicDAL(conString);
        }

        public Favor JSONToFavor(string JSONString)
        {
            newFavor = newIJSON.DeserializeJsonToObject<Favor>(JSONString);
            return newFavor;
        }

        public Dynamic JSONToDynamic(string JSONString)
        {
            dynamic = newIJSON.DeserializeJsonToObject<Dynamic>(JSONString);
            return dynamic;
        }

        public string FavorToJSON(Favor newFavor)
        {
            IJSON newIJSON = new IJSON();
            return newIJSON.SerializeObject(newFavor);
        }
        #endregion

        //{"id":"1","dynamicid":"18100000000","creatid":"123456","creatdate":"headimgurl"}

        public string AddNewFavor(string recieveParament)
        {
            newFavor = JSONToFavor(recieveParament);
            newFavor.creatdate = DateTime.Now.ToLocalTime();
            string editStatus = "";
            bool outBool = newFavorDAL.AddFavor(newFavor, ref editStatus);
            if (editStatus != "")
            {
                newIJSON.resultCode = 10;
                newIJSON.resultMessage = editStatus;
                newIJSON.resultData = "null";
            }
            else
            {
                if (outBool == true)
                {
                    string str = "select max(id) as id from Favor";//标识规范：是；Model:int? _id
                    //string str = "select id from Favor where id='" + newFavor.id + "'";//标识规范：否；Model:int _id
                    string id = newDB.returndata(str, "id").ToString();
                    newFavor = newFavorDAL.ReturnFavor("id='" + id + "'");
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "添加成功";
                    newIJSON.resultData = FavorToJSON(newFavor);
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "添加失败";
                    newIJSON.resultData = "null";
                }
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"shareid":"2","creatid":"1"}
         //

        public string EditFavor(string recieveParament)
        {
            newFavor = JSONToFavor(recieveParament);
            //newFavor.creatdate = DateTime.Now;
            string editStatus = "";
            bool outBool = newFavorDAL.EditFavor(newFavor, ref editStatus);
            if (editStatus != "")
            {
                newIJSON.resultCode = 10;
                newIJSON.resultMessage = editStatus;
                newIJSON.resultData = "null";
            }
            else
            {
                if (outBool == true)
                {
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "更新成功";
                    newIJSON.resultData = "null";
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "更新失败";
                    newIJSON.resultData = "null";
                }
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"1"}
         //

        public string DeleteFavor(string recieveParament)
        {
            newFavor = JSONToFavor(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newFavorDAL.ReturnFavorList("id='" + newFavor.id + "'");
            if (newArr.Count >= 1)
            {
                string str = "Delete from Favor where id='" + newFavor.id + "'";
                bool status = newDB.update(str);
                if (status == true)
                {
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "删除成功";
                    newIJSON.resultData = "null";
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "删除失败";
                    newIJSON.resultData = "null";
                }
            }
            else
            {
                newIJSON.resultCode = 3;
                newIJSON.resultMessage = "不存在赞赏编号";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"0"}
         //

        public string ReturnFavor(string recieveParament)
        {
            newFavor = JSONToFavor(recieveParament);
            newFavor = newFavorDAL.ReturnFavor((int)newFavor.id);
            if (newFavor.id != 0)
            {
                newIJSON.resultCode = 1;
                newIJSON.resultMessage = "返回成功";
                newIJSON.resultData = FavorToJSON(newFavor);
            }
            else
            {
                newIJSON.resultCode = 3;
                newIJSON.resultMessage = "不存在赞赏编号";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"1"}
         //

        public string ReturnFavorList(string recieveParament)
        {
            ArrayList newArr = new ArrayList();
            newArr = newFavorDAL.ReturnFavorList("1=1");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{}
         //

        public string ReturnFavorListByDynamicId(string recieveParament)
        {
            newFavor = JSONToFavor(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newFavorDAL.ReturnFavorList("dynamicid='" + newFavor.dynamicid + "'");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{"shareid":"2"}
         //

        public string ReturnFavorListByCreatId(string recieveParament)
        {
            newFavor = JSONToFavor(recieveParament);
            ArrayList newArr = new ArrayList();
            ArrayList dyArr = new ArrayList();
            newArr = newFavorDAL.ReturnFavorList("creatid='" + newFavor.creatid + "'");
            for(int i = 0; i < newArr.Count; i++)
            {
                newFavor = (Favor)newArr[i];
                dynamic = dynamicdal.ReturnDynamic((int)newFavor.dynamicid);
                dyArr.Add(dynamic);
            }
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(dyArr); 
            return newIJSON.IJSONToString(newIJSON);
        }//{"creatid":"1"}
         //

        public string ReturnFavorListByCreatDate(string recieveParament)
        {
            newFavor = JSONToFavor(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newFavorDAL.ReturnFavorList("creatdate>'" + newFavor.creatdate + "'");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{"creatdate":"2017-12-25"}
         //
    }
}
