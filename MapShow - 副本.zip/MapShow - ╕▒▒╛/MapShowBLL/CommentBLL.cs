﻿using ClassLibraryQikuo;
using MapShowDAL;
using MapShowModel;
using System;
using System.Collections;
using System.Reflection;
using System.Data;

namespace MapShowBLL
{
    public class CommentBLL
    {
        #region public method
        DBOperation newDB;
        JSONOperation newJSON = new JSONOperation();//上面2行是每个DAL文件必须要的，方便在具体的文件操作的时候处理
        string connectString = "";
        CommentDAL newCommentDAL;
        IJSON newIJSON = new IJSON();
        Comment newComment = new Comment();

        public CommentBLL(string conString)
        {
            newDB = new DBOperation(conString);//把数据库连接语句传递入qikuo类库中
            connectString = conString;
            newCommentDAL = new CommentDAL(conString);
        }

        public Comment JSONToComment(string JSONString)
        {
            newComment = newIJSON.DeserializeJsonToObject<Comment>(JSONString);
            return newComment;
        }

        public string CommentToJSON(Comment newComment)
        {
            IJSON newIJSON = new IJSON();
            return newIJSON.SerializeObject(newComment);
        }
        #endregion

        //{"id":"1","dynamicid":"18100000000","creatid":"123456","creatdate":"headimgurl","commentdata":"妮可妮可","commentstate":"pickpick"}

        public string AddNewComment(string recieveParament)
        {
            newComment = JSONToComment(recieveParament);
            newComment.creatdate = DateTime.Now.ToLocalTime();
            string editStatus = "";
            bool outBool = newCommentDAL.AddComment(newComment, ref editStatus);
            if (editStatus != "")
            {
                newIJSON.resultCode = 10;
                newIJSON.resultMessage = editStatus;
                newIJSON.resultData = "null";
            }
            else
            {
                if (outBool == true)
                {
                    string str = "select max(id) as id from Comment";//标识规范：是；Model:int? _id
                    //string str = "select id from Comment where id='" + newComment.id + "'";//标识规范：否；Model:int _id
                    string id = newDB.returndata(str, "id").ToString();
                    newComment = newCommentDAL.ReturnComment("id='" + id + "'");
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "添加成功";
                    newIJSON.resultData = CommentToJSON(newComment);
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "添加失败";
                    newIJSON.resultData = "null";
                }
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"name":"学校1"}
         //

        public string EditComment(string recieveParament)
        {
            newComment = JSONToComment(recieveParament);
            //newComment.creatdate = DateTime.Now;
            string editStatus = "";
            bool outBool = newCommentDAL.EditComment(newComment, ref editStatus);
            if (editStatus != "")
            {
                newIJSON.resultCode = 10;
                newIJSON.resultMessage = editStatus;
                newIJSON.resultData = "null";
            }
            else
            {
                if (outBool == true)
                {
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "更新成功";
                    newIJSON.resultData = "null";
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "更新失败";
                    newIJSON.resultData = "null";
                }
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"1","name":"学校2"}
         //

        public string DeleteComment(string recieveParament)
        {
            newComment = JSONToComment(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newCommentDAL.ReturnCommentList("id='" + newComment.id + "'");
            if (newArr.Count >= 1)
            {
                string str = "Delete from Comment where id='" + newComment.id + "'";
                bool status = newDB.update(str);
                if (status == true)
                {
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "删除成功";
                    newIJSON.resultData = "null";
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "删除失败";
                    newIJSON.resultData = "null";
                }
            }
            else
            {
                newIJSON.resultCode = 3;
                newIJSON.resultMessage = "不存在评论编号";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"0"}
         //

        public string ReturnComment(string recieveParament)
        {
            newComment = JSONToComment(recieveParament);
            newComment = newCommentDAL.ReturnComment((int)newComment.id);
            if (newComment.id != 0)
            {
                newIJSON.resultCode = 1;
                newIJSON.resultMessage = "返回成功";
                newIJSON.resultData = CommentToJSON(newComment);
            }
            else
            {
                newIJSON.resultCode = 3;
                newIJSON.resultMessage = "不存在评论编号";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"1"}
         //

        public string ReturnCommentList(string recieveParament)
        {
            ArrayList newArr = new ArrayList();
            newArr = newCommentDAL.ReturnCommentList("1=1");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{}
         //

        public string ReturnCommentListByDynamicId(string recieveParament)
        {
            newComment = JSONToComment(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newCommentDAL.ReturnCommentList("dynamicid='" + newComment.dynamicid + "'");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{"name":"学校1"}
         //

        public string ReturnCommentListByCreatId(string recieveParament)
        {
            newComment = JSONToComment(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newCommentDAL.ReturnCommentList("creatid='" + newComment.creatid + "'");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{"name":"学校1"}
         //

        public string ReturnCommentListByCreatDate(string recieveParament)
        {
            newComment = JSONToComment(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newCommentDAL.ReturnCommentList("creatdate>'" + newComment.creatdate + "'");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{"name":"学校1"}
         //
    }
}
