﻿using ClassLibraryQikuo;
using MapShowDAL;
using MapShowModel;
using System;
using System.Collections;
using System.Reflection;
using System.Data;

namespace MapShowBLL
{
    public class UsersBLL
    {
        #region public method
        DBOperation newDB;
        JSONOperation newJSON = new JSONOperation();//上面2行是每个DAL文件必须要的，方便在具体的文件操作的时候处理
        string connectString = "";
        UsersDAL newUsersDAL;
        DynamicDAL dynamicdal;
        IJSON newIJSON = new IJSON();
        Users newUsers = new Users();
        Dynamic dynamic = new Dynamic();

        public UsersBLL(string conString)
        {
            newDB = new DBOperation(conString);//把数据库连接语句传递入qikuo类库中
            connectString = conString;
            newUsersDAL = new UsersDAL(conString);
            dynamicdal = new DynamicDAL(conString);
        }

        public Users JSONToUsers(string JSONString)
        {
            newUsers = newIJSON.DeserializeJsonToObject<Users>(JSONString);
            return newUsers;
        }

        public Dynamic JSONToDynamic(string JSONString)
        {
            dynamic = newIJSON.DeserializeJsonToObject<Dynamic>(JSONString);
            return dynamic;
        }

        public string UsersToJSON(Users newUsers)
        {
            IJSON newIJSON = new IJSON();
            return newIJSON.SerializeObject(newUsers);
        }
        #endregion

        //{"id":"1","username":"18100000000","password":"123456","headimg":"headimgurl","nikename":"妮可妮可","signature":"pickpick","sex":"女","state":"0"}

        public string CheckLogin(string recieveParament)
        {
            string[] setJSON = { "username", "password" };
            newUsers = JSONToUsers(recieveParament);
            if (newUsers == null || newIJSON.CheckJSON(recieveParament, setJSON))
            {
                newIJSON.resultCode = 201;
                newIJSON.resultMessage = "JSON格式错误";
                newIJSON.resultData = "null";
            }
            else
            {
                string checkString = " username='" + newUsers.username + "' and password='" + newUsers.password + "'";
                if (newDB.ReturnConnectStatus())
                {
                    int itemCount = newUsersDAL.ReturnUsersList(checkString).Count;

                    if (itemCount == 1)
                    {
                        newUsers = newUsersDAL.ReturnUsers("username='" + newUsers.username + "'");
                        newIJSON.resultCode = 1;
                        newIJSON.resultMessage = "登录成功";
                        newIJSON.resultData = UsersToJSON(newUsers);
                    }
                    else
                    {
                        checkString = " username='" + newUsers.username + "'";
                        itemCount = newUsersDAL.ReturnUsersList(checkString).Count;

                        if (itemCount == 1)
                        {
                            newIJSON.resultCode = 5;
                            newIJSON.resultMessage = "密码错误";
                            newIJSON.resultData = "null";
                        }
                        else
                        {
                            newIJSON.resultCode = 4;
                            newIJSON.resultMessage = "用户不存在";
                            newIJSON.resultData = "null";
                        }
                    }
                }
                else
                {
                    newIJSON.resultCode = 15;
                    newIJSON.resultMessage = "数据库连接失败";
                    newIJSON.resultData = "null";
                }
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"username":"18100000000","password":"123456"}
         //{"resultCode":1,"resultMessage":"登录成功","resultData":{"id":1,"username":"18100000000","password":"123456","headimg":"url","nikename":"nike","signature":"哈哈","sex":"男","state":0}}

        public string Register(string recieveParament)
        {
            newUsers = JSONToUsers(recieveParament);
            string checkString = " username='" + newUsers.username + "'";
            int itemCount = newUsersDAL.ReturnUsersList(checkString).Count;
            if (itemCount == 0)
            {
                string editStatus = "";
                bool outBool = newUsersDAL.AddUsers(newUsers, ref editStatus);
                if (editStatus != "")
                {
                    newIJSON.resultCode = 10;
                    newIJSON.resultMessage = editStatus;
                    newIJSON.resultData = "null";
                }
                else
                {
                    if (outBool == true)
                    {
                        string str = "select max(id) as id from Users";//标识规范：是；Model:int? _id
                                                                       //string str = "select id from Users where id='" + newUsers.id + "'";//标识规范：否；Model:int _id
                        string id = newDB.returndata(str, "id").ToString();
                        newUsers = newUsersDAL.ReturnUsers("id='" + id + "'");
                        newIJSON.resultCode = 1;
                        newIJSON.resultMessage = "注册成功";
                        newIJSON.resultData = UsersToJSON(newUsers);
                    }
                    else
                    {
                        newIJSON.resultCode = 0;
                        newIJSON.resultMessage = "注册失败";
                        newIJSON.resultData = "null";
                    }
                }
            }
            else
            {
                newIJSON.resultCode = 2;
                newIJSON.resultMessage = "用户已存在";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"username":"18100000001","password":"123456","headimg":"headimgurl","nikename":"妮可妮可","signature":"pickpick","sex":"女","state":"0"}
         //{"resultCode":1,"resultMessage":"注册成功","resultData":{"id":4,"username":"18100000001","password":"123456","headimg":"headimgurl","nikename":"妮可妮可","signature":"pickpick","sex":"女","state":0}}

        public string EditUsers(string recieveParament)
        {
            newUsers = JSONToUsers(recieveParament);
            string editStatus = "";
            bool outBool = newUsersDAL.EditUsers(newUsers, ref editStatus);
            if (editStatus != "")
            {
                newIJSON.resultCode = 10;
                newIJSON.resultMessage = editStatus;
                newIJSON.resultData = "null";
            }
            else
            {
                if (outBool == true)
                {
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "更新成功";
                    newIJSON.resultData = "null";
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "更新失败";
                    newIJSON.resultData = "null";
                }
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"password":"123456","headimg":"headimgurl","nikename":"妮可妮可","signature":"pickpick","sex":"女","state":"0"}
         //

        public string DeleteUsers(string recieveParament)
        {
            newUsers = JSONToUsers(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newUsersDAL.ReturnUsersList("id='" + newUsers.id + "'");
            if (newArr.Count >= 1)
            {
                string str = "Delete from Users where id='" + newUsers.id + "'";
                bool status = newDB.update(str);
                if (status == true)
                {
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "删除成功";
                    newIJSON.resultData = "null";
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "删除失败";
                    newIJSON.resultData = "null";
                }
            }
            else
            {
                newIJSON.resultCode = 3;
                newIJSON.resultMessage = "不存在用户编号";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"0"}
         //

        public string ReturnUsers(string recieveParament)
        {
            newUsers = JSONToUsers(recieveParament);
            newUsers = newUsersDAL.ReturnUsers((int)newUsers.id);
            if (newUsers.id != 0)
            {
                newIJSON.resultCode = 1;
                newIJSON.resultMessage = "返回成功";
                newIJSON.resultData = UsersToJSON(newUsers);
            }
            else
            {
                newIJSON.resultCode = 3;
                newIJSON.resultMessage = "不存在用户编号";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"1"}
         //

        public string ReturnUsersList(string recieveParament)
        {
            ArrayList newArr = new ArrayList();
            newArr = newUsersDAL.ReturnUsersList("1=1");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{}
         //

        public string ReturnHeadimgByDynamicList(string recieveParament)
        {
            //newUsers = JSONToDynamic()
            ArrayList newArr = new ArrayList();
            //DataTable newData = newDB.returndatatable("Users", strWhere);
            newArr = newUsersDAL.MyReturnUsersList("Users.id = Dynamic.creatid");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{}
         //
    }
}
