﻿using ClassLibraryQikuo;
using MapShowDAL;
using MapShowModel;
using System;
using System.Collections;
using System.Reflection;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MapShowBLL
{
    public class DynamicBLL
    {
        #region public method
        DBOperation newDB;
        JSONOperation newJSON = new JSONOperation();//上面2行是每个DAL文件必须要的，方便在具体的文件操作的时候处理
        string connectString = "";
        DynamicDAL newDynamicDAL;
        IJSON newIJSON = new IJSON();
        Dynamic newDynamic = new Dynamic();

        public DynamicBLL(string conString)
        {
            newDB = new DBOperation(conString);//把数据库连接语句传递入qikuo类库中
            connectString = conString;
            newDynamicDAL = new DynamicDAL(conString);
        }

        public Dynamic JSONToDynamic(string JSONString)
        {
            newDynamic = newIJSON.DeserializeJsonToObject<Dynamic>(JSONString);
            return newDynamic;
        }

        public string DynamicToJSON(Dynamic newDynamic)
        {
            IJSON newIJSON = new IJSON();
            return newIJSON.SerializeObject(newDynamic);
        }
        #endregion

        //{"id":"1","creatid":"18100000000","creatdate":"123456","dynamicdata":"headimgurl","videodata":"妮可妮可","address":"pickpick","latlng":"女","commentnum":"0","favornum":"0"}

        public string AddNewDynamic(string recieveParament)
        {
            newDynamic = JSONToDynamic(recieveParament);
            newDynamic.creatdate = DateTime.Now.ToLocalTime();
            string editStatus = "";
            bool outBool = newDynamicDAL.AddDynamic(newDynamic, ref editStatus);
            if (editStatus != "")
            {
                newIJSON.resultCode = 10;
                newIJSON.resultMessage = editStatus;
                newIJSON.resultData = "null";
            }
            else
            {
                if (outBool == true)
                {
                    string str = "select max(id) as id from Dynamic";//标识规范：是；Model:int? _id
                    //string str = "select id from Dynamic where id='" + newDynamic.id + "'";//标识规范：否；Model:int _id
                    string id = newDB.returndata(str, "id").ToString();
                    newDynamic = newDynamicDAL.ReturnDynamic("id='" + id + "'");
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "添加成功";
                    newIJSON.resultData = DynamicToJSON(newDynamic);
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "添加失败";
                    newIJSON.resultData = "null";
                }
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"location":"address","sharedata":"喜欢这里","creatid":"1","favornum":"0","commentnum":"0","sharetype":"0"}
         //

        public string EditDynamic(string recieveParament)
        {
            newDynamic = JSONToDynamic(recieveParament);
            //newDynamic.creatdate = DateTime.Now;
            string editStatus = "";
            bool outBool = newDynamicDAL.EditDynamic(newDynamic, ref editStatus);
            if (editStatus != "")
            {
                newIJSON.resultCode = 10;
                newIJSON.resultMessage = editStatus;
                newIJSON.resultData = "null";
            }
            else
            {
                if (outBool == true)
                {
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "更新成功";
                    newIJSON.resultData = "null";
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "更新失败";
                    newIJSON.resultData = "null";
                }
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"1","location":"address","sharedata":"喜欢这里","creatid":"1","favornum":"0","commentnum":"0","sharetype":"1"}
         //

        public string DeleteDynamic(string recieveParament)
        {
            newDynamic = JSONToDynamic(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newDynamicDAL.ReturnDynamicList("id='" + newDynamic.id + "'");
            if (newArr.Count >= 1)
            {
                string str = "Delete from Dynamic where id='" + newDynamic.id + "'";
                bool status = newDB.update(str);
                if (status == true)
                {
                    newIJSON.resultCode = 1;
                    newIJSON.resultMessage = "删除成功";
                    newIJSON.resultData = "null";
                }
                else
                {
                    newIJSON.resultCode = 0;
                    newIJSON.resultMessage = "删除失败";
                    newIJSON.resultData = "null";
                }
            }
            else
            {
                newIJSON.resultCode = 3;
                newIJSON.resultMessage = "不存在动态编号";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"0"}
         //

        public string ReturnDynamic(string recieveParament)
        {
            newDynamic = JSONToDynamic(recieveParament);
            newDynamic = newDynamicDAL.ReturnDynamic((int)newDynamic.id);
            if (newDynamic.id != 0)
            {
                newIJSON.resultCode = 1;
                newIJSON.resultMessage = "返回成功";
                newIJSON.resultData = DynamicToJSON(newDynamic);
            }
            else
            {
                newIJSON.resultCode = 3;
                newIJSON.resultMessage = "不存在动态编号";
                newIJSON.resultData = "null";
            }
            return newIJSON.IJSONToString(newIJSON);
        }//{"id":"1"}
         //

        public string ReturnDynamicList(string recieveParament)
        {
            ArrayList newArr = new ArrayList();
            newArr = newDynamicDAL.ReturnDynamicList("1=1");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{}
         //

        public string ReturnDynamicListByCreatId(string recieveParament)
        {
            newDynamic = JSONToDynamic(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newDynamicDAL.ReturnDynamicList("creatid='" + newDynamic.creatid + "'");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{"creatid":"1"}
         //

        public string ReturnDynamicListByCreatDate(string recieveParament)
        {
            newDynamic = JSONToDynamic(recieveParament);
            ArrayList newArr = new ArrayList();
            newArr = newDynamicDAL.ReturnDynamicList("creatdate>'" + newDynamic.creatdate + "'");
            newIJSON.resultCode = 1;
            newIJSON.resultMessage = "返回成功";
            newIJSON.resultData = newIJSON.SerializeObject(newArr);
            return newIJSON.IJSONToString(newIJSON);
        }//{"creatdate":"2017-12-25"}
         //
    }
}
