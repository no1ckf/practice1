﻿using MapShowModel;
using ClassLibraryQikuo;
using System;
using System.Collections;
using System.Data;
using System.Reflection;

namespace MapShowDAL
{
    public class FavorDAL
    {
        DBOperation newDB;
        JSONOperation newJSON = new JSONOperation();//上面2行是每个DAL文件必须要的，方便在具体的文件操作的时候处理
        string connectString = "";

        public FavorDAL(string conString)//把数据库连接字符串传入到数据操作类中，进行数据操作
        {
            newDB = new DBOperation(conString);//把数据库连接语句传递入qikuo类库中
            connectString = conString;
        }

        public bool AddFavor(Favor newFavor, ref string editStatus)//添加一个Favor对象到数据库中，方法命名规则Add+对象名，这里不需要设定id的值
        {
            String columnString = "";
            string valueString = "";

            Type type = newFavor.GetType();
            System.Reflection.PropertyInfo[] ps = type.GetProperties();

            foreach (PropertyInfo i in ps)
            {
                object obj = i.GetValue(newFavor, null);
                if (obj != null)
                {
                    string proType = i.PropertyType.ToString();
                    string name = i.Name;

                    if (proType == "System.Nullable`1[System.Int32]" || proType == "System.Int32")
                    {
                        if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                        {
                            if (int.Parse(obj.ToString()) > -1)
                            {
                                columnString = columnString + i.Name + ",";
                                valueString = valueString + "" + obj.ToString() + ",";
                            }
                        }
                    }
                    else
                    {
                        if (proType == "System.Nullable`1[System.Decimal]" || proType == "System.Decimal")
                        {
                            if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                            {
                                if (float.Parse(obj.ToString()) > -1)
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "" + obj.ToString() + ",";
                                }
                            }
                        }
                        else
                        {
                            if (proType == "System.DateTime" || proType == "System.Nullable`1[System.DateTime]")
                            {
                                if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "'" + obj.ToString() + "',";
                                }
                            }
                            else
                            {
                                if (obj != null)//下面3个if语句是判定对象
                                {
                                    columnString = columnString + i.Name + ",";
                                    valueString = valueString + "'" + obj.ToString() + "',";
                                }
                            }
                        }
                    }
                }

            }


            if (columnString.IndexOf(",") > 0)//判定是否需要进行更新
            {
                columnString = columnString.Substring(0, columnString.Length - 1);//对于更新字符串进行处理，因为字符串构建方法在最后会多出来一个逗号，所以需要把字后的逗号去掉
                valueString = valueString.Substring(0, valueString.Length - 1);
                string updateString = " insert Favor (" + columnString + ") values (" + valueString + ")";
                //拼接更新字符串，设定更新条件

                return newDB.update(updateString);//执行数据库更新语句，更新数据库，返回执行状态
            }
            else
            {
                editStatus = " no update parameter";//错误代表没有传入更新参数
                return false;
            }
        }

        public bool EditFavor(Favor newFavor, ref string editStatus)//更新一个Favor对象，方法命名规则Edit+对象名，这里必须设定id的值
        {//这里采用的是反射参数方法，editStatus是返回更新的具体问题所在，调用方法的时候可以直接用
            string updateString = "update Favor set ";//首先设定更新字符串的初始值

            if (ReturnFavor(Convert.ToInt32(newFavor.id)).id > 0) //返回false
            {
                Type type = newFavor.GetType();
                System.Reflection.PropertyInfo[] ps = type.GetProperties();

                foreach (PropertyInfo i in ps)
                {
                    object obj = i.GetValue(newFavor, null);
                    if (obj != null)
                    {
                        string proType = obj.GetType().ToString();
                        string name = i.Name;

                        if (proType == "System.Nullable`1[System.Int32]" || proType == "System.Int32")
                        {
                            if (i.Name != "id" && i.Name != "username")
                            {
                                if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                                {
                                    updateString = updateString + " " + i.Name + "=" + obj.ToString() + ",";
                                }
                            }
                        }
                        else
                        {
                            if (proType == "System.Nullable`1[System.Decimal]" || proType == "System.Decimal")
                            {
                                if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                                {
                                    updateString = updateString + " " + i.Name + "=" + obj.ToString() + ",";
                                }
                            }
                            else
                            {
                                if (proType == "System.DateTime" || proType == "System.Nullable`1[System.DateTime]")
                                {
                                    if (obj != null && obj.ToString() != "")//下面3个if语句是判定对象
                                    {
                                        updateString = updateString + " " + i.Name + "='" + obj.ToString() + "',";
                                    }
                                }
                                else
                                {
                                    if (obj != null)//下面3个if语句是判定对象
                                    {
                                        updateString = updateString + " " + i.Name + "='" + obj.ToString() + "',";
                                    }
                                }
                            }
                        }
                    }

                }
                if (updateString.IndexOf("=") > 0)//判定是否需要进行更新
                {
                    updateString = updateString.Substring(0, updateString.Length - 1);//对于更新字符串进行处理，因为字符串构建方法在最后会多出来一个逗号，所以需要把字后的逗号去掉
                    updateString = updateString + " where id=" + newFavor.id + "";//拼接更新字符串，设定更新条件

                    return newDB.update(updateString);//执行数据库更新语句，更新数据库，返回执行状态
                }
                else
                {
                    editStatus = " no update parameter";//错误代表没有传入更新参数
                    return false;
                }
            }
            else
            {
                editStatus = " no such data";//错误代表没有与id对应的数据
                return false;
            }
        }

        public bool DeleteFavor(Favor oldFavor, ref string deleteStatus)//删除一个Favor对象，方法命名规则Delete+对象名，这里必须设定id的值
        {//这里采用的是反射参数方法，deleteStatus是返回更新的具体问题所在，调用方法的时候可以直接用


            if (ReturnFavor(Convert.ToInt32(oldFavor.id)).id > 0) //判定是否有和oldFavor的id对应的数据
            {
                string deleteString = "delete Favor where id=" + oldFavor.id + "";
                return newDB.update(deleteString);
            }
            else
            {
                deleteStatus = " no such data";//错误代表没有与id对应的数据
                return false;
            }
        }

        public Favor ReturnFavor(int id)//返回数据
        {
            System.Data.DataTable newData = newDB.returndatatable("Favor", "id=" + id + "");//建立一个datatable，用来存储检索的数据
            Favor newFavor = new Favor();

            // 这里调用qikuo类库的一个方法，返回数据表的方法，第一个参数是数据库的表名，第二个参数是查询条件，类似于查询select * from Favor where id=传递的id参数

            if (newData.Rows.Count > 0)//添加判定条件，判定是否查询到数据
            {

                Type type = newFavor.GetType();
                System.Reflection.PropertyInfo[] ps = type.GetProperties();

                foreach (PropertyInfo i in ps)
                {
                    //object obj = i.GetValue(newFavor, null);

                    string proType = i.PropertyType.ToString();
                    string name = i.Name;

                    if (proType == "System.Nullable`1[System.Int32]" || proType == "System.Int32" || proType == "System.Reflection.RuntimePropertyInfo")
                    {
                        if (newData.Rows[0][i.Name] != null && newData.Rows[0][i.Name].ToString() != "")//对于int类型（或者是其他非string类型），需要进行两步判定，判断是否为null或者是是否为空
                        {
                            i.SetValue(newFavor, int.Parse(newData.Rows[0][i.Name].ToString()), null);//把获取的值转化为int类型
                        }
                    }
                    else
                    {
                        if (proType == "System.Nullable`1[System.Decimal]" || proType == "System.Decimal")
                        {
                            if (newData.Rows[0][i.Name] != null && newData.Rows[0][i.Name].ToString() != "")//对于int类型（或者是其他非string类型），需要进行两步判定，判断是否为null或者是是否为空
                            {
                                i.SetValue(newFavor, float.Parse(newData.Rows[0][i.Name].ToString()), null);//把获取的值转化为int类型
                            }
                        }
                        else
                        {
                            if (proType == "System.DateTime" || proType == "System.Nullable`1[System.DateTime]")
                            {
                                if (newData.Rows[0][i.Name] != null && newData.Rows[0][i.Name].ToString() != "")//对于int类型（或者是其他非string类型），需要进行两步判定，判断是否为null或者是是否为空
                                {
                                    i.SetValue(newFavor, DateTime.Parse(newData.Rows[0][i.Name].ToString()), null);//把获取的值转化为int类型
                                }
                            }
                            else
                            {
                                if (newData.Rows[0][i.Name] != null)//对于int类型（或者是其他非string类型），需要进行两步判定，判断是否为null或者是是否为空
                                {
                                    i.SetValue(newFavor, newData.Rows[0][i.Name].ToString(), null);//把获取的值转化为int类型
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                //首先实例化一个对象
                newFavor.id = 0;//在数据库中没有与该id对应的数据时候，设定id=0，告知后续的方法
            }

            return newFavor;//返回Favor对象
        }

        public Favor ReturnFavor(string strWhere)//这里用的是多态，可以在strwhere可以添加order by语句
        {
            Favor newFavor = new Favor();//首先实例化一个对象
            DataTable newData = newDB.returndatatable("Favor", strWhere);//建立一个datatable，用来存储检索的数据
                                                                         // 这里调用qikuo类库的一个方法，返回数据表的方法，第一个参数是数据库的表名，第二个参数是查询条件，类似于查询select * from Favor where id=传递的id参数
            if (newData.Rows.Count > 0)//添加判定条件，判定是否查询到数据
            {
                Type type = newFavor.GetType();
                System.Reflection.PropertyInfo[] ps = type.GetProperties();

                foreach (PropertyInfo i in ps)
                {
                    object obj = i.GetValue(newFavor, null);

                    string proType = i.PropertyType.ToString();
                    string name = i.Name;

                    if (proType == "System.Nullable`1[System.Int32]" || proType == "System.Int32")
                    {
                        if (newData.Rows[0][i.Name] != null && newData.Rows[0][i.Name].ToString() != "")//对于int类型（或者是其他非string类型），需要进行两步判定，判断是否为null或者是是否为空
                        {
                            i.SetValue(newFavor, int.Parse(newData.Rows[0][i.Name].ToString()), null);//把获取的值转化为int类型
                        }
                    }
                    else
                    {
                        if (proType == "System.Nullable`1[System.Decimal]" || proType == "System.Decimal")
                        {
                            if (newData.Rows[0][i.Name] != null && newData.Rows[0][i.Name].ToString() != "")//对于int类型（或者是其他非string类型），需要进行两步判定，判断是否为null或者是是否为空
                            {
                                i.SetValue(newFavor, float.Parse(newData.Rows[0][i.Name].ToString()), null);//把获取的值转化为int类型
                            }
                        }
                        else
                        {
                            if (proType == "System.DateTime" || proType == "System.Nullable`1[System.DateTime]")
                            {
                                if (newData.Rows[0][i.Name] != null && newData.Rows[0][i.Name].ToString() != "")//对于int类型（或者是其他非string类型），需要进行两步判定，判断是否为null或者是是否为空
                                {
                                    i.SetValue(newFavor, DateTime.Parse(newData.Rows[0][i.Name].ToString()), null);//把获取的值转化为int类型
                                }
                            }
                            else
                            {
                                if (newData.Rows[0][i.Name] != null)//对于int类型（或者是其他非string类型），需要进行两步判定，判断是否为null或者是是否为空
                                {
                                    i.SetValue(newFavor, newData.Rows[0][i.Name].ToString(), null);//把获取的值转化为int类型
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                newFavor.id = 0;//在数据库中没有与该id对应的数据时候，设定id=0，告知后续的方法
            }

            return newFavor;//返回Favor对象
        }

        public Favor ReturnTopFavor(string strWhere)//返回最新的数据
        {
            return ReturnFavor(strWhere + " order by id desc");
        }

        public ArrayList ReturnFavorList(string strWhere)
        {

            DataTable newData = newDB.returndatatable("Favor", strWhere);//建立一个datatable，用来存储检索的数据
                                                                         // 这里调用qikuo类库的一个方法，返回数据表的方法，第一个参数是数据库的表名，第二个参数是查询条件，类似于查询select * from Favor where id=传递的id参数
            ArrayList newArr = new ArrayList();//实例化一个arraylist

            for (int i = 0; i < newData.Rows.Count; i++)//遍历检索的数据
            {
                int FavorId = int.Parse(newData.Rows[i]["id"].ToString());//获取对象的编号
                newArr.Add(ReturnFavor(FavorId));//通过返回对象的方法获取对象，之后把对象添加到arraylist里
            }
            return newArr;
        }

        public ArrayList ReturnFavorList(string strWhere, int pageNO, int pagePer)
        {

            DataTable newData = newDB.returndatatable(strWhere, "Favor", pagePer, pageNO, 1, "id");//建立一个datatable，用来存储检索的数据
                                                                                                   // 这里调用qikuo类库的一个方法，返回数据表的方法，第一个参数是数据库的表名，第二个参数是查询条件，类似于查询select * from Favor where id=传递的id参数
            ArrayList newArr = new ArrayList();//实例化一个arraylist

            for (int i = 0; i < newData.Rows.Count; i++)//遍历检索的数据
            {
                int FavorId = int.Parse(newData.Rows[i]["id"].ToString());//获取对象的编号
                newArr.Add(ReturnFavor(FavorId));//通过返回对象的方法获取对象，之后把对象添加到arraylist里
            }
            return newArr;
        }

    }
}
