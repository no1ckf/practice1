package com.no1ckf.mapshow.activity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.OSSUtil;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class SettingActivity extends Activity {
    private ImageView setting_headimg;
    private EditText setting_nikenameetx, setting_signatureetx;
    private RadioButton setting_sexb, setting_sexg;
    private Button setting_editpassword, setting_post, setting_exit;
    private TextView setting_sex;
    private int loginid;
    private String url = "ReturnUsers.aspx";
    private String setting_imgpath = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        setting_headimg = (ImageView) findViewById(R.id.setting_headimg);
        setting_headimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //OSSUtil.uploadFile()
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent,0);

            }
        });

        setting_nikenameetx = (EditText) findViewById(R.id.setting_nikenameetx);

        setting_signatureetx = (EditText) findViewById(R.id.setting_signatureetx);

        setting_sex = (TextView) findViewById(R.id.setting_sex);
        setting_sexb = (RadioButton) findViewById(R.id.setting_sexb);
        setting_sexg = (RadioButton) findViewById(R.id.setting_sexg);
        setting_sexb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setting_sexb.setChecked(true);
                setting_sexg.setChecked(false);
                setting_sex.setContentDescription("男");
            }
        });
        setting_sexg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setting_sexb.setChecked(false);
                setting_sexg.setChecked(true);
                setting_sex.setContentDescription("女");
            }
        });

        setting_editpassword = (Button) findViewById(R.id.setting_editpassword);
        setting_editpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingActivity.this, ChangePasswordActivity.class);
                startActivity(intent);
            }
        });

        setting_post = (Button) findViewById(R.id.setting_post);
        setting_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url = "EditUsers.aspx";
                getData();
            }
        });

        setting_exit = (Button) findViewById(R.id.setting_exit);
        setting_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferencesHelper.getInstance().saveData("id",0);
                finish();
            }
        });
        getData();
    }

    public void getData(){
        loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);
        JSONObject jsonObject = new JSONObject();
        try {
            if(url.equals("ReturnUsers.aspx")){
                jsonObject.put("id",loginid);
            }else{
                jsonObject.put("id",loginid);
                jsonObject.put("headimg",setting_imgpath);
                jsonObject.put("nikename",setting_nikenameetx.getText());
                jsonObject.put("signature",setting_signatureetx.getText());
                jsonObject.put("sex",setting_sex.getContentDescription());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post(url, entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){
                        if(url.equals("ReturnUsers.aspx")){
                            try {
                                //通过uri获取到bitmap对象
                                if(!response.getJSONObject("resultData").getString("headimg").equals("")){
                                    Uri urig = Uri.fromFile(new File(response.getJSONObject("resultData").getString("headimg")));
                                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
                                    setting_headimg.setImageBitmap(bitmap);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            //setting_headimg.setImageBitmap();
                            setting_signatureetx.setText(response.getJSONObject("resultData").getString("signature"));
                            setting_nikenameetx.setText(response.getJSONObject("resultData").getString("nikename"));
                            if(response.getJSONObject("resultData").getString("sex").equals("女")){
                                setting_sexb.setChecked(false);
                                setting_sexg.setChecked(true);
                                setting_sex.setContentDescription("女");
                            }else {
                                setting_sexb.setChecked(true);
                                setting_sexg.setChecked(false);
                                setting_sex.setContentDescription("男");
                            }
                        }
                        Log.e("try", response.toString());
                    }else {
                        Toast toast=Toast.makeText(SettingActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 0:
                if(resultCode == RESULT_OK){
                    Uri uri = data.getData();
                    //通过uri的方式返回，部分手机uri可能为空
                    if(uri != null){
                        try {
                            //通过uri获取到bitmap对象
                            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                            setting_headimg.setImageBitmap(bitmap);

                            Cursor cursor = this.getContentResolver().query(uri, null,
                                    null, null, null);
                            if (cursor.moveToFirst()) {
                                setting_imgpath = cursor.getString(cursor.getColumnIndex("_data"));// 获取绝对路径
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }else {
                        //部分手机可能直接存放在bundle中
                        Bundle bundleExtras = data.getExtras();
                        if(bundleExtras != null){
                            Bitmap  bitmaps = bundleExtras.getParcelable("data");
                            setting_headimg.setImageBitmap(bitmaps);
                        }
                    }
                    Log.e("uri",setting_imgpath);
                }
                break;
        }
    }
}
