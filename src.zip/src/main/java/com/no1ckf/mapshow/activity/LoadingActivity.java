package com.no1ckf.mapshow.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;

import com.no1ckf.mapshow.MyApplication;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;

import java.util.Timer;
import java.util.TimerTask;

public class LoadingActivity extends FragmentActivity {

//    public SharedPreferences myPreference = getSharedPreferences("myPreference", Context.MODE_PRIVATE);
//    public SharedPreferences.Editor editor = myPreference.edit();
    private Timer timer;

    final Handler handler = new Handler(){
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    Intent intent = new Intent(LoadingActivity.this,MainActivity.class);
                    startActivity(intent);
                    timer.cancel();
                    finish();

                    break;
            }
            super.handleMessage(msg);
        }
    };
    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_loading);

//        SharedPreferences myPreference = getSharedPreferences("myPreference", Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = myPreference.edit();
        //SharedPreferencesHelper.getInstance().cleanid();
        if(!SharedPreferencesHelper.getInstance().getid()){
            SharedPreferencesHelper.getInstance().saveData("id",0);
            SharedPreferencesHelper.getInstance().saveData("fragment",0);
//            SharedPreferencesHelper.getInstance().saveData("dynamicid",0);
        }

        timer = new Timer(true);
        timer.schedule(task,2000);
    }

    TimerTask task = new TimerTask(){
        public void run() {
            Message message = new Message();
            message.what = 1;
            handler.sendMessage(message);
        }
    };
}

//{"id": "1","username": "18100000000","password": "123456","headimg": "headimgurl",
//        "nikename": "妮可妮可","signature": "pickpick","sex": "女","state": "0"}
//
//
//{"id": "1","creatid": "18100000000","creatdate": "123456","dynamicdata": "headimgurl",
//        "videodata": "妮可妮可","address": "pickpick","latlng": "女","commentnum": "0","favornum": "0"}
//
//
//{"id": "1","dynamicid": "18100000000","creatid": "123456","creatdate":
//        "headimgurl","commentdata": "妮可妮可","commentstate": "pickpick"}
//
//
//{"id": "1","dynamicid": "18100000000","creatid": "123456","creatdate": "headimgurl"}

//http://47.96.109.9:8081/ReturnFavor.aspx
