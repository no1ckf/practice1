package com.no1ckf.mapshow.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;

import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.model.Comment;
import com.no1ckf.mapshow.model.Dynamic;
import com.no1ckf.mapshow.widget.XListView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReviewActivity extends FragmentActivity implements XListView.IXListViewListener {
    List<Comment> _list_comment =new ArrayList<Comment>();
    private XListView comment_list;
    private Handler mHandler;
    private int loginid;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_listview);

        comment_list = (XListView) findViewById(R.id.listview);
        comment_list.setPullRefreshEnable(true); //允许下拉刷新
        comment_list.setPullLoadEnable(true); //允许上拉加载更多
        comment_list.setAutoLoadEnable(true); //允许下拉到底部后自动加载
        comment_list.setXListViewListener(this);

        getData();

    }

    public void getData() {

    }

    //下拉刷新
    @Override
    public void onRefresh() {
        // TODO Auto-generated method stub
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                _list_comment = new ArrayList<Comment>();
                getData();
            }
        }, 2);
    }

    //上拉加载更多
    @Override
    public void onLoadMore() {
        // TODO Auto-generated method stub
//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                getData();
//            }
//        },2);
    }

    //完成数据加载
    private void onLoaded() {
        comment_list.stopRefresh(); //停止刷新
        comment_list.stopLoadMore(); //停止加载更多
        comment_list.setRefreshTime(getTime());
    }

    private String getTime() {
        return new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(new Date());
    }
}
