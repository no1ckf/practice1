package com.no1ckf.mapshow.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.adapter.ReviewAdapter;
import com.no1ckf.mapshow.model.Comment;
import com.no1ckf.mapshow.model.Dynamic;
import com.no1ckf.mapshow.utils.BDlistener;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;
import com.no1ckf.mapshow.widget.XListView;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DynamicActivity extends FragmentActivity implements XListView.IXListViewListener {
    private static final String DYNAMIC_ID = "com.no1ckf.mapshow.dynamic_id";

    private VideoView dynamic_videodata;
    private ImageView dynamic_headimg,dynamic_favor,dynamic_comment,dynamic_delete;
    private TextView dynamic_dynamicdatatv,dynamic_nikename,dynamic_creatdate,dynamic_address,dynamic_favornum;
    private EditText dynamic_dynamicdataetx,send_comment;
    private XListView dynamic_listview;
    private Button dynamic_publish,send_button;
    private LinearLayout dynamic_contain,comment_layout,dynamic_layout;
    private String videoPath = null;
    private int key = 0;
    private List<Comment> _list_comment =new ArrayList<Comment>();
    private Handler mHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic);
        getIntent().getStringExtra("DYNAMIC_ID");

        send_comment = (EditText) findViewById(R.id.send_comment);
        send_button = (Button) findViewById(R.id.send_button);
        comment_layout = (LinearLayout) findViewById(R.id.comment_layout);
        dynamic_layout = (LinearLayout) findViewById(R.id.dynamic_layout);
        dynamic_favor = (ImageView) findViewById(R.id.dynamic_favor);
        dynamic_comment = (ImageView) findViewById(R.id.dynamic_comment);
        dynamic_favornum = (TextView) findViewById(R.id.dynamic_favornum);
        dynamic_creatdate = (TextView) findViewById(R.id.dynamic_creatdate);
        dynamic_contain = (LinearLayout) findViewById(R.id.dynamic_contain);
        dynamic_dynamicdatatv = (TextView) findViewById(R.id.dynamic_dynamicdatatv);
        dynamic_dynamicdataetx = (EditText) findViewById(R.id.dynamic_dynamicdataetx);
        dynamic_publish = (Button) findViewById(R.id.dynamic_publish);
        dynamic_listview = (XListView) findViewById(R.id.dynamic_listview);
        dynamic_delete = (ImageView) findViewById(R.id.dynamic_delete);
        dynamic_dynamicdataetx.setVisibility(View.GONE);
        dynamic_publish.setVisibility(View.GONE);
        dynamic_delete.setVisibility(View.VISIBLE);
        dynamic_creatdate.setVisibility(View.VISIBLE);
        dynamic_contain.setVisibility(View.VISIBLE);
        dynamic_dynamicdatatv.setVisibility(View.VISIBLE);

        dynamic_listview.setVisibility(View.VISIBLE);
        dynamic_listview.setPullRefreshEnable(true); //允许下拉刷新
        dynamic_listview.setPullLoadEnable(true); //允许上拉加载更多
        dynamic_listview.setAutoLoadEnable(true); //允许下拉到底部后自动加载
        dynamic_listview.setXListViewListener(this);

        dynamic_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setData();
                finish();
            }
        });

        dynamic_videodata = (VideoView) findViewById(R.id.dynamic_videodata);
        dynamic_videodata.setMediaController(new MediaController(this));
        dynamic_videodata.setOnCompletionListener( new DynamicActivity.MyPlayerOnCompletionListener());
        dynamic_videodata.start();

        dynamic_headimg = (ImageView) findViewById(R.id.dynamic_headimg);
        dynamic_nikename = (TextView) findViewById(R.id.dynamic_nikename);
        dynamic_address = (TextView) findViewById(R.id.dynamic_address);

        dynamic_favor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setfavor();
            }
        });

        dynamic_comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(DynamicActivity.this,)
                dynamic_layout.setVisibility(View.GONE);
                comment_layout.setVisibility(View.VISIBLE);
            }
        });

        send_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setcomment();
                comment_layout.setVisibility(View.GONE);
                dynamic_layout.setVisibility(View.VISIBLE);
                onRefresh();
            }
        });

        getData();


    }

    public void getData() {
        mHandler = new Handler();
        int loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);

        JSONObject jsonObject1 = new JSONObject();
        try {
            jsonObject1.put("id", SharedPreferencesHelper.getInstance().getData("dynamicid",0));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity1;
        try {
            entity1 = new StringEntity(jsonObject1.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("ReturnDynamic.aspx", entity1, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){
                        dynamic_videodata.setVideoPath(response.getJSONObject("resultData").getString("videodata"));
                        dynamic_favornum.setText(response.getJSONObject("resultData").getString("favornum"));
                        dynamic_dynamicdatatv.setText(response.getJSONObject("resultData").getString("dynamicdata"));
                        dynamic_creatdate.setText(changeCreatdate(response.getJSONObject("resultData").getString("creatdate")));
                        dynamic_address.setText(response.getJSONObject("resultData").getString("address"));
                    }else {
                        Toast toast=Toast.makeText(DynamicActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id",SharedPreferencesHelper.getInstance().getData("creatid",0));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("ReturnUsers.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){

                        try {
                            //通过uri获取到bitmap对象
                            if(!response.getJSONObject("resultData").getString("headimg").equals("")){
                                Uri urig = Uri.fromFile(new File(response.getJSONObject("resultData").getString("headimg")));
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
                                dynamic_headimg.setImageBitmap(bitmap);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //dynamic_headimg.setImageBitmap();
                        dynamic_nikename.setText(response.getJSONObject("resultData").getString("nikename"));
                        Log.e("try", response.toString());
                    }else {
                        Toast toast=Toast.makeText(DynamicActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });

        JSONObject jsonObject2 = new JSONObject();
        try {
            jsonObject2.put("dynamicid",SharedPreferencesHelper.getInstance().getData("dynamicid",0));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            entity = new StringEntity(jsonObject2.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        Log.e("try", jsonObject2.toString());
        BaseClient.post("ReturnCommentListByDynamicId.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){
                        JSONArray comment_array = response.getJSONArray("resultData");
                        for(int i = 0; i < comment_array.length(); i ++){
                            JSONObject jsonObject1 = (JSONObject) comment_array.get(i);
                            Comment comment = new Comment(jsonObject1.getInt("id"),jsonObject1.getInt("dynamicid"),jsonObject1.getInt("creatid"),
                                    jsonObject1.getString("creatdate"),jsonObject1.getString("commentdata"),jsonObject1.getInt("commentstate"));
                            _list_comment.add(comment);
                        }
                        ReviewAdapter reviewAdapter = new ReviewAdapter(dynamic_listview.getContext(), _list_comment);
                        dynamic_listview.setAdapter(reviewAdapter);
                        Log.e("try", response.toString());
                    }else {
                        Toast toast=Toast.makeText(DynamicActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                onLoaded();
            }
        });
    }

    public void setData() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id", SharedPreferencesHelper.getInstance().getData("dynamicid",0));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("DeleteDynamic.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1) {
                        Log.e("try", response.toString());
                    } else {
                        Toast toast = Toast.makeText(DynamicActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    public void setfavor(){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("dynamicid", SharedPreferencesHelper.getInstance().getData("dynamicid",0));
            jsonObject.put("creatid",SharedPreferencesHelper.getInstance().getData("id",0));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("AddNewFavor.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1) {
                        Log.e("try", response.toString());
                    } else {
                        Toast toast = Toast.makeText(DynamicActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    public void setcomment(){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("dynamicid", SharedPreferencesHelper.getInstance().getData("dynamicid",0));
            jsonObject.put("creatid",SharedPreferencesHelper.getInstance().getData("id",0));
            jsonObject.put("commentdata",send_comment.getText());
            jsonObject.put("commentstate",0);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("AddNewComment.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1) {
                        Log.e("try", response.toString());
                    } else {
                        Toast toast = Toast.makeText(DynamicActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    class MyPlayerOnCompletionListener implements MediaPlayer.OnCompletionListener {
        @Override
        public void onCompletion(MediaPlayer mp) {
            Toast.makeText( DynamicActivity.this, "播放完成了", Toast.LENGTH_SHORT).show();
        }
    }

    public static Intent newIntent(Context packageContext, int dynamicId){
        Intent intent = new Intent(packageContext, DynamicActivity.class);
        intent.putExtra(DYNAMIC_ID, dynamicId);
        return intent;
    }

    public String changeCreatdate(String creatdate) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date strtodate = formatter.parse(creatdate);
            creatdate = formatter2.format(strtodate);
            String dateString = formatter1.format(strtodate);
            String hour = creatdate.substring(11, 13);
            String min = creatdate.substring(14, 16);
            creatdate = dateString + " " + hour + ":" + min;
        }catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return creatdate;
    }

    //下拉刷新
    @Override
    public void onRefresh() {
        // TODO Auto-generated method stub
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                _list_comment = new ArrayList<Comment>();
                getData();
            }
        }, 2);
    }

    //上拉加载更多
    @Override
    public void onLoadMore() {
        // TODO Auto-generated method stub
//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                getData();
//            }
//        },2);
    }

    //完成数据加载
    private void onLoaded() {
        dynamic_listview.stopRefresh(); //停止刷新
        dynamic_listview.stopLoadMore(); //停止加载更多
        dynamic_listview.setRefreshTime(getTime());
    }

    private String getTime() {
        return new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(new Date());
    }
}
