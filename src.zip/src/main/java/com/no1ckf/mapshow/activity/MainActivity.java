package com.no1ckf.mapshow.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.location.Poi;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.model.Dynamic;
import com.no1ckf.mapshow.model.Main;
import com.no1ckf.mapshow.model.Users;
import com.no1ckf.mapshow.utils.BDlistener;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.OrientationSensor;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends FragmentActivity {
    private MapView mMapView;
    private BaiduMap mBaiduMap;
    private ImageView merchant_info, merchant_review, merchant_dynamic, merchant_publish;
    private CircleImageView mer_title;
    private LocationClient mLocationClient;
    private BDLocation mlocation;
    private BitmapDescriptor mMarkDescriptor;
    private JSONArray jsonObject1;
    private Marker marker = null;
    private final List<Main> _list_main = new ArrayList<Main>();
    //private LatLng latLng = null;
    private final List<OverlayOptions> options = new ArrayList<OverlayOptions>();
    private Bitmap bitmap;
    //public LocationClient mLocationClient = null;
    //public BDLocationListener myListener = new MyLocationListener();

    private OrientationSensor mOrientationSensor;
    /**
     * 传感器方向
     */
    private float driection = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_main);
        mer_title = (CircleImageView) findViewById(R.id.mer_title);
        showAllMarkersOnMap();
        init();
    }

    private void init() {
        mMapView = (MapView) findViewById(R.id.mer_map);
        mMapView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("Main","mMapView");
            }
        });
        mBaiduMap = mMapView.getMap();
        mBaiduMap.setMapType(BaiduMap.MAP_TYPE_SATELLITE);

        merchant_info = (ImageView) findViewById(R.id.merchant_info);
        merchant_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("Main","info");
                Intent intent = new Intent(MainActivity.this,InfoActivity.class);
                startActivity(intent);
            }
        });

        merchant_review = (ImageView) findViewById(R.id.merchant_review);
        merchant_review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ReviewActivity.class);
                startActivity(intent);
                Log.e("Main","review");
            }
        });

        merchant_dynamic = (ImageView) findViewById(R.id.merchant_dynamic);
        merchant_dynamic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AllDynamicActivity.class);
                startActivity(intent);
                Log.e("Main","go1");
            }
        });

        merchant_publish = (ImageView) findViewById(R.id.merchant_publish);
        merchant_publish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PublishActivity.class);
                startActivity(intent);
                Log.e("Main","go2");
            }
        });


        mOrientationSensor = new OrientationSensor(this);
        mOrientationSensor.start();
        mOrientationSensor.setOrientationListener(new OrientationSensor.OrientationSensorListener() {
            @Override
            public void getOrientation(float x) {
                driection = x;
            }
        });

        // 开启定位图层
        mBaiduMap.setMyLocationEnabled(true);
        //mBaiduMap.addOverlays(options);

        //List<OverlayOptions> options = new ArrayList<OverlayOptions>();
        String str = (String) SharedPreferencesHelper.getInstance().getData("main","0");
        Log.e("sre",str);
        try{
            JSONObject json = new JSONObject(str);
            JSONArray js = json.getJSONArray("resultData");
            for(int i = 0;i<js.length();i++){
                //jsonObject1.put(response.getJSONArray("resultData").get(i));
                try {
                    Uri urig = Uri.fromFile(new File(((JSONObject) js.get(i)).getString("headimg")));
                    //mer_title.setImageURI(urig);
                    BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromPath(((JSONObject) js.get(i)).getString("headimg"));
                    BitmapDescriptor bitmap = BitmapDescriptorFactory.fromView(mer_title);
                    //Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
                    //view.setImageBitmap(bitmap);
                    Log.i("img", ((JSONObject) js.get(i)).getString("latlng"));
                    JSONObject jsonObject = new JSONObject(((JSONObject) js.get(i)).getString("latlng"));
                    Log.i("js",jsonObject.getString("lat"));
                    LatLng point = new LatLng(jsonObject.getDouble("lat"), jsonObject.getDouble("lon"));
                    Main main = new Main(((JSONObject) js.get(i)).getInt("id"),((JSONObject) js.get(i)).getString("headimg")
                            ,jsonObject.getDouble("lat"),jsonObject.getDouble("lon"));
                    _list_main.add(main);
                    //options.add( new MarkerOptions().position(point).icon(bitmap1));
                    //在地图上批量添加
                    //通过uri获取到bitmap对象
                    //Uri urig = Uri.fromFile(new File(((JSONObject)response.getJSONArray("resultData").get(i)).getString("headimg")));
                    //Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
                    //view.setImageBitmap(bitmap);
                    Log.i("img", ((JSONObject) js.get(i)).getString("headimg"));
                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }catch (JSONException e){
            e.printStackTrace();
        }

        Log.i("list",String.valueOf(_list_main.size()));
        for(int i=0;i<_list_main.size();i++){
            Uri urig = Uri.fromFile(new File(_list_main.get(i).getHeadimg()));
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
                //bitmap.setHeight(40);
                //bitmap.setWidth(40);
                int originalWidth = bitmap.getWidth();
                int originalHeight = bitmap.getHeight();
                int newWidth = 100;
                int newHeight = 150;
                float scale = ((float) newHeight) / originalHeight;
                Matrix matrix = new Matrix();
                matrix.postScale(scale, scale);
                Bitmap changedBitmap = Bitmap.createBitmap(bitmap, 0, 0,
                        originalWidth, originalHeight, matrix, true);
                //changedImageView.setImageBitmap(changedBitmap);
                mer_title.setImageBitmap(changedBitmap);
                mer_title.setAlpha(0);
                //mer_title.
                //mer_title.
                BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromPath(_list_main.get(i).getHeadimg());
                BitmapDescriptor bitmap2 = BitmapDescriptorFactory.fromView(mer_title);
                //Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
                //view.setImageBitmap(bitmap);
                // Log.i("img", ((JSONObject) response.getJSONArray("resultData").get(i)).getString("latlng"));
                //JSONObject js = new JSONObject(((JSONObject) response.getJSONArray("resultData").get(i)).getString("latlng"));
                //Log.i("js",js.getString("lat"));
                LatLng point = new LatLng(_list_main.get(i).getLat(), _list_main.get(i).getLng());

                options.add( new MarkerOptions().position(point).icon(bitmap2));
            } catch (IOException e) {
                e.printStackTrace();
            }


            //mer_title.setImageURI(urig);
            //mer_title.setImageBitmap(bitmap);
            //mer_title.setAlpha(0);
            //mer_title.
            //mer_title.
            //BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromPath(_list_main.get(i).getHeadimg());
            //BitmapDescriptor bitmap2 = BitmapDescriptorFactory.fromView(mer_title);
            //Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
            //view.setImageBitmap(bitmap);
            // Log.i("img", ((JSONObject) response.getJSONArray("resultData").get(i)).getString("latlng"));
            //JSONObject js = new JSONObject(((JSONObject) response.getJSONArray("resultData").get(i)).getString("latlng"));
            //Log.i("js",js.getString("lat"));
            //LatLng point = new LatLng(_list_main.get(i).getLat(), _list_main.get(i).getLng());

            //options.add( new MarkerOptions().position(point).icon(bitmap2));

        }


//        initLocation();
//
//        mLocationClient = new LocationClient(getApplicationContext());
//        mLocationClient.registerLocationListener(new BDLocationListener() {
//            @Override
//            public void onReceiveLocation(BDLocation location) {
//                // TODO Auto-generated method stub
//                MyLocationConfiguration.LocationMode mCurrentMode = MyLocationConfiguration.LocationMode.FOLLOWING;//定位跟随态
////                MyLocationConfiguration.LocationMode mCurrentMode = MyLocationConfiguration.LocationMode.NORMAL;   //默认为 LocationMode.NORMAL 普通态
////                MyLocationConfiguration.LocationMode mCurrentMode = MyLocationConfiguration.LocationMode.COMPASS;  //定位罗盘态
//
//                // 构造定位数据
//                MyLocationData locData = new MyLocationData.Builder()
//                        .accuracy(location.getRadius())
//                        // 此处设置开发者获取到的方向信息，顺时针0-360
//                        .direction(100).latitude(location.getLatitude())
//                        .longitude(location.getLongitude()).build();
//
//                //Log.e("Location",String.valueOf(location.getRadius() + " / " + location.getLatitude() + " / " + location.getLongitude()));
//                // 设置定位数据
//                mBaiduMap.setMyLocationData(locData);
//
//                // 设置定位图层的配置（定位模式，是否允许方向信息，用户自定义定位图标）
//                BitmapDescriptor mCurrentMarker = BitmapDescriptorFactory.fromResource(R.drawable.arrow);
//                MyLocationConfiguration config = new MyLocationConfiguration(mCurrentMode, true, mCurrentMarker);
//                mBaiduMap.setMyLocationConfiguration(config);
//            }
//        });
//        mLocationClient.start();

        new Thread(new com.no1ckf.mapshow.activity.MainActivity.MyThread()).start();


        //showAllMarkersOnMap();

        //定义Maker坐标点
//        LatLng point = new LatLng(39.963175, 116.400244);
//        LatLng point1 = new LatLng(30.963175, 120.400244);
//
//        //构建Marker图标
//        BitmapDescriptor bitmap = BitmapDescriptorFactory.fromResource(R.drawable.edit);
//        BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromPath("/storage/emulated/0/tencent/MicroMsg/WeiXin/mmexport1528947656338.jpg");
//        BitmapDescriptor bitmap2 = BitmapDescriptorFactory.fromView(merchant_info);
//
//        //mer_title = (CircleImageView) findViewById(R.id.headimg);
//        mer_title.setImageResource(R.drawable.edit);
//        BitmapDescriptor bitmap3 = BitmapDescriptorFactory.fromView(mer_title);
//
//        //构建MarkerOption，用于在地图上添加Marker
//        OverlayOptions option = new MarkerOptions().position(point).icon(bitmap3);
        //options.add(option);

        //在地图上添加Marker，并显示
        //mBaiduMap.addOverlay(option);
        //option = new MarkerOptions().position(point1).icon(bitmap3);
        //options.add(option);
        mBaiduMap.addOverlays(options);
        mer_title.setWillNotDraw(true);
        //showAllMarkersOnMap();


//        ClusterManager mClusterManager = new ClusterManager<>(this, mBaiduMap);
//
//// 向点聚合管理类中添加Marker实例
//
//        LatLng llA = new LatLng(39.963175, 116.400244);
//
//        List<MyItem> items = new ArrayList<>();
//
//        items.add(new MyItem(llA));
//
//        mClusterManager.addItems(items);
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        mLocationClient.stop();
        mMapView.onDestroy();
    }
    @Override
    protected void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();
    }

    private void initLocation() {
        LocationClientOption option = new LocationClientOption();
        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);
        //可选，默认高精度，设置定位模式，高精度，低功耗，仅设备
        option.setCoorType("WGS84");//可选，默认 gcj02国标，设置返回的定位结果坐标系 bd09ll百度 WGS84国际
        option.setScanSpan(1000);
        //可选，默认 0，即仅定位一次，设置发起定位请求的间隔需要大于等于 1000ms 才是有效的
        option.setIsNeedAddress(true);//可选，设置是否需要地址信息，默认不需要
        option.setOpenGps(true);//可选，默认 false,设置是否使用 gps
        option.setLocationNotify(true);
        //可选，默认 false，设置是否当 gps 有效时按照 1S1 次频率输出 GPS 结果
        option.setIgnoreKillProcess(true);
        //可选，默认 true，定位 SDK 内部是一个 SERVICE，并放到了独立进程，
        // 设置是否在 stop 的时候杀死这个进程，默认不杀死
        option.setEnableSimulateGps(false);
        //可选，默认 false，设置是否需要过滤 gps 仿真结果，默认需要
        option.setIsNeedLocationDescribe(true);
        //可选，默认 false，设置是否需要位置语义化结果，
        // 可以在 BDLocation.getLocationDescribe 里得到，结果类似于“在北京天安门附近”
        option.setIsNeedLocationPoiList(true);//可选，默认 false，设置是否需要 POI 结果，
        // 可以在 BDLocation.getPoiList 里得到
        // mLocationClient.setLocOption(option);
        option.setNeedDeviceDirect(true); //返回的定位结果包含手机机头方向
    }

    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            if(msg.what==1){
                //initLocation();
                //startLocate();
                BDlistener.getInstance().startLocate();

                mLocationClient = new LocationClient(getApplicationContext());
                mLocationClient.registerLocationListener(new BDLocationListener() {
                    @Override
                    public void onReceiveLocation(BDLocation location) {
                        // TODO Auto-generated method stub

                        location.setLatitude(pianyi(location.getLongitude(),location.getLatitude()).getLatitude());
                        location.setLongitude(pianyi(location.getLongitude(),location.getLatitude()).getLongitude());

                        MyLocationConfiguration.LocationMode mCurrentMode = MyLocationConfiguration.LocationMode.FOLLOWING;//定位跟随态
//                MyLocationConfiguration.LocationMode mCurrentMode = MyLocationConfiguration.LocationMode.NORMAL;   //默认为 LocationMode.NORMAL 普通态
//                MyLocationConfiguration.LocationMode mCurrentMode = MyLocationConfiguration.LocationMode.COMPASS;  //定位罗盘态

                        // 构造定位数据
                        MyLocationData locData = new MyLocationData.Builder()
                                .accuracy(location.getRadius())
                                // 此处设置开发者获取到的方向信息，顺时针0-360
                                .direction(driection).latitude(location.getLatitude())
                                .longitude(location.getLongitude()).build();

                        Log.e("Location",String.valueOf(String.valueOf(driection) + " / " + location.getLatitude() + " / " + location.getLongitude() + " / " + location.getLocationDescribe()));
                        // 设置定位数据
                        mBaiduMap.setMyLocationData(locData);


                        // 设置定位图层的配置（定位模式，是否允许方向信息，用户自定义定位图标）
                        BitmapDescriptor mCurrentMarker = BitmapDescriptorFactory.fromResource(R.drawable.arrow);
                        MyLocationConfiguration config = new MyLocationConfiguration(mCurrentMode, true, mCurrentMarker);
                        mBaiduMap.setMyLocationConfiguration(config);
                    }
                });
                mLocationClient.start();
            }
            super.handleMessage(msg);
        }
    };

    class MyThread extends Thread {
        @Override
        public void run(){
            while(true){
                try{
                    Thread.sleep(1000);
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        }
    }

    private BDLocation pianyi(double lon,double lat) {
        double x = lon; double y = lat;
        double z = Math.sqrt(x*x+y*y) + 0.00002 *Math.sin(y*Math.PI) ;
        double temp =Math.atan2(y, x)  + 0.000003 * Math.cos(x*Math.PI);

        double bdLon = z * Math.cos(temp) + 0.0065;
        double bdLat = z * Math.sin(temp) + 0.006;
        BDLocation location = new BDLocation();
        location.setLatitude(bdLat);
        location.setLongitude(bdLon);
        return location;
    }

    /**
     * 将所有任务以发布人头像显示在地图上
     */
    private void showAllMarkersOnMap(){
        //mBaiduMap.clear();
//        Marker marker = null;
////        LatLng latLng = null;
////        OverlayOptions options;

        Log.e("getData", "getData");
        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id","1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        //final JSONArray jsonObject1 = new JSONArray();
        BaseClient.post("ReturnHeadimgByDynamicList.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){
                        SharedPreferencesHelper.getInstance().saveData("main",response.toString());
//                        for(int i = 0;i<response.getJSONArray("resultData").length();i++){
//                            //jsonObject1.put(response.getJSONArray("resultData").get(i));
//                            try {
//                                //通过uri获取到bitmap对象
//                                SharedPreferencesHelper.getInstance().saveData("main",);
//
//                                Uri urig = Uri.fromFile(new File(((JSONObject) response.getJSONArray("resultData").get(i)).getString("headimg")));
//                                //mer_title.setImageURI(urig);
//                                BitmapDescriptor bitmap1 = BitmapDescriptorFactory.fromPath(((JSONObject) response.getJSONArray("resultData").get(i)).getString("headimg"));
//                                BitmapDescriptor bitmap = BitmapDescriptorFactory.fromView(mer_title);
//                                //Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
//                                //view.setImageBitmap(bitmap);
//                                Log.i("img", ((JSONObject) response.getJSONArray("resultData").get(i)).getString("latlng"));
//                                JSONObject js = new JSONObject(((JSONObject) response.getJSONArray("resultData").get(i)).getString("latlng"));
//                                Log.i("js",js.getString("lat"));
//                                LatLng point = new LatLng(js.getDouble("lat"), js.getDouble("lon"));
//
//                                Main main = new Main(((JSONObject) response.getJSONArray("resultData").get(i)).getInt("id"),((JSONObject) response.getJSONArray("resultData").get(i)).getString("headimg")
//                                        ,js.getDouble("lat"),js.getDouble("lon"));
//                                _list_main.add(main);
//
//                                //options.add( new MarkerOptions().position(point).icon(bitmap1));
//
//                                //在地图上批量添加
//
//                                //通过uri获取到bitmap对象
//                                //Uri urig = Uri.fromFile(new File(((JSONObject)response.getJSONArray("resultData").get(i)).getString("headimg")));
//                                //Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
//                                //view.setImageBitmap(bitmap);
//                                Log.i("img", ((JSONObject) response.getJSONArray("resultData").get(i)).getString("headimg"));
//                            }catch (JSONException e){
//                                e.printStackTrace();
//                            }
//                        }

                    }else {

                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
        //try{
         //   Log.e("json",String.valueOf(jsonObject1.length()));
        //}catch (JSONException e) {
            // TODO Auto-generated catch block
         //   e.printStackTrace();
        //}
//        for(int i=0;i<jsonObject1.length();i++){
////            try{
////
////            }catch (JSONException e) {
////                // TODO Auto-generated catch block
////                e.printStackTrace();
////            }
//            //jsonObject2.getString("id");
//
//            try {
//                //通过uri获取到bitmap对象
//                Uri urig = Uri.fromFile(new File(((JSONObject)jsonObject1.get(i)).getString("headimg")));
//                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
//                mer_title.setImageBitmap(bitmap);
//                Log.i("img",((JSONObject)jsonObject1.get(i)).getString("headimg"));
//            } catch (IOException e) {
//                e.printStackTrace();
//            }catch (JSONException e){
//                e.printStackTrace();
//            }
//
//            mer_title.setImageAlpha(0);
//            mMarkDescriptor = BitmapDescriptorFactory
//                    .fromView(mer_title);
//            options = new MarkerOptions().position(latLng)
//                    .icon(mMarkDescriptor).zIndex(5);
//            marker = (Marker) mBaiduMap.addOverlay(options);
//            Bundle arg0 = new Bundle();
//            arg0.putSerializable("info", 1);
//            marker.setExtraInfo(arg0);
//        }

        //创建OverlayOptions的集合


        //MapStatusUpdate msu = MapStatusUpdateFactory.newLatLng(latLng);
        //mBaiduMap.setMapStatus(msu);
    }



}
