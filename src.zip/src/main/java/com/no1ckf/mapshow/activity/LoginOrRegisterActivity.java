package com.no1ckf.mapshow.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class LoginOrRegisterActivity extends Activity {
    private static final String LOGIN_OR_REGISTER = "com.no1ckf.mapshow.activity.login_or_register";

//    SharedPreferences myPreference = getSharedPreferences("myPreference", Context.MODE_PRIVATE);
//    SharedPreferences.Editor editor = myPreference.edit();

    private EditText loorre_tx1, loorre_tx2;
    private Button loorre_btn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_or_register);

        loorre_tx1 = (EditText) findViewById(R.id.loorre_tx1);
        loorre_tx2 = (EditText) findViewById(R.id.loorre_tx2);
        loorre_btn = (Button) findViewById(R.id.loorre_btn);

        if(getIntent().getStringExtra(LOGIN_OR_REGISTER).equals("login")){
            loorre_tx1.setHint("请输入用户名");
            loorre_tx2.setHint("请输入密码");
            loorre_btn.setText("登陆");
        }else{
            loorre_tx1.setHint("请输入新用户名");
            loorre_tx2.setHint("请输入新密码");
            loorre_btn.setText("注册");
        }

        loorre_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
            }
        });
    }

    public void getData() {
        JSONObject jsonObject = new JSONObject();
        HttpEntity entity;
        String url = "";
        try {
            jsonObject.put("username",loorre_tx1.getText());
            jsonObject.put("password",loorre_tx2.getText());
            if(getIntent().getStringExtra(LOGIN_OR_REGISTER).equals("login")){
                url = "CheckLogin.aspx";
            }else{
                url = "Register.aspx";
                jsonObject.put("sex","男");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }

        BaseClient.post(url, entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){
                        SharedPreferencesHelper.getInstance().saveData("id", response.getJSONObject("resultData").getInt("id"));
                        Log.e("try", response.toString());
                        finish();
                    }else {
                        SharedPreferencesHelper.getInstance().saveData("id", 0);
                        Toast toast=Toast.makeText(LoginOrRegisterActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    public static Intent newIntent(Context packageContext, String type){
        Intent intent = new Intent(packageContext, LoginOrRegisterActivity.class);
        intent.putExtra(LOGIN_OR_REGISTER, type);
        return intent;
    }
}
