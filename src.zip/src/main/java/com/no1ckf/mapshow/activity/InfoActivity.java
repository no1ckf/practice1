package com.no1ckf.mapshow.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.fragment.FavorFragment;
import com.no1ckf.mapshow.fragment.MineFragment;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;
import com.shizhefei.view.indicator.Indicator;
import com.shizhefei.view.indicator.IndicatorViewPager;
import com.shizhefei.view.indicator.slidebar.ColorBar;
import com.shizhefei.view.indicator.transition.OnTransitionTextListener;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import de.hdodenhof.circleimageview.CircleImageView;

public class InfoActivity extends FragmentActivity {

//    SharedPreferences myPreference = getSharedPreferences("myPreference", Context.MODE_PRIVATE);
//    SharedPreferences.Editor editor = myPreference.edit();

    private IndicatorViewPager indicatorViewPager;
    private LinearLayout info_login, info_unlogin;
    private Button info_loginbtn, info_registerbtn;
    private ImageView info_back, info_setting;
    private CircleImageView info_headimg;
    private TextView info_signature, info_nikename;
    private static int loginid;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

//        info_login = (LinearLayout) findViewById(R.id.info_login);
//        info_unlogin = (LinearLayout) findViewById(R.id.info_unlogin);

//        final ViewPager viewPager = (ViewPager) findViewById(R.id.tabmain_viewPager);
//
//        Indicator indicator = (Indicator) findViewById(R.id.tabmain_indicator);
//        indicator.setScrollBar(new ColorBar(getApplicationContext(),
//                getResources().getColor(R.color.pink), 5));
//
//        int selectColor = getResources().getColor(R.color.pink);
//        int unSelectColor = getResources().getColor(R.color.tab_text_color);
//        indicator.setOnTransitionListener(new OnTransitionTextListener()
//                .setColor(selectColor, unSelectColor).setSize(17, 17));
//
//        indicatorViewPager = new IndicatorViewPager(indicator, viewPager);
//        indicatorViewPager.setAdapter(new MyAdapter(getSupportFragmentManager()));

//        SharedPreferences myPreference = getSharedPreferences("myPreference", Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = myPreference.edit();
//        editor.putInt("id", 0);
//        editor.apply();
//        loginid = myPreference.getInt("id",0);

        init();

//        if(loginid == 0){
//            info_login.setVisibility(View.GONE);
//            info_unlogin.setVisibility(View.VISIBLE);
//        }else{
//            info_unlogin.setVisibility(View.GONE);
//            info_login.setVisibility(View.VISIBLE);
//        }
    }

    @Override
    public void onResume() {
        super.onResume();
        init();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    public void init() {

        loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);

        info_headimg = (CircleImageView) findViewById(R.id.info_headimg);
        info_signature = (TextView) findViewById(R.id.info_signature);
        info_nikename = (TextView) findViewById(R.id.info_nikename);

        info_back = (ImageView) findViewById(R.id.info_back);
        info_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        info_login = (LinearLayout) findViewById(R.id.info_login);
        info_unlogin = (LinearLayout) findViewById(R.id.info_unlogin);
        if(loginid == 0){
            //未登录
            info_login.setVisibility(View.GONE);
            info_unlogin.setVisibility(View.VISIBLE);

            info_loginbtn = (Button) findViewById(R.id.info_loginbtn);
            info_loginbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = LoginOrRegisterActivity.newIntent(InfoActivity.this, "login");
                    //Intent intent = new Intent(InfoActivity.this, LoginOrRegisterActivity.class);
                    startActivity(intent);
                }
            });

            info_registerbtn = (Button) findViewById(R.id.info_registerbtn);
            info_registerbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = LoginOrRegisterActivity.newIntent(InfoActivity.this, "register");
                    startActivity(intent);
                }
            });

        }else{
            //已登陆
            info_unlogin.setVisibility(View.GONE);
            info_login.setVisibility(View.VISIBLE);

            final ViewPager viewPager = (ViewPager) findViewById(R.id.tabmain_viewPager);

            Indicator indicator = (Indicator) findViewById(R.id.tabmain_indicator);
            indicator.setScrollBar(new ColorBar(getApplicationContext(),
                    getResources().getColor(R.color.pink), 5));

            int selectColor = getResources().getColor(R.color.pink);
            int unSelectColor = getResources().getColor(R.color.tab_text_color);
            indicator.setOnTransitionListener(new OnTransitionTextListener()
                    .setColor(selectColor, unSelectColor).setSize(17, 17));

            indicatorViewPager = new IndicatorViewPager(indicator, viewPager);
            indicatorViewPager.setAdapter(new MyAdapter(getSupportFragmentManager()));

            info_setting = (ImageView) findViewById(R.id.info_setting);
            info_setting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(InfoActivity.this, SettingActivity.class);
                    startActivity(intent);
                }
            });
        }
        getData();
    }

    public void getData(){
        loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id",loginid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        if(loginid == 0){
            info_headimg.setImageResource(R.drawable.logo_start);
            info_signature.setText("Text");
            info_nikename.setText("Text");
        }else{
            BaseClient.post("ReturnUsers.aspx", entity, new JsonHttpResponseHandler() {
                //@SuppressLint("SimpleDateFormat")
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    // If the response is JSONObject instead of expected
                    // JSONArray
                    Log.e("onSuccess", response.toString());
                    try {
                        if (response.getInt("resultCode") == 1){
                            //通过uri获取到bitmap对象
                            try {
                                //通过uri获取到bitmap对象
                                if(!response.getJSONObject("resultData").getString("headimg").equals("")){
                                    Uri urig = Uri.fromFile(new File(response.getJSONObject("resultData").getString("headimg")));
                                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
                                    info_headimg.setImageBitmap(bitmap);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            //info_headimg.setImageBitmap();
                            info_signature.setText(response.getJSONObject("resultData").getString("signature"));
                            info_nikename.setText(response.getJSONObject("resultData").getString("nikename"));
                            Log.e("try", response.toString());
                        }else {
                            info_headimg.setImageResource(R.drawable.logo_start);
                            info_signature.setText("Text");
                            info_nikename.setText("Text");
                            Toast toast=Toast.makeText(InfoActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    private class MyAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter {
        private String[] tabNames = {"我的", "喜欢"};
        private LayoutInflater inflater;

        public MyAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
            inflater = LayoutInflater.from(getApplicationContext());
        }

        @Override
        public int getCount() {
            return tabNames.length;
        }

        @Override
        public View getViewForTab(int position, View convertView,
                                  ViewGroup container) {
            if (convertView == null) {
                convertView = (TextView) inflater.inflate(R.layout.tab_main,
                        container, false);
            }

            TextView textView = (TextView) convertView;
            textView.setText(tabNames[position]);

            return textView;
        }

        @Override
        public Fragment getFragmentForPage(int position) {
            Fragment fragment = null;
            switch (position) {
                case 0:
                    fragment = new MineFragment();
                    break;
                case 1:
                    fragment = new FavorFragment();
                    break;
                default:
                    break;
            }
            return fragment;
        }
    }

}
