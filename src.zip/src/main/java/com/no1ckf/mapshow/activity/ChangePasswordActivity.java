package com.no1ckf.mapshow.activity;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class ChangePasswordActivity extends Activity {
    private EditText old_password_tx,new_password_tx;
    private Button change_password_btn;
    private int loginid;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        old_password_tx = (EditText) findViewById(R.id.old_password_tx);
        new_password_tx = (EditText) findViewById(R.id.new_password_tx);
        change_password_btn = (Button) findViewById(R.id.change_password_btn);
        change_password_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(old_password_tx.getText().toString().equals(new_password_tx.getText().toString())){
                    getData();
                }else {
                    Toast toast=Toast.makeText(ChangePasswordActivity.this, "密码不一致", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
    }

    public void getData(){
        loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id",loginid);
            jsonObject.put("password",new_password_tx.getText());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("EditUsers.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){
                        Toast toast=Toast.makeText(ChangePasswordActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                        finish();
                    }else {
                        Toast toast=Toast.makeText(ChangePasswordActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }
}
