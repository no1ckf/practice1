package com.no1ckf.mapshow.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.MyApplication;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.adapter.DynamicAdapter;
import com.no1ckf.mapshow.adapter.ReviewAdapter;
import com.no1ckf.mapshow.model.Comment;
import com.no1ckf.mapshow.model.Dynamic;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;
import com.no1ckf.mapshow.widget.XListView;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static com.no1ckf.mapshow.MyApplication.getContext;

public class AllDynamicActivity extends FragmentActivity implements XListView.IXListViewListener {
    private static final String DYNAMIC_ID = "com.no1ckf.mapshow.dynamic_id";

    private VideoView dynamic_videodata;
    private ImageView dynamic_headimg,dynamic_favor,dynamic_comment,dynamic_delete;
    private TextView dynamic_dynamicdatatv,dynamic_nikename,dynamic_creatdate,dynamic_address,dynamic_favornum;
    private EditText dynamic_dynamicdataetx;
    private XListView dynamic_listview;
    private Button dynamic_publish;
    private LinearLayout dynamic_contain;
    private String videoPath = null;
    private int key = 0;
    private List<Dynamic> _list_dynamic =new ArrayList<Dynamic>();
    private Handler mHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_listview);

        dynamic_listview = (XListView) findViewById(R.id.listview);
        dynamic_listview.setPullRefreshEnable(true); //允许下拉刷新
        dynamic_listview.setPullLoadEnable(true); //允许上拉加载更多
        dynamic_listview.setAutoLoadEnable(true); //允许下拉到底部后自动加载
        dynamic_listview.setXListViewListener(this);

        getData();


    }

    public void getData() {
        mHandler = new Handler();
        int loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id",loginid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("ReturnDynamicList.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1) {
                        final JSONArray dynamic_array = response.getJSONArray("resultData");
                        for(int i = 0; i < dynamic_array.length(); i ++){
                            JSONObject jsonObjectall = (JSONObject) dynamic_array.get(i);
                            Dynamic dynamic = new Dynamic(jsonObjectall.getInt("id"),jsonObjectall.getInt("creatid"),jsonObjectall.getString("creatdate"),
                                    jsonObjectall.getString("dynamicdata"),jsonObjectall.getString("videodata"),jsonObjectall.getString("address"),
                                    jsonObjectall.getString("latlng"), jsonObjectall.getInt("commentnum"),jsonObjectall.getInt("favornum"));
                            _list_dynamic.add(dynamic);
                        }
                        DynamicAdapter dynamicAdapter = new DynamicAdapter(dynamic_listview.getContext(), _list_dynamic);
                        dynamic_listview.setAdapter(dynamicAdapter);
                        dynamic_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                final LinearLayout name=(LinearLayout)view.findViewById(R.id.ldynamic_Linearyout);
                                final ImageView name2 = (ImageView) view.findViewById(R.id.ldynamic_headimg);
                                //mClickListener.onClick(name., 0);
                                //fragment = new GameFragment();
                                //Log.e("all", name.getContentDescription().toString());
                                String flag = name.getContentDescription().toString();
                                //Log.e("all", flag);
                                int flag1 = Integer.parseInt(flag);
                                SharedPreferencesHelper.getInstance().saveData("dynamicid",flag1);
                                flag = name2.getContentDescription().toString();
                                //Log.e("all", flag);
                                flag1 = Integer.parseInt(flag);
                                SharedPreferencesHelper.getInstance().saveData("creatid",flag1);
                                Intent intent = new Intent(AllDynamicActivity.this,DynamicActivity.class);
                                startActivity(intent);
                            }
                        });

                        Log.e("try", response.toString());
                    } else {

                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                onLoaded();
            }
        });

    }

    DynamicAdapter.ClickListener Click = new DynamicAdapter.ClickListener() {
        @Override
        public void onClick(Object... objects) {
            if (objects[1].equals(0)) {
                Intent intent = DynamicActivity.newIntent(getApplicationContext(), (int)objects[0]);
                startActivity(intent);
            }
        }
    };

    //下拉刷新
    @Override
    public void onRefresh() {
        // TODO Auto-generated method stub
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                _list_dynamic = new ArrayList<Dynamic>();
                getData();
            }
        }, 2);
    }

    //上拉加载更多
    @Override
    public void onLoadMore() {
        // TODO Auto-generated method stub
//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                getData();
//            }
//        },2);
    }

    //完成数据加载
    private void onLoaded() {
        dynamic_listview.stopRefresh(); //停止刷新
        dynamic_listview.stopLoadMore(); //停止加载更多
        dynamic_listview.setRefreshTime(getTime());
    }

    private String getTime() {
        return new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(new Date());
    }
}
