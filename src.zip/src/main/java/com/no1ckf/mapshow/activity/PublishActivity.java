package com.no1ckf.mapshow.activity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.utils.BDlistener;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.OSSUtil;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;
import com.no1ckf.mapshow.widget.XListView;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PublishActivity extends Activity {
    private VideoView dynamic_videodata;
    private ImageView dynamic_headimg,dynamic_favor,dynamic_comment;
    private TextView dynamic_dynamicdatatv,dynamic_nikename,dynamic_creatdate,dynamic_address,dynamic_favornum;
    private EditText dynamic_dynamicdataetx;
    private XListView dynamic_listview;
    private Button dynamic_publish;
    private LinearLayout dynamic_contain;
    private String videoPath = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic);

        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(takeVideoIntent, 0);

        dynamic_creatdate = (TextView) findViewById(R.id.dynamic_creatdate);
        dynamic_contain = (LinearLayout) findViewById(R.id.dynamic_contain);
        dynamic_dynamicdatatv = (TextView) findViewById(R.id.dynamic_dynamicdatatv);
        dynamic_dynamicdataetx = (EditText) findViewById(R.id.dynamic_dynamicdataetx);
        dynamic_publish = (Button) findViewById(R.id.dynamic_publish);
        dynamic_listview = (XListView) findViewById(R.id.dynamic_listview);
        dynamic_creatdate.setVisibility(View.GONE);
        dynamic_contain.setVisibility(View.GONE);
        dynamic_dynamicdatatv.setVisibility(View.GONE);
        dynamic_dynamicdataetx.setVisibility(View.VISIBLE);

        dynamic_listview.setVisibility(View.GONE);
        dynamic_publish.setVisibility(View.VISIBLE);

        dynamic_publish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setData();
                finish();
            }
        });

        dynamic_videodata = (VideoView) findViewById(R.id.dynamic_videodata);
        dynamic_videodata.setMediaController(new MediaController(this));
        dynamic_videodata.setOnCompletionListener( new MyPlayerOnCompletionListener());
        dynamic_videodata.start();

        dynamic_headimg = (ImageView) findViewById(R.id.dynamic_headimg);
        dynamic_nikename = (TextView) findViewById(R.id.dynamic_nikename);
        dynamic_address = (TextView) findViewById(R.id.dynamic_address);

        getData();


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Uri uri = data.getData();
        if (uri != null) {
            Cursor cursor = this.getContentResolver().query(uri, null,
                    null, null, null);
            if (cursor.moveToFirst()) {
                videoPath = cursor.getString(cursor.getColumnIndex("_data"));// 获取绝对路径
            }
        }
        dynamic_videodata.setVideoPath(videoPath);
        Log.e("1",videoPath);
    }

    class MyPlayerOnCompletionListener implements MediaPlayer.OnCompletionListener {

        @Override
        public void onCompletion(MediaPlayer mp) {
            Toast.makeText( PublishActivity.this, "播放完成了", Toast.LENGTH_SHORT).show();
        }
    }

    public void getData() {
        int loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id",loginid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("ReturnUsers.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){

                        try {
                            //通过uri获取到bitmap对象
                            if(!response.getJSONObject("resultData").getString("headimg").equals("")){
                                Uri urig = Uri.fromFile(new File(response.getJSONObject("resultData").getString("headimg")));
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), urig);
                                dynamic_headimg.setImageBitmap(bitmap);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //dynamic_headimg.setImageBitmap();
                        dynamic_nikename.setText(response.getJSONObject("resultData").getString("nikename"));
                        dynamic_address.setText(BDlistener.getInstance().getLocationdescribe());
                        Log.e("try", response.toString());
                    }else {
                        Toast toast=Toast.makeText(PublishActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    public void setData() {
        int loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);
        JSONObject jsonObject = new JSONObject();
        //OSSUtil.uploadFile();
        //File file = new File(videoPath);
        //String url = OSSUtil.uploadFile(file,"mp4");
        if(videoPath != null) {
            try {
                jsonObject.put("creatid", loginid);
                //jsonObject.put("creatdate","1990-1-1 11:11:11");
                jsonObject.put("dynamicdata", dynamic_dynamicdataetx.getText());
                jsonObject.put("videodata", videoPath);
                jsonObject.put("address", dynamic_address.getText());
                jsonObject.put("latlng", BDlistener.getInstance().getlatlon().toString());
                jsonObject.put("commentnum",0);
                jsonObject.put("favornum",0);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Log.e("try", String.valueOf(jsonObject));
            HttpEntity entity;
            try {
                entity = new StringEntity(jsonObject.toString(), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }
            BaseClient.post("AddNewDynamic.aspx", entity, new JsonHttpResponseHandler() {
                //@SuppressLint("SimpleDateFormat")
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    // If the response is JSONObject instead of expected
                    // JSONArray
                    Log.e("onSuccess", response.toString());
                    try {
                        if (response.getInt("resultCode") == 1) {
                            Log.e("try", response.toString());
                        } else {
                            Toast toast = Toast.makeText(PublishActivity.this, response.getString("resultMessage"), Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            });
        }else{
            Toast toast = Toast.makeText(PublishActivity.this, "上传失败", Toast.LENGTH_SHORT);
            toast.show();
        }
    }
}
