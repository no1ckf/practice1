package com.no1ckf.mapshow.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.VideoView;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.MyApplication;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.model.Comment;
import com.no1ckf.mapshow.model.Dynamic;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class ReviewAdapter extends BaseAdapter {
    private LayoutInflater inflater;
    private List<Comment> _listData = null;
    private Context mContext;
    private String headimg,nikename;
    private Uri urig;
    private Bitmap bitmap;

    public  ReviewAdapter(Context context, List<Comment> list){

        _listData = new ArrayList<Comment>();
        _listData = list;
        this.mContext = context;
        inflater = LayoutInflater.from(mContext);
    }

    public interface ClickListener {
        public void onClick(Object ... objects);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return _listData == null ? 0 : _listData.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return _listData == null ? null : _listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return _listData == null ? 0 : position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub

        final ReviewAdapter.ViewHolder holder;
        View view = convertView;
        if(convertView == null){
            holder = new ReviewAdapter.ViewHolder();
            view = inflater.inflate(R.layout.list_review, parent,false);
            holder.comment_commentdata = (TextView) view.findViewById(R.id.comment_commentdata);
            holder.comment_creatdate = (TextView) view.findViewById(R.id.comment_creatdate);
            holder.comment_delete = (ImageView) view.findViewById(R.id.comment_delete);
            holder.comment_nikename = (TextView) view.findViewById(R.id.comment_nikename);
            holder.comment_headimg = (ImageView) view.findViewById(R.id.comment_headimg);

            //Log.e("group",String.valueOf());
            view.setTag(holder);
        }else{
            holder = (ReviewAdapter.ViewHolder) view.getTag();
        }

        //getData(_listData.get(position).getCreatid());
        getData(_listData.get(position).getCreatid(),holder.comment_headimg,holder.comment_nikename);

        //holder.comment_nikename.setText(nikename);
        //holder.comment_headimg.setImageBitmap(bitmap);

        holder.comment_commentdata.setText(_listData.get(position).getCommentdata());
        holder.comment_creatdate.setText(_listData.get(position).getCreatdate());
//        if(_listData.get(position).getCreatid() == (int) SharedPreferencesHelper.getInstance().getData("id",0)){
//
//        }

        //Utility.setListViewHeightBasedOnChildren(holder.elvScoreboard);

        return view;
    }

    public void getData(int creatid,final ImageView imageView,final TextView ntextView) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id",creatid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("ReturnUsers.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){
                        if(!response.getJSONObject("resultData").getString("headimg").equals("")){
                            try{
                                urig = Uri.fromFile(new File(response.getJSONObject("resultData").getString("headimg")));
                                bitmap = MediaStore.Images.Media.getBitmap(MyApplication.getInstance().getContentResolver(), urig);
                                imageView.setImageBitmap(bitmap);
                            }catch (IOException e){
                                e.printStackTrace();
                            }
                            //headimg = response.getJSONObject("resultData").getString("headimg");
                            //nikename = response.getJSONObject("resultData").getString("nikename");
                            ntextView.setText(response.getJSONObject("resultData").getString("nikename"));
                        }
                        Log.e("Review", response.toString());
                    }else {
                        //Toast toast=Toast.makeText(MyApplication.getContext(), response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        //toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    public class ViewHolder{
        private ImageView comment_headimg,comment_delete;
        private TextView comment_nikename,comment_commentdata,comment_creatdate;
    }
}
