package com.no1ckf.mapshow.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.constraint.solver.Cache;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.MyApplication;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.activity.DynamicActivity;
import com.no1ckf.mapshow.activity.InfoActivity;
import com.no1ckf.mapshow.activity.PublishActivity;
import com.no1ckf.mapshow.model.Dynamic;
import com.no1ckf.mapshow.utils.BDlistener;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;
import com.no1ckf.mapshow.utils.Utility;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class DynamicAdapter extends BaseAdapter {
    private ClickListener mClickListener;
    private LayoutInflater inflater;
    private List<Dynamic> _listData = null;
    private Context mContext;
    private String headimg,nikename;
    private Uri urig;
    private Bitmap bitmap;

    public  DynamicAdapter(Context context, List<Dynamic> list){

        _listData = new ArrayList<Dynamic>();
        _listData = list;
        this.mContext = context;
        inflater = LayoutInflater.from(mContext);
    }

    public interface ClickListener {
        public void onClick(Object ... objects);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return _listData == null ? 0 : _listData.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return _listData == null ? null : _listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return _listData == null ? 0 : position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub

        final DynamicAdapter.ViewHolder holder;
        View view = convertView;
        if(convertView == null){
            holder = new DynamicAdapter.ViewHolder();
            view = inflater.inflate(R.layout.list_dynamic, parent,false);
            holder.dynamic_creatdate = (TextView) view.findViewById(R.id.ldynamic_creatdate);
            //holder.dynamic_contain = (LinearLayout) view.findViewById(R.id.dynamic_contain);
            holder.dynamic_dynamicdatatv = (TextView) view.findViewById(R.id.ldynamic_dynamicdatatv);
            //holder.dynamic_dynamicdataetx = (EditText) view.findViewById(R.id.ldynamic_dynamicdataetx);
            //holder.dynamic_publish = (Button) view.findViewById(R.id.ldynamic_publish);
            //holder.dynamic_listview = (ListView) view.findViewById(R.id.ldynamic_listview);
            //holder.dynamic_videodata = (VideoView) view.findViewById(R.id.ldynamic_videodata);
            holder.dynamic_headimg = (ImageView) view.findViewById(R.id.ldynamic_headimg);
            holder.dynamic_nikename = (TextView) view.findViewById(R.id.ldynamic_nikename);
            holder.dynamic_address = (TextView) view.findViewById(R.id.ldynamic_address);
            holder.dynamic_favornum = (TextView) view.findViewById(R.id.ldynamic_favornum);
            holder.dynamic_Linearyout = (LinearLayout) view.findViewById(R.id.ldynamic_Linearyout);

           view.setTag(holder);
        }else{
            holder = (DynamicAdapter.ViewHolder) view.getTag();
        }

        holder.dynamic_creatdate.setText(_listData.get(position).getCreatdate());
        holder.dynamic_dynamicdatatv.setText(_listData.get(position).getDynamicdata());
        holder.dynamic_Linearyout.setContentDescription(String.valueOf(_listData.get(position).getId()));
        holder.dynamic_headimg.setContentDescription(String.valueOf(_listData.get(position).getCreatid()));
//        holder.dynamic_Linearyout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mClickListener.onClick(_listData.get(position).getId(), 0);
//                SharedPreferencesHelper.getInstance().saveData("dynamicid",holder.dynamic_dynamicdatatv.getContentDescription());
//            }
//        });
        holder.dynamic_favornum.setText(_listData.get(position).getFavornum());
        //holder.dynamic_videodata.setVideoPath(_listData.get(position).getVideodata());
        //holder.dynamic_videodata.setMediaController(new MediaController());
        //holder.dynamic_videodata.setOnCompletionListener(new MyPlayerOnCompletionListener());
        //holder.dynamic_videodata.start();

        getData(_listData.get(position).getCreatid(),holder.dynamic_headimg,holder.dynamic_nikename);

        //holder.dynamic_nikename.setText(nikename);

        holder.dynamic_address.setText(_listData.get(position).getAddress());


        //Utility.setListViewHeightBasedOnChildren(holder.elvScoreboard);

        return view;
    }

    public class ViewHolder{
//        private VideoView dynamic_videodata;
        private ImageView dynamic_headimg,dynamic_favor,dynamic_comment;
        private TextView dynamic_dynamicdatatv,dynamic_creatdate,dynamic_address,dynamic_favornum,dynamic_nikename;
//        private EditText dynamic_dynamicdataetx;
//        private ListView dynamic_listview;
//        private Button dynamic_publish;
        private LinearLayout dynamic_contain,dynamic_Linearyout;
    }

    public void getData(int creatid, final ImageView imageView,final TextView ntextView) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id",creatid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("ReturnUsers.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1){
                        if(!response.getJSONObject("resultData").getString("headimg").equals("")){
                            try{
                                urig = Uri.fromFile(new File(response.getJSONObject("resultData").getString("headimg")));
                                bitmap = MediaStore.Images.Media.getBitmap(MyApplication.getInstance().getContentResolver(), urig);
                                imageView.setImageBitmap(bitmap);
                            }catch (IOException e){
                                e.printStackTrace();
                            }
                            //headimg = response.getJSONObject("resultData").getString("headimg");
                            //ntextView.setText(response.getJSONObject("resultData").getString("nikename"));
                            ntextView.setText(response.getJSONObject("resultData").getString("nikename"));
                            //nikename = response.getJSONObject("resultData").getString("nikename");
                        }
                        Log.e("try", response.toString());
                    }else {
                        //Toast toast=Toast.makeText(MyApplication.getContext(), response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        //toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

//    class MyPlayerOnCompletionListener implements MediaPlayer.OnCompletionListener {
//
//        @Override
//        public void onCompletion(MediaPlayer mp) {
//            //Toast.makeText( MyApplication.getContext(), "播放完成了", Toast.LENGTH_SHORT).show();
//        }
//    }

}
