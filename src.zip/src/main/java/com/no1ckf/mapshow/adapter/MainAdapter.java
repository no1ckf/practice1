package com.no1ckf.mapshow.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.activity.MainActivity;
import com.no1ckf.mapshow.model.Dynamic;
import com.no1ckf.mapshow.model.Users;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapter extends BaseAdapter {
    private DynamicAdapter.ClickListener mClickListener;
    private LayoutInflater inflater;
    private List<Users> _listData = null;
    private Context mContext;
    private String headimg,nikename;
    private Uri urig;
    private Bitmap bitmap;

    public MainAdapter(Context context, List<Users> list){

        _listData = new ArrayList<Users>();
        _listData = list;
        this.mContext = context;
        inflater = LayoutInflater.from(mContext);
    }

    public interface ClickListener {
        public void onClick(Object ... objects);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return _listData == null ? 0 : _listData.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return _listData == null ? null : _listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return _listData == null ? 0 : position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub

        final MainAdapter.ViewHolder holder;
        View view = convertView;
        if(convertView == null){
            holder = new MainAdapter.ViewHolder();
            view = inflater.inflate(R.layout.list_dynamic, parent,false);
            holder.headimg = (CircleImageView) view.findViewById(R.id.headimg);


            view.setTag(holder);
        }else{
            holder = (MainAdapter.ViewHolder) view.getTag();
        }

//       holder.headimg.setImageResource(1);

        return view;
    }

    public class ViewHolder{
        CircleImageView headimg;
    }
}
