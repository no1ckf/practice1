package com.no1ckf.mapshow;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

import com.no1ckf.mapshow.utils.BDlistener;
import com.no1ckf.mapshow.utils.CacheManager;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;

public class MyApplication extends Application {

    private static MyApplication instance;
    public static Context context;

    public static MyApplication getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();
        instance = this;
        context = getApplicationContext();
        SharedPreferencesHelper.init(getApplicationContext());
        CacheManager.init(context);
        BDlistener.init(getApplicationContext());
    }

    // LTAIEEcrYWZqPuky
    // pEF6ZGhuEQ5K0x7GZ0rbZsVzZ8lJTt

    /**
     * 获取全局上下文*/
    public static Context getContext() {
        return context;
    }

}