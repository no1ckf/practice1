package com.no1ckf.mapshow.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.no1ckf.mapshow.R;
import com.no1ckf.mapshow.activity.AllDynamicActivity;
import com.no1ckf.mapshow.activity.DynamicActivity;
import com.no1ckf.mapshow.activity.InfoActivity;
import com.no1ckf.mapshow.adapter.DynamicAdapter;
import com.no1ckf.mapshow.model.Dynamic;
import com.no1ckf.mapshow.model.Users;
import com.no1ckf.mapshow.utils.BaseClient;
import com.no1ckf.mapshow.utils.SharedPreferencesHelper;
import com.no1ckf.mapshow.widget.XListView;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MineFragment extends Fragment implements XListView.IXListViewListener {
    List<Users> _list_users = new ArrayList<Users>();
    List<Dynamic> _list_dynamic =new ArrayList<Dynamic>();
    private XListView mine_list;
    private Handler mHandler;
    private int loginid;
    private Bitmap bitmap;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        getData();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent,
                             Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        View v = inflater.inflate(R.layout.single_listview, parent, false);
        mine_list = (XListView) v.findViewById(R.id.listview);
        mine_list.setPullRefreshEnable(true); //允许下拉刷新
        mine_list.setPullLoadEnable(true); //允许上拉加载更多
        mine_list.setAutoLoadEnable(true); //允许下拉到底部后自动加载
        mine_list.setXListViewListener(this);

        return v;
    }

    public void getData() {
        mHandler = new Handler();
        loginid = (int) SharedPreferencesHelper.getInstance().getData("id",0);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("creatid",loginid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpEntity entity;
        try {
            entity = new StringEntity(jsonObject.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        BaseClient.post("ReturnDynamicListByCreatId.aspx", entity, new JsonHttpResponseHandler() {
            //@SuppressLint("SimpleDateFormat")
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected
                // JSONArray
                Log.e("onSuccess", response.toString());
                try {
                    if (response.getInt("resultCode") == 1) {
                        JSONArray dynamic_array = response.getJSONArray("resultData");
                        for(int i = 0; i < dynamic_array.length(); i ++){
                            JSONObject jsonObject1 = (JSONObject) dynamic_array.get(i);
                            Dynamic dynamic = new Dynamic(jsonObject1.getInt("id"),jsonObject1.getInt("creatid"),jsonObject1.getString("creatdate"),
                                    jsonObject1.getString("dynamicdata"),jsonObject1.getString("videodata"),jsonObject1.getString("address"),
                                    jsonObject1.getString("latlng"), jsonObject1.getInt("commentnum"),jsonObject1.getInt("favornum"));
                            _list_dynamic.add(dynamic);
                        }
                        DynamicAdapter dynamicAdapter = new DynamicAdapter(mine_list.getContext(), _list_dynamic);
                        mine_list.setAdapter(dynamicAdapter);

                        mine_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                final LinearLayout name=(LinearLayout)view.findViewById(R.id.ldynamic_Linearyout);
                                final ImageView name2 = (ImageView) view.findViewById(R.id.ldynamic_headimg);
                                //mClickListener.onClick(name., 0);
                                //fragment = new GameFragment();
                                //Log.e("all", name.getContentDescription().toString());
                                String flag = name.getContentDescription().toString();
                                //Log.e("all", flag);
                                int flag1 = Integer.parseInt(flag);
                                SharedPreferencesHelper.getInstance().saveData("dynamicid",flag1);
                                flag = name2.getContentDescription().toString();
                                //Log.e("all", flag);
                                flag1 = Integer.parseInt(flag);
                                SharedPreferencesHelper.getInstance().saveData("creatid",flag1);
                                SharedPreferencesHelper.getInstance().saveData("fragment",0);
                                Intent intent = new Intent(getActivity().getApplicationContext(),DynamicActivity.class);
                                startActivity(intent);
                            }
                        });

                        Log.e("try", response.toString());
                    } else {
                        Toast toast = Toast.makeText(getContext(), response.getString("resultMessage"), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                onLoaded();
            }
        });
    }

    DynamicAdapter.ClickListener Click = new DynamicAdapter.ClickListener() {
        @Override
        public void onClick(Object... objects) {
            if (objects[1].equals(0)) {
                Intent intent = DynamicActivity.newIntent(getActivity().getApplicationContext(), (int)objects[0]);
                Log.e("group1",objects[0].toString());
                startActivity(intent);
            }
        }
    };

    //下拉刷新
    @Override
    public void onRefresh() {
        // TODO Auto-generated method stub
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                _list_dynamic = new ArrayList<Dynamic>();
                getData();
            }
        }, 2);
    }

    //上拉加载更多
    @Override
    public void onLoadMore() {
        // TODO Auto-generated method stub
//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                getData();
//            }
//        },2);
    }

    //完成数据加载
    private void onLoaded() {
        mine_list.stopRefresh(); //停止刷新
        mine_list.stopLoadMore(); //停止加载更多
        mine_list.setRefreshTime(getTime());
    }

    private String getTime() {
        return new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(new Date());
    }
}
