package com.no1ckf.mapshow.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Comment {
    private int id;              //评论id
    private int dynamicid;       //动态id
    private int creatid;         //创建者id
    private String creatdate;    //创建日期
    private String commentdata;  //评论内容
    private int commentstate;    //评论状态

    public Comment(int id, int dynamicid, int creatid, String creatdate, String commentdata, int commentstate) {
        this.id = id;
        this.dynamicid = dynamicid;
        this.creatid = creatid;
        this.creatdate = creatdate;
        this.commentdata = commentdata;
        this.commentstate = commentstate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDynamicid() {
        return dynamicid;
    }

    public void setDynamicid(int dynamicid) {
        this.dynamicid = dynamicid;
    }

    public int getCreatid() {
        return creatid;
    }

    public void setCreatid(int creatid) {
        this.creatid = creatid;
    }

    public String getCreatdate() {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date strtodate = formatter.parse(creatdate);
            creatdate = formatter2.format(strtodate);
            String dateString = formatter1.format(strtodate);
            String hour = creatdate.substring(11, 13);
            String min = creatdate.substring(14, 16);
            creatdate = dateString + " " + hour + ":" + min;
        }catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return creatdate;
    }

    public void setCreatdate(String creatdate) {
        this.creatdate = creatdate;
    }

    public String getCommentdata() {
        return commentdata;
    }

    public void setCommentdata(String commentdata) {
        this.commentdata = commentdata;
    }

    public int getCommentstate() {
        return commentstate;
    }

    public void setCommentstate(int commentstate) {
        this.commentstate = commentstate;
    }
}
