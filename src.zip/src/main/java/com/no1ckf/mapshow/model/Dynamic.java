package com.no1ckf.mapshow.model;

import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;

import com.no1ckf.mapshow.MyApplication;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Dynamic {
    private int id;             //动态id
    private int creatid;        //创建者id
    private String creatdate;   //创建日期
    private String dynamicdata; //动态内容
    private String videodata;   //视频url
    private String address;     //地址
    private String latlng;      //经纬度
    private int commentnum;     //评论数
    private int favornum;       //喜欢数
    private Bitmap headimg;
    private String nikename;
    private Bitmap bitmap;

    public Dynamic(int id, int creatid, String creatdate, String dynamicdata, String videodata, String address, String latlng, int commentnum, int favornum) {
        this.id = id;
        this.creatid = creatid;
        this.creatdate = creatdate;
        this.dynamicdata = dynamicdata;
        this.videodata = videodata;
        this.address = address;
        this.latlng = latlng;
        this.commentnum = commentnum;
        this.favornum = favornum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCreatid() {
        return creatid;
    }

    public void setCreatid(int creatid) {
        this.creatid = creatid;
    }

    public String getCreatdate() {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date strtodate = formatter.parse(creatdate);
            creatdate = formatter2.format(strtodate);
            String dateString = formatter1.format(strtodate);
            String hour = creatdate.substring(11, 13);
            String min = creatdate.substring(14, 16);
            creatdate = dateString + " " + hour + ":" + min;
        }catch (ParseException e) {
           // TODO Auto-generated catch block
           e.printStackTrace();
        }
        return creatdate;
    }

    public void setCreatdate(String creatdate) {
        this.creatdate = creatdate;
    }

    public String getDynamicdata() {
        return dynamicdata;
    }

    public void setDynamicdata(String dynamicdata) {
        this.dynamicdata = dynamicdata;
    }

    public String getVideodata() {
        return videodata;
    }

    public void setVideodata(String videodata) {
        this.videodata = videodata;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLatlng() {
        return latlng;
    }

    public void setLatlng(String latlng) {
        this.latlng = latlng;
    }

    public int getCommentnum() {
        return commentnum;
    }

    public void setCommentnum(int commentnum) {
        this.commentnum = commentnum;
    }

    public String getFavornum() {
        return String.valueOf(favornum);
    }

    public void setFavornum(int favornum) {
        this.favornum = favornum;
    }

    public Bitmap getHeadimg() {
        //Bitmap bitmap;
//        try{
//            Uri uri = Uri.fromFile(new File(headimg));
//            bitmap = MediaStore.Images.Media.getBitmap(MyApplication.getInstance().getContentResolver(), uri);
//        }catch (IOException e){
//            e.printStackTrace();
//        }catch (NullPointerException e){
//            e.printStackTrace();
//        }
        //return bitmap;
        return headimg;
    }

    public void setHeadimg(Bitmap headimg) {
        this.headimg = headimg;
    }

    public String getNikename() {
        return nikename;
    }

    public void setNikename(String nikename) {
        this.nikename = nikename;
    }
}
