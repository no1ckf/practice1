package com.no1ckf.mapshow.model;

public class Users {
    private int id;           //用户id
    private String username;  //用户名
    private String password;  //密码
    private String headimg;   //头像url
    private String nikename;  //昵称
    private String signature; //个性签名
    private String sex;       //性别
    private int state;        //账号状态

    public Users(int id, String username, String password, String headimg, String nikename, String signature, String sex, int state) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.headimg = headimg;
        this.nikename = nikename;
        this.signature = signature;
        this.sex = sex;
        this.state = state;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getHeadimg() {
        return headimg;
    }

    public void setHeadimg(String headimg) {
        this.headimg = headimg;
    }

    public String getNikename() {
        return nikename;
    }

    public void setNikename(String nikename) {
        this.nikename = nikename;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }
}
