package com.no1ckf.mapshow.model;

public class Main {
    private int id;
    private String headimg;
    private double lat;
    private double lng;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getHeadimg() {
        return headimg;
    }

    public void setHeadimg(String headimg) {
        this.headimg = headimg;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public Main(int id , String headimg , double lat, double lng){
        this.headimg = headimg;
        this.id = id;
        this.lat = lat;
        this.lng = lng;
    }
}
