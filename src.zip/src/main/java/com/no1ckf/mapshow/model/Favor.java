package com.no1ckf.mapshow.model;

public class Favor {
    private int id;            //喜欢id
    private int dynamicid;     //动态id
    private int creatid;       //创建者id
    private String creatdate;  //创建日期

    public Favor(int id, int dynamicid, int creatid, String creatdate) {
        this.id = id;
        this.dynamicid = dynamicid;
        this.creatid = creatid;
        this.creatdate = creatdate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDynamicid() {
        return dynamicid;
    }

    public void setDynamicid(int dynamicid) {
        this.dynamicid = dynamicid;
    }

    public int getCreatid() {
        return creatid;
    }

    public void setCreatid(int creatid) {
        this.creatid = creatid;
    }

    public String getCreatdate() {
        return creatdate;
    }

    public void setCreatdate(String creatdate) {
        this.creatdate = creatdate;
    }
}
